CREATE procedure PRO_lj_price_min_max
is
/************************************************************************************************************************************
开发人员：唐遂宁
开发时间：2017-04-14
变更时间：计算assess_house表中的均价及最小、最大参考均价，计算结果放在表：assess_house中
变更内容：
输入参数：
返回参数：房屋评估单价
过程功能：计算房屋单价
************************************************************************************************************************************/
sv_err_sqlcode varchar2(200);
sv_err_SQLERRM varchar2(2000);

begin
  --1、是否能匹配lj_name+building_type
  merge into assess_house h
  using (
  select distinct h.district_id,h.building_type,p.avgprice_min,p.avgprice_max,p.avgprice
  from assess_house h inner join tmp_lj_district_rel t on h.district_id=t.district_id and h.tr_price=0
  inner join lj_project_building_price p on t.lj_name=p.lj_name and h.building_type=p.building_type ) tt
  on (h.district_id=tt.district_id and h.building_type=tt.building_type)
  when matched then
  update set h.tr_price_min=tt.avgprice_min,h.tr_price_max=tt.avgprice_max,h.tr_price=tt.avgprice,h.RISK_BROAD=0;

  --2、是否能匹配lj_name
  merge into assess_house h
  using (
  select distinct h.district_id,p.avgprice_min,p.avgprice_max,p.avgprice
  from assess_house h inner join tmp_lj_district_rel t on h.district_id=t.district_id and h.tr_price=0
  inner join lj_project_price p on t.lj_name=p.lj_name ) tt
  on (h.district_id=tt.district_id )
  when matched then
  update set h.tr_price_min=tt.avgprice_min,h.tr_price_max=tt.avgprice_max,h.tr_price=tt.avgprice,h.RISK_BROAD=0;

  --3、是否能匹配block_name+building_type
  merge into assess_house h
  using (
  select distinct h.district_id,h.building_type,p.avgprice_min,p.avgprice_max,p.avgprice
  from assess_house h inner join tmp_lj_district_rel t on h.district_id=t.district_id and h.tr_price=0
  inner join lj_block_building_price p on t.lj_block=p.lj_block and h.building_type=p.building_type ) tt
  on (h.district_id=tt.district_id and h.building_type=tt.building_type )
  when matched then
  update set h.tr_price_min=tt.avgprice_min,h.tr_price_max=tt.avgprice_max,h.tr_price=tt.avgprice,h.RISK_BROAD=1;

  --4、是否能匹配block_name
  merge into assess_house h
  using (
  select distinct h.district_id,p.avgprice_min,p.avgprice_max,p.avgprice
  from assess_house h inner join tmp_lj_district_rel t on h.district_id=t.district_id and h.tr_price=0
  inner join lj_block_price p on t.lj_block=p.lj_block ) tt
  on (h.district_id=tt.district_id )
  when matched then
  update set h.tr_price_min=tt.avgprice_min,h.tr_price_max=tt.avgprice_max,h.tr_price=tt.avgprice,h.RISK_BROAD=1;

  --5、是否能匹配region_name+building_type
  merge into assess_house h
  using (
  select distinct h.building_type,p.region_code,p.avgprice_min,p.avgprice_max,p.avgprice
  from assess_house h inner join lj_region_building_price p on h.region_code=p.region_code and h.building_type=p.building_type ) tt
  on (h.region_code=tt.region_code and h.building_type=tt.building_type )
  when matched then
  update set h.tr_price_min=tt.avgprice_min,h.tr_price_max=tt.avgprice_max,h.tr_price=tt.avgprice,h.RISK_BROAD=2;


  --6、是否能匹配region_name
  merge into assess_house h
  using (
  select distinct p.avgprice_min,p.avgprice_max,p.avgprice,p.region_code
  from assess_house h inner join lj_region_price p on h.region_code=p.region_code ) tt
  on (h.region_code=tt.region_code )
  when matched then
  update set h.tr_price_min=tt.avgprice_min,h.tr_price_max=tt.avgprice_max,h.tr_price=tt.avgprice,h.RISK_BROAD=2;

  delete ASSESSPRICE.WORK_LOG where name='PRO_lj_price_min_max' and trunc(in_date)=trunc(sysdate);
  insert into ASSESSPRICE.WORK_LOG
  values(assessprice.seq_work_log_id.nextval,'PRO_lj_price_min_max','','','是','成功',trunc(sysdate),'','','PRO_lj_price_min_max');
  commit;

  exception when others then
  dbms_output.put_line('捕获错误 ');
  sv_err_sqlcode:=('错误代码：'||SQLCODE);
  sv_err_SQLERRM:=('错误信息：'||SQLERRM);
  insert into ASSESSPRICE.WORK_LOG
  values(assessprice.seq_work_log_id.nextval,'PRO_lj_price_min_max','','','是','失败',trunc(sysdate),sv_err_sqlcode,sv_err_SQLERRM,'PRO_lj_price_min_max');
  commit;
end PRO_lj_price_min_max;
/

