CREATE procedure PRO_ETL_BASETABLE
is
/************************************************************************************************************************************
开发人员：谢勇
开发时间：2016-11-16
变更时间：
变更内容：
输入参数：
返回参数：
过程功能：增量新增或者更新房屋评估系统基础数据（建筑区划信息，楼栋信息，房源信息）
************************************************************************************************************************************/

sv_err_sqlcode varchar2(200);
sv_err_SQLERRM varchar2(2000);
v_date date;
begin
v_date := trunc(sysdate);


insert into ASSESSPRICE.WORK_LOG values(assessprice.seq_work_log_id.nextval,'抽取数据开始','','','','',sysdate,'','','基础数据抽取模块');

--楼栋信息
merge into assessprice.ASSESS_PROJECTS a
using (select * from estate.projects p where  p.etl_time >= v_date -1) p
on(a.PROJID = p.projid and a.data_source = p.data_source)
when matched then
  update set
a.houseage = trim(p.houseage),
a.struct = p.struct,
a.housetype = p.buildtype,
a.projects = p.project,
a.totfloor =p.totfloor,
a.xcentercood = p.xcentercoord,
a.ycentercood = p.ycentercoord,
a.sys_update_time = v_date
when not matched then
insert (id,PROJID,data_source,hno,enddate,houseage,struct,housetype,projects,totfloor,led_hou_ratio,
LIFT,out_elevation,xcentercood,ycentercood,totalarea,is_deleted,version,sys_create_time,sys_update_time,sys_delete_id
)
values(assessprice.SEQ_ASSESS_PROJECTS_ID.NEXTVAL,
p.projid,p.data_source,null,null,trim(p.houseage),p.struct,p.buildtype,p.project,p.totfloor,null,null,null,p.xcentercoord,p.ycentercoord,null,
0,1,v_date,v_date,1)
;
dbms_output.put_line('楼栋信息 ');

--建筑区划信息
merge into assessprice.assess_district b
using  (select * from wxzj.fix_district a where a.etl_time >= v_date -1)a
on(b.district_id = a.id and a.region_code = b.region_code
)
when matched then
  update set

b.district_name =a.district_name,
b.district_code =a.district_code,
b.manager_type = a.manager_type,
b.org_dev_desc = a.org_dev_desc,
b.district_address = a.district_address,
b.belong_street = a.belong_street,
b.belong_committee = a.belong_committee,
b.street = a.street,
b.link_people = a.link_people,
b.link_tel = a.link_tel,
b.link_address = a.link_address,
b.remark = a.remark,
b.east = a.east,
b.west = a.west,
b.south = a.south,
b.north = a.north,
b.district_type = a.district_type,
b.floorest = a.floorest,
b.total_area = a.total_area,
b.plot_ratio = a.plot_ratio,
b.green_retio = a.green_retio,
b.indoor_parking_space =a.indoor_parking_space,
b.outdoor_parking_space = a.outdoor_parking_space,
b.property_service_address = a.property_service_address,
b.committee_service_address = a.committee_service_address,
b.property_service_area = a.property_service_area,
b.committee_service_area = a.committee_service_area,
b.sys_update_time = v_date
when not matched then

insert (
district_id,
district_name,
district_code,
XCENTERCOOD,
YCENTERCOOD,
manager_type,
region_code,
org_dev_desc,
district_address,
belong_street,
belong_committee,
street,
sno,saddno,
link_people,
link_tel,
link_address,
remark,
east,
west,
south,
north,
district_type,
floorest,
total_area,
plot_ratio,
green_retio,
indoor_parking_space,
outdoor_parking_space,
property_service_address,
committee_service_address,
property_service_area,
committee_service_area,
property_fee,
is_deleted,version,
sys_create_time,
sys_update_time,
sys_create_id)
values(a.id,
a.district_name,
a.district_code,
null,null,
a.manager_type,
a.region_code,
a.org_dev_desc,
a.district_address,
a.belong_street,
a.belong_committee,
a.street,
null,null,
a.link_people,
a.link_tel,
a.link_address,
a.remark,
a.east,a.west,a.south,a.north,
a.district_type,a.floorest,
a.total_area,a.plot_ratio,a.green_retio,a.indoor_parking_space,a.outdoor_parking_space,a.property_service_address,a.committee_service_address,
a.property_service_area,a.committee_service_area,null,0,1,v_date,v_date,1
)
;
dbms_output.put_line('建筑区划信息 ');

---抽取房源数据
merge into assessprice.ASSESS_HOUSE a
using  (select * from estate.housetable h where h.area >0 and h.etl_time >= v_date -1 ) h
on(a.tableid = h.tableid and a.data_source = h.data_source)
when matched then
  update set
  a.projid = h.projid,
  a.districk = h.districk,
  a.street = h.streetscene,
  a.sno = h.doorplate,
  a.saddno = h.additory_doorplate,
  a.hno = h.hno,
  a.uno = h.uno,
  a.fno = h.fno,
  a.rno = h.rno,
  a.area = nvl(h.area,0),
  a.outarea = nvl(h.outarea,0),
  a.totalarea = nvl(h.area,0)+nvl(h.outarea,0),
  a.suit_type = h.planinfo,
  a.room_struct = h.roomstruct,
  a.struct = h.struct,
  a.orientation = h.roomsunny,
  a.fitment = h.fitmentlevel,
  a.sys_update_time = v_date,
  a.totalprice = h.price,
  a.totaldecprice= h.price - nvl(h.fitmentprice,0),
  a.price = round(h.price/(h.area+h.outarea),2),
  a.decprice = round((h.price - nvl(h.fitmentprice,0))/(h.area+h.outarea),0),
  a.lifestatus = h.lifestatus,
  a.foresyncmark = h.foresyncmark,
  a.licenceid = h.licenceid
when not matched then
insert (hou_id,tableid,projid,districk,street,sno,saddno,hno,uno,fno,rno,area,
outarea,totalarea,suit_type,room_struct,struct,
ORIENTATION,FITMENT,is_deleted,version,STATUS,DATA_SOURCE,sys_create_time,sys_update_time,sys_delete_id,
totalprice,totaldecprice,price,decprice,lifestatus,foresyncmark,licenceid
)
values(assessprice.seq_assess_house_id.nextval,h.tableid,h.projid,h.districk,h.streetscene,h.doorplate,
h.additory_doorplate,h.hno,h.uno,h.fno,h.rno,
h.area,h.outarea,h.area+h.outarea,h.planinfo,h.roomstruct,h.struct,h.roomsunny,h.fitmentlevel,0,1,'有效',h.data_source,v_date,v_date,1,
h.price,h.price - nvl(h.fitmentprice,0),h.price/(h.area+h.outarea),(h.price - nvl(h.fitmentprice,0))/(h.area+h.outarea),h.lifestatus,h.foresyncmark,h.licenceid
);
dbms_output.put_line('房源信息 ');

--房源关联建筑区划信息
merge into assessprice.assess_house h
using (SELECT manual_code,data_source,district_id FROM (
SELECT  a.manual_code,a.data_source,b.district_id,
row_number()over(partition by a.manual_code ORDER BY a.sys_create_time desc) row_id
FROM  wxzj.fix_house a
inner join wxzj.fix_building b on a.building_id = b.id
and a.is_deleted = 0 and b.is_deleted = 0
and a.manual_code is not null
--and a.data_source in('510100','510114')
and a.etl_time >= v_date -1
) WHERE row_id = 1) a
on(h.tableid = a.manual_code and h.data_source = a.data_source)
when matched then
  update set h.district_id = a.district_id
;
dbms_output.put_line('房源关联建筑区划信息 ');
--回写房龄到房源表
merge into assessprice.assess_house a
using (select a.hou_id,b.houseage  from assessprice.assess_house a
inner join assessprice.assess_projects b on a.projid = b.projid and a.data_source = b.data_source
and regexp_like(b.houseage,'^[0-9]*$')
and a.is_deleted = 0
and b.is_deleted = 0
and a.sys_update_time >= v_date -1) b
on(a.hou_id = b.hou_id)
when matched then
  update set a.house_age = b.houseage;


dbms_output.put_line('回写房龄信息 ');
-------------------------------------------
---回写区域编码到房源表
merge into assessprice.assess_house a
using(
select a.hou_id,c.region_code,c.region_name
from assessprice.assess_house a
inner join wxzj.fix_district b on a.district_id = b.id  and b.is_deleted = 0 and a.sys_update_time >= v_date
inner join cdfgora.t_region_d c  on b.region_code = c.region_code
) b
on(a.hou_id = b.hou_id)
when matched then
  update set a.region = b.region_name,a.region_code = b.region_code
;

update assessprice.assess_house h
set h.region_code = case
when h.data_source = '510100' and h.districk in('锦江区','锦江','3锦江区')  then '510104'
when h.data_source = '510100' and h.districk in('武侯区','武侯','武候区')  then '510107'
when h.data_source = '510100' and h.districk in('青羊区','青羊')  then '510105'
when h.data_source = '510100' and h.districk in('金牛区','.金牛区','金牛')  then '510106'
when h.data_source = '510100' and h.districk in('成华区','.成华区','成华')  then '510108'
when h.data_source = '510100' and h.districk in('高新区','高新','高新区（西区）','西航港街道','西航港街道办事处','西航港开发区','中和','中和街道','中和镇','华阳镇')  then '510109'
else '' end
where h.region_code is null
and h.sys_update_time >= v_date;


merge into assessprice.assess_house a
using (select a.hou_id,b.region_name from assessprice.assess_house a
inner join  cdfgora.t_region_d b on a.region_code = b.region_code
and a.region is null and a.sys_update_time >= v_date) b
on(a.hou_id = b.hou_id)
when matched then
  update set a.region = b.region_name;

dbms_output.put_line('回写区域编码到房源表');

----------------------------------
--回写板块id
merge into assessprice.assess_house a
using(
select  a.hou_id,b.block_id from assessprice.ASSESS_HOUSE a
inner join assessprice.assess_block_district_rel b on a.district_id = b.district_id
and a.is_deleted = 0 and b.is_deleted = 0
and a.block_id is null
and a.sys_update_time >=v_date
) b
on(a.hou_id = b.hou_id)
when matched then
  update set a.block_id = b.block_id
;
dbms_output.put_line('回写板块id');


--建筑区划配套
merge into assessprice.ASSESS_DISTRICT_SUPPORTING a
using (SELECT
a.id as supporting_id,a.district_id,a.facility_name as supporting_name,case when a.scrap_date is not null then '否'else '是' end  isaffective,
b.facility_type_name as supporting_type,to_char(a.enable_date,'yyyy') as finish_year,'是' isfinished,0 is_deleted,1 version,
v_date sys_create_time,v_date sys_update_time,1 sys_create_id
 FROM wxzj.fix_facility a
 inner join wxzj.fix_facility_type b on a.facility_type_code = b.code and a.is_deleted =0 and b.is_deleted = 0
 and a.etl_time >= v_date-1) b
on(a.supporting_id = b.supporting_id)
when matched then
  update set
  a.district_id = b.district_id,
  a.supporting_name = b.supporting_name,
  a.isaffective = b.isaffective,
  a.supporting_type = b.supporting_type,
  a.finish_year = b.finish_year,
  a.isfinished = b.isfinished,
  a.sys_update_time = v_date
when not matched then
  insert(supporting_id,district_id,supporting_name,isaffective,supporting_type,finish_year,isfinished,is_deleted,
version,sys_create_time,sys_update_time,sys_create_id)
values(
b.supporting_id,b.district_id,b.supporting_name,b.isaffective,
b.supporting_type,b.finish_year,b.isfinished,b.is_deleted,b.version,
v_date,v_date,1)
;
dbms_output.put_line('建筑区划配套 ');
--房源配套




insert into ASSESSPRICE.WORK_LOG values(assessprice.seq_work_log_id.nextval,'抽取数据成功','','','否','成功',sysdate,sv_err_sqlcode,sv_err_SQLERRM,'基础数据抽取模块');
commit;


------------------------------------------
---更新最新的存量房价格
------------------------------------------
insert into ASSESSPRICE.WORK_LOG values(assessprice.seq_work_log_id.nextval,'开始更新存量房交易价格','','','','',sysdate,'','','存量房价格');

merge into assessprice.assess_house a
using(
select house_code,region_code,price from(
select hbi.house_code,hbi.region_code, sp.supervision_fund+sp.loan_fund price,row_number()over(partition by hbi.house_code,hbi.region_code  ORDER BY sp.code desc) row_id
from trading.fs_supervision_protocol@dl_cd sp
inner join trading.fs_contract@dl_cd c on sp.id = c.supervision_protocol_id and sp.deleted = 0 and c.contract_type = 'SERVICE_CONTRACT'
inner join trading.fund_supervision_info@dl_cd fsi on c.contract_code = fsi.services_contract_code and fsi.deleted = 0
inner join trading.services_contract_house_ref@dl_cd schr on fsi.services_contract_id = schr.services_contract_id
inner join trading.house_base_info@dl_cd hbi on schr.house_id = hbi.id
) where row_id = 1
) b on(a.tableid = b.house_code and a.data_source = b.region_code)
when matched then
  update set a.stock_price = b.price;

insert into ASSESSPRICE.WORK_LOG values(assessprice.seq_work_log_id.nextval,'更新存量房交易价格成功','','','否','成功',sysdate,'','','存量房价格');

commit;

------------------------------------------
---调用估价算法计算新增房源价格
------------------------------------------
assessprice.pro_assess;


    exception when others then
    dbms_output.put_line('捕获错误 ');
    sv_err_sqlcode:=('错误代码：'||SQLCODE);
    sv_err_SQLERRM:=('错误信息：'||SQLERRM);
insert into ASSESSPRICE.WORK_LOG values(assessprice.seq_work_log_id.nextval,'抽取失败','','','是','失败',sysdate,sv_err_sqlcode,sv_err_SQLERRM,'评估基础数据抽取模块');

    commit;


end PRO_ETL_BASETABLE;
/

