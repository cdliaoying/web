CREATE Function             FUNC_GET_EARTH_DISTANCE(lon1 Number,lat1 Number,lon2 Number,lat2 Number)
Return Number As
/************************************************************************************************************************************
开发人员：谢勇
开发时间：2016-11-16
变更时间：
变更内容：
输入参数：坐标1的经纬度 ，坐标2的经纬度，坐标精度小数点后8位
返回参数：两个坐标点之间的距离（米）
过程功能：根据两点坐标计算两点之间的距离
************************************************************************************************************************************/
  rad_lon1     Number(12, 8);
  rad_lat1     Number(12, 8);
  rad_lon2     Number(12, 8);
  rad_lat2     Number(12, 8);
  a            Number(12, 8);
  b            Number(12, 8);
  pi           Number := 3.14159265;
  s            Number(20, 8);
  EARTH_RADIUS Number := 6378.137;
Begin
  rad_lat1 := lat1 * pi / 180.0;
  rad_lat2 := lat2 * pi / 180.0;
  rad_lon1 := lon1 * pi / 180.0;
  rad_lon2 := lon2 * pi / 180.0;
  a        := rad_lat1 - rad_lat2;
  b        := rad_lon1 - rad_lon2;
  s        := 2 * asin(sqrt(power(sin(a / 2), 2)+
                            cos(rad_lat1) * cos(rad_lat2) *
                            power(sin(b / 2), 2)));
  s        := s * EARTH_RADIUS;
  s        := round(s * 100000) / 100000;
  s        := s * 1000;
  Return s;
End FUNC_GET_EARTH_DISTANCE;
/

