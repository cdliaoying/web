CREATE procedure sp_hu_test(spcode in int,spname out varchar2)is
begin
select data_source into spname 
from estate.housetable  where tableid = spcode;
end;
/

