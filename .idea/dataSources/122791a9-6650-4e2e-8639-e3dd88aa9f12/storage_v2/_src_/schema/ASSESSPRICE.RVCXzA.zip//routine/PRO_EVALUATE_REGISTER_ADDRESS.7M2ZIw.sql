CREATE procedure pro_evaluate_register_address ( s_type in varchar2,s_date in varchar2 )
is
/************************************************************************************************************************************
开发时间：2017-07-11
变更时间：
变更内容：
输入参数：s_type='ini',初始化，'add'，增量；yyyy-mm-dd
返回参数：
过程功能：增量抽取证载地址数据
************************************************************************************************************************************/
v_start_date date;
v_end_date date;

v_sqlcode varchar2(200);
v_sqlerrm varchar2(2000);


begin

    --开始时间
    select sysdate into v_start_date from dual;

    if s_type='ini' then

    EXECUTE IMMEDIATE 'truncate table assessprice.evaluate_register_address';

    --全量抽取证载地址
    merge into assessprice.evaluate_register_address a
    using ( select distinct b.street as streetscene,b.sno as doorplate,b.saddno as additory_doorplate
         from hregister.registrations r inner join hregister.buildinght b on r.id=b.regiid and r.data_source=b.data_source
               where r.regitype in ('所有权登记') and r.status in (1500,1501) and b.street is not null
       ) t  on ( decode( a.streetscene,null,'999999','','999999',a.streetscene ) = decode( t.streetscene,null,'999999','','999999',t.streetscene )  and
                    decode( a.doorplate,null,'999999','','999999',a.doorplate ) = decode( t.doorplate,null,'999999','','999999',t.doorplate )  and
                    decode( a.additory_doorplate,null,'999999','','999999',a.additory_doorplate ) = decode( t.additory_doorplate,null,'999999','','999999',t.additory_doorplate )
       )
       when not matched then
         insert ( streetscene,doorplate,additory_doorplate  )
        values( t.streetscene,t.doorplate,t.additory_doorplate );
    else
    --增量抽取证载地址
    merge into assessprice.evaluate_register_address a
    using ( select distinct b.street as streetscene,b.sno as doorplate,b.saddno as additory_doorplate
         from hregister.registrations r inner join hregister.buildinght b on r.id=b.regiid and r.data_source=b.data_source
               where r.regitype in ('所有权登记') and r.status in (1500,1501) and b.street is not null and r.etl_time between to_date(s_date||' 00:00:00','yyyy-mm-dd hh24:mi:ss') and to_date(s_date||' 23:59:59','yyyy-mm-dd hh24:mi:ss')
       ) t on ( decode( a.streetscene,null,'999999','','999999',a.streetscene ) = decode( t.streetscene,null,'999999','','999999',t.streetscene )  and
                    decode( a.doorplate,null,'999999','','999999',a.doorplate ) = decode( t.doorplate,null,'999999','','999999',t.doorplate )  and
                    decode( a.additory_doorplate,null,'999999','','999999',a.additory_doorplate ) = decode( t.additory_doorplate,null,'999999','','999999',t.additory_doorplate )
       )
       when not matched then
         insert ( streetscene,doorplate,additory_doorplate  )
        values( t.streetscene,t.doorplate,t.additory_doorplate );
    end if;

    --结束时间
    select sysdate into v_end_date from dual;

    delete from assessprice.operate_log where proc_name='pro_evaluate_register_address' and parameter_name=s_date;
    insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
    values(sys_guid(),'pro_evaluate_register_address',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'成功','');
    commit;

    exception
    when others then
    v_sqlcode:=('错误代码:'||SQLCODE);
    v_sqlerrm:=('错误信息:'||SQLERRM);
    insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
    values(sys_guid(),'pro_evaluate_register_address',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'失败:'||v_sqlcode,v_sqlerrm);
    commit;
end pro_evaluate_register_address;
/

