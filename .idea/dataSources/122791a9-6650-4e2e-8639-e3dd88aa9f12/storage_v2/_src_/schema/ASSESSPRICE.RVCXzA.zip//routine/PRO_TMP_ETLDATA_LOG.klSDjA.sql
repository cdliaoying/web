CREATE procedure pro_tmp_etldata_log ( s_date in varchar2)
is
/************************************************************************************************************************************
开发：tsn
开发时间：2017-05-08
变更时间：
变更内容：计算assess_house、新房网签数据、存量房网签数据、评估备案数据每日条数
输入参数：
返回参数：
过程功能：
************************************************************************************************************************************/
v_sqlcode varchar2(200);
v_sqlerrm varchar2(2000);

v_start_date date;
v_end_date date;

begin

    --1、计算assess_house表中每日抽取数据条数及数据表中总条数
    begin
      --开始时间
      select sysdate into v_start_date from dual;
      v_sqlcode:=null;
      v_sqlerrm:=null;

      merge into tmp_etldata_log tl
      using
      (
      select t.data_type,
         to_date(s_date,'yyyy-mm-dd') as create_date,
         sum(t.new_data_amount) as new_data_amount,
         sum(t.last_data_amount) as last_data_amount,
         sum(t.total_data_amount) as total_data_amount,
         round(decode(sum(t.last_data_amount),0,0,(sum(t.new_data_amount)-sum(t.last_data_amount))/sum(t.last_data_amount)),4) as rate
    from
    (
    select '评估数据' as data_type,
           count(1) as new_data_amount,
           0 as last_data_amount,
           0 as total_data_amount,
           0
    from assess_house h where to_char(h.sys_create_time,'yyyy-mm-dd')= s_date
    union all
    select '评估数据' as data_type,
           0 as new_data_amount,
           count(1) as last_data_amount,
           0 as total_data_amount,
           0
    from assess_house h where h.sys_create_time= (to_date(s_date,'yyyy-mm-dd') -1 )
    union all
    select '评估数据' as data_type,
           0 as new_data_amount,
           0 as last_data_amount,
           count(1) as total_data_amount,
           0
    from assess_house h where to_char(h.sys_create_time,'yyyy-mm-dd')<= s_date  ) t
    group by t.data_type
      ) ss
      on ( tl.data_type=ss.data_type and trunc(tl.create_date)=trunc(ss.create_date) )
      when matched then update set tl.new_data_amount=ss.new_data_amount,tl.last_data_amount=ss.last_data_amount,tl.total_data_amount=ss.total_data_amount,tl.rate=ss.rate
        when not matched then insert (create_date,data_type,new_data_amount,last_data_amount,total_data_amount,rate)
          values(ss.create_date,ss.data_type,ss.new_data_amount,ss.last_data_amount,ss.total_data_amount,ss.rate);

      --只保留30天的数据
      delete from tmp_etldata_log t where t.data_type='评估数据'
      and trunc(t.create_date) not between trunc(to_date(s_date,'yyyy-mm-dd')-30) and trunc(to_date(s_date,'yyyy-mm-dd'));

      --结束时间
      select sysdate into v_end_date from dual;

      delete from assessprice.operate_log where proc_name='评估数据' and parameter_name=s_date;

      insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
      values(sys_guid(),'评估数据',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'成功','');

      commit;

      exception
      when others then
      v_sqlcode:=('错误代码:'||SQLCODE);
      v_sqlerrm:=('错误信息:'||SQLERRM);

      insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
      values(sys_guid(),'评估数据条数',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'失败:'||v_sqlcode,v_sqlerrm);
      commit;
    end;


    --2、计算assess_tradingsh_house表中新房网签数据每日抽取数据条数及数据表中总条数
    begin
      --开始时间
      select sysdate into v_start_date from dual;
      v_sqlcode:=null;
      v_sqlerrm:=null;

      merge into tmp_etldata_log tl
      using
      (
      select t.data_type,
         to_date(s_date,'yyyy-mm-dd') as create_date,
         sum(t.new_data_amount) as new_data_amount,
         sum(t.last_data_amount) as last_data_amount,
         sum(t.total_data_amount) as total_data_amount,
         round(decode(sum(t.last_data_amount),0,0,(sum(t.new_data_amount)-sum(t.last_data_amount))/sum(t.last_data_amount)),4) as rate
    from
    (
    select '新房网签数据' as data_type,
           count(1) as new_data_amount,
           0 as last_data_amount,
           0 as total_data_amount,
           0
    from assess_tradingsh_house h where to_char(h.buydate,'yyyy-mm-dd')= s_date
    union all
    select '新房网签数据' as data_type,
           0 as new_data_amount,
           count(1) as last_data_amount,
           0 as total_data_amount,
           0
    from assess_tradingsh_house h where trunc(h.buydate)=trunc (to_date(s_date,'yyyy-mm-dd') -1 )
    union all
    select '新房网签数据' as data_type,
           0 as new_data_amount,
           0 as last_data_amount,
           count(1) as total_data_amount,
           0
    from assess_tradingsh_house h where h.buydate is not null and to_char(h.buydate,'yyyy-mm-dd')<= s_date  ) t
    group by t.data_type
      ) ss
      on ( tl.data_type=ss.data_type and trunc(tl.create_date)=trunc(ss.create_date) )
      when matched then update set tl.new_data_amount=ss.new_data_amount,tl.last_data_amount=ss.last_data_amount,tl.total_data_amount=ss.total_data_amount,tl.rate=ss.rate
        when not matched then insert (create_date,data_type,new_data_amount,last_data_amount,total_data_amount,rate)
          values(ss.create_date,ss.data_type,ss.new_data_amount,ss.last_data_amount,ss.total_data_amount,ss.rate);

      --只保留30天的数据
      delete from tmp_etldata_log t where t.data_type='新房网签数据'
      and trunc(t.create_date) not between trunc(to_date(s_date,'yyyy-mm-dd')-30) and trunc(to_date(s_date,'yyyy-mm-dd'));

      --结束时间
      select sysdate into v_end_date from dual;

      delete from assessprice.operate_log where proc_name='新房网签数据' and parameter_name=s_date;

      insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
      values(sys_guid(),'新房网签数据',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'成功','');

      commit;

      exception
      when others then
      v_sqlcode:=('错误代码:'||SQLCODE);
      v_sqlerrm:=('错误信息:'||SQLERRM);

      insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
      values(sys_guid(),'新房网签数据',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'失败:'||v_sqlcode,v_sqlerrm);
      commit;
    end;

    --3、计算assess_tradingsh_house表中评估备案数据每日抽取数据条数及数据表中总条数
    begin
      --开始时间
      select sysdate into v_start_date from dual;
      v_sqlcode:=null;
      v_sqlerrm:=null;

      merge into tmp_etldata_log tl
      using
      (
      select t.data_type,
         to_date(s_date,'yyyy-mm-dd') as create_date,
         sum(t.new_data_amount) as new_data_amount,
         sum(t.last_data_amount) as last_data_amount,
         sum(t.total_data_amount) as total_data_amount,
         round(decode(sum(t.last_data_amount),0,0,(sum(t.new_data_amount)-sum(t.last_data_amount))/sum(t.last_data_amount)),4) as rate
    from
    (
    select '评估备案数据' as data_type,
           count(1) as new_data_amount,
           0 as last_data_amount,
           0 as total_data_amount,
           0
    from assess_tradingsh_house h where to_char(h.trading_date,'yyyy-mm-dd')= s_date
    union all
    select '评估备案数据' as data_type,
           0 as new_data_amount,
           count(1) as last_data_amount,
           0 as total_data_amount,
           0
    from assess_tradingsh_house h where trunc(h.trading_date)=trunc (to_date(s_date,'yyyy-mm-dd') -1 )
    union all
    select '评估备案数据' as data_type,
           0 as new_data_amount,
           0 as last_data_amount,
           count(1) as total_data_amount,
           0
    from assess_tradingsh_house h where h.trading_date is not null and to_char(h.trading_date,'yyyy-mm-dd')<= s_date ) t
    group by t.data_type
      ) ss
      on ( tl.data_type=ss.data_type and trunc(tl.create_date)=trunc(ss.create_date) )
      when matched then update set tl.new_data_amount=ss.new_data_amount,tl.last_data_amount=ss.last_data_amount,tl.total_data_amount=ss.total_data_amount,tl.rate=ss.rate
        when not matched then insert (create_date,data_type,new_data_amount,last_data_amount,total_data_amount,rate)
          values(ss.create_date,ss.data_type,ss.new_data_amount,ss.last_data_amount,ss.total_data_amount,ss.rate);

      --只保留30天的数据
      delete from tmp_etldata_log t where t.data_type='评估备案数据'
      and trunc(t.create_date) not between trunc(to_date(s_date,'yyyy-mm-dd')-30) and trunc(to_date(s_date,'yyyy-mm-dd'));

      --结束时间
      select sysdate into v_end_date from dual;

      delete from assessprice.operate_log where proc_name='评估备案数据' and parameter_name=s_date;

      insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
      values(sys_guid(),'评估备案数据',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'成功','');

      commit;

      exception
      when others then
      v_sqlcode:=('错误代码:'||SQLCODE);
      v_sqlerrm:=('错误信息:'||SQLERRM);

      insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
      values(sys_guid(),'评估备案数据',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'失败:'||v_sqlcode,v_sqlerrm);
      commit;
    end;

   --4、计算assess_tradingsh_house表中存量房网签数据每日抽取数据条数及数据表中总条数
    begin
      --开始时间
      select sysdate into v_start_date from dual;
      v_sqlcode:=null;
      v_sqlerrm:=null;

      merge into tmp_etldata_log tl
      using
      (
      select t.data_type,
         to_date(s_date,'yyyy-mm-dd') as create_date,
         sum(t.new_data_amount) as new_data_amount,
         sum(t.last_data_amount) as last_data_amount,
         sum(t.total_data_amount) as total_data_amount,
         round(decode(sum(t.last_data_amount),0,0,(sum(t.new_data_amount)-sum(t.last_data_amount))/sum(t.last_data_amount)),4) as rate
    from
    (
    select '存量房网签数据' as data_type,
           count(1) as new_data_amount,
           0 as last_data_amount,
           0 as total_data_amount,
           0
    from assess_tradingsh_house h where to_char(h.sh_printdate,'yyyy-mm-dd')= s_date
    union all
    select '存量房网签数据' as data_type,
           0 as new_data_amount,
           count(1) as last_data_amount,
           0 as total_data_amount,
           0
    from assess_tradingsh_house h where trunc(h.sh_printdate)=trunc (to_date(s_date,'yyyy-mm-dd') -1 )
    union all
    select '存量房网签数据' as data_type,
           0 as new_data_amount,
           0 as last_data_amount,
           count(1) as total_data_amount,
           0
    from assess_tradingsh_house h where h.sh_printdate is not null and to_char(h.sh_printdate,'yyyy-mm-dd')<= s_date  ) t
    group by t.data_type
      ) ss
      on ( tl.data_type=ss.data_type and trunc(tl.create_date)=trunc(ss.create_date) )
      when matched then update set tl.new_data_amount=ss.new_data_amount,tl.last_data_amount=ss.last_data_amount,tl.total_data_amount=ss.total_data_amount,tl.rate=ss.rate
        when not matched then insert (create_date,data_type,new_data_amount,last_data_amount,total_data_amount,rate)
          values(ss.create_date,ss.data_type,ss.new_data_amount,ss.last_data_amount,ss.total_data_amount,ss.rate);

      --只保留30天的数据
      delete from tmp_etldata_log t where t.data_type='存量房网签数据'
      and trunc(t.create_date) not between trunc(to_date(s_date,'yyyy-mm-dd')-30) and trunc(to_date(s_date,'yyyy-mm-dd'));

      --结束时间
      select sysdate into v_end_date from dual;

      delete from assessprice.operate_log where proc_name='存量房网签数据' and parameter_name=s_date;

      insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
      values(sys_guid(),'存量房网签数据',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'成功','');

      commit;

      exception
      when others then
      v_sqlcode:=('错误代码:'||SQLCODE);
      v_sqlerrm:=('错误信息:'||SQLERRM);

      insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
      values(sys_guid(),'存量房网签数据',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'失败:'||v_sqlcode,v_sqlerrm);
      commit;
    end;

end pro_tmp_etldata_log;
/

