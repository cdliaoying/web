CREATE function FUN_GETREGIONCODE(v_districk IN VARCHAR2,v_data_source IN VARCHAR2) return varchar2
is
  Result varchar2(10);


begin

  select case when v_data_source='510100' and v_districk in ('中和街道','中和镇','中和','华阳镇','华阳街道','东升街道','华阳街道办','西航港开发区','西航港街道','华阳','东升镇','兴隆镇','高新区','高新南区') then '510109'
              when v_data_source='510100' and v_districk ='锦江区' then '510104'
              when v_data_source='510100' and v_districk ='青羊区' then '510105'
              when v_data_source='510100' and v_districk ='金牛区' then '510106'
              when v_data_source='510100' and v_districk ='武侯区' then '510107'
              when v_data_source='510100' and v_districk ='成华区' then '510108'
              when v_data_source!='510100' then v_data_source
         end
  into Result
  from dual;

  return(Result);
end FUN_GETREGIONCODE;
/

