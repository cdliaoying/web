CREATE procedure pro_etl_assesshouse_modify
is
/************************************************************************************************************************************
开发时间：2017-06-28
变更时间：
变更内容：
输入参数：
返回参数：
过程功能：增量新增或者更新房屋评估系统基础数据（建筑区划信息，楼栋信息，房源信息）
************************************************************************************************************************************/

sv_err_sqlcode varchar2(200);
sv_err_SQLERRM varchar2(2000);
v_date date;

v_start_date date;
v_end_date date;

s_date varchar2(20); 

begin
v_date := trunc(sysdate);


--开始时间
select sysdate,to_char(sysdate,'yyyy-mm-dd') into v_start_date,s_date from dual;

--insert into ASSESSPRICE.WORK_LOG values(assessprice.seq_work_log_id.nextval,'pro_etl_assesshouse_modify','','','','',sysdate,'','','pro_etl_assesshouse_modify');


begin
sv_err_sqlcode:=null;
sv_err_SQLERRM:=null;

--开始时间
select sysdate,to_char(sysdate,'yyyy-mm-dd') into v_start_date,s_date from dual;
sv_err_sqlcode:=null;
sv_err_SQLERRM:=null;

---调整房源数据
merge into assessprice.ASSESS_HOUSE a
using  (select h.*,func_get_building_shape(h.projid,h.data_source,h.hno,h.uno) as building_type from estate.housetable h where h.area >0 ) h
on ( a.tableid = h.tableid and a.data_source = h.data_source)
when matched then
  update set
  a.projid = h.projid,
  a.districk = h.districk,
  a.street = h.streetscene,
  a.sno = h.doorplate,
  a.saddno = h.additory_doorplate,
  a.hno = h.hno,
  a.uno = h.uno,
  a.fno = h.fno,
  a.rno = h.rno,
  a.area = nvl(h.area,0),
  a.outarea = nvl(h.outarea,0),
  a.totalarea = nvl(h.area,0)+nvl(h.outarea,0),
  a.suit_type = h.planinfo,
  a.room_struct = h.roomstruct,
  a.struct = h.struct,
  a.orientation = h.roomsunny,
  a.fitment = h.fitmentlevel,
  a.sys_update_time = v_date,
  a.totalprice = h.price,
  a.totaldecprice= h.price - nvl(h.fitmentprice,0),
  a.price = round(h.price/(h.area+h.outarea),2),
  a.decprice = round((h.price - nvl(h.fitmentprice,0))/(h.area+h.outarea),0),
  a.lifestatus = h.lifestatus,
  a.foresyncmark = h.foresyncmark,
  a.licenceid = h.licenceid,
  a.building_type=h.building_type,
  a.usage=h.usage
when not matched then
insert (hou_id,tableid,projid,districk,street,sno,saddno,hno,uno,fno,rno,area,
outarea,totalarea,suit_type,room_struct,struct,
ORIENTATION,FITMENT,is_deleted,version,STATUS,DATA_SOURCE,sys_create_time,sys_update_time,sys_delete_id,
totalprice,totaldecprice,price,decprice,lifestatus,foresyncmark,licenceid,building_type,usage
)
values(assessprice.seq_assess_house_id.nextval,h.tableid,h.projid,h.districk,h.streetscene,h.doorplate,
h.additory_doorplate,h.hno,h.uno,h.fno,h.rno,
h.area,h.outarea,h.area+h.outarea,h.planinfo,h.roomstruct,h.struct,h.roomsunny,h.fitmentlevel,0,1,'有效',h.data_source,v_date,v_date,1,
h.price,h.price - nvl(h.fitmentprice,0),h.price/(h.area+h.outarea),(h.price - nvl(h.fitmentprice,0))/(h.area+h.outarea),h.lifestatus,h.foresyncmark,h.licenceid,h.building_type,h.usage
);
dbms_output.put_line('房源信息 ');


--结束时间
select sysdate into v_end_date from dual;

insert into ASSESSPRICE.WORK_LOG values(assessprice.seq_work_log_id.nextval,'assess_house_modify','','','否','成功',sysdate,'','','assess_house_modify');
delete from assessprice.operate_log where proc_name='assess_house_modify' and parameter_name=s_date;
insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
values(sys_guid(),'assess_house_modify',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'成功','');

commit;

    exception when others then
    dbms_output.put_line('捕获错误 ');
    sv_err_sqlcode:=('错误代码：'||SQLCODE);
    sv_err_SQLERRM:=('错误信息：'||SQLERRM);
insert into ASSESSPRICE.WORK_LOG
values(assessprice.seq_work_log_id.nextval,'assess_house_modify','','','是','失败',sysdate,sv_err_sqlcode,sv_err_SQLERRM,'assess_house_modify');
insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
      values(sys_guid(),'assess_house_modify',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'失败:'||sv_err_sqlcode,sv_err_SQLERRM);
commit;

end;


begin
sv_err_sqlcode:=null;
sv_err_SQLERRM:=null;

--开始时间
select sysdate,to_char(sysdate,'yyyy-mm-dd') into v_start_date,s_date from dual;
sv_err_sqlcode:=null;
sv_err_SQLERRM:=null;

--房源关联建筑区划信息
merge into assessprice.assess_house h
using ( SELECT manual_code,data_source,district_id FROM (
SELECT  a.manual_code,a.data_source,b.district_id,
row_number()over(partition by a.manual_code,a.data_source ORDER BY a.sys_create_time desc) row_id
FROM  wxzj.fix_house a
inner join wxzj.fix_building b on a.building_id = b.id
and regexp_like(a.manual_code,'^[0-9]([0-9])*$')
and a.is_deleted = 0 and b.is_deleted = 0
and a.manual_code is not null
) WHERE row_id = 1) a
on(h.tableid = a.manual_code and h.data_source = a.data_source)
when matched then
  update set h.district_id = a.district_id
;
dbms_output.put_line('房源关联建筑区划信息 ');


--结束时间
select sysdate into v_end_date from dual;

insert into ASSESSPRICE.WORK_LOG values(assessprice.seq_work_log_id.nextval,'房源关联建筑区划信息','','','否','成功',sysdate,'','','房源关联建筑区划信息');
delete from assessprice.operate_log where proc_name='房源关联建筑区划信息' and parameter_name=s_date;
insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
values(sys_guid(),'房源关联建筑区划信息',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'成功','');

commit;

    exception when others then
    dbms_output.put_line('捕获错误 ');
    sv_err_sqlcode:=('错误代码：'||SQLCODE);
    sv_err_SQLERRM:=('错误信息：'||SQLERRM);
insert into ASSESSPRICE.WORK_LOG
values(assessprice.seq_work_log_id.nextval,'房源关联建筑区划信息','','','是','失败',sysdate,sv_err_sqlcode,sv_err_SQLERRM,'房源关联建筑区划信息');
insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
      values(sys_guid(),'房源关联建筑区划信息',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'失败:'||sv_err_sqlcode,sv_err_SQLERRM);
commit;

end;


begin
sv_err_sqlcode:=null;
sv_err_SQLERRM:=null;

--开始时间
select sysdate,to_char(sysdate,'yyyy-mm-dd') into v_start_date,s_date from dual;
sv_err_sqlcode:=null;
sv_err_SQLERRM:=null;

--回写房龄到房源表
merge into assessprice.assess_house a
using (select a.hou_id,b.houseage  from assessprice.assess_house a
inner join assessprice.assess_projects b on a.projid = b.projid and a.data_source = b.data_source
and regexp_like(b.houseage,'^[0-9]*$')
and a.is_deleted = 0
and b.is_deleted = 0 ) b
on(a.hou_id = b.hou_id)
when matched then
  update set a.house_age = b.houseage;


dbms_output.put_line('回写房龄信息 ');


--结束时间
select sysdate into v_end_date from dual;

insert into ASSESSPRICE.WORK_LOG values(assessprice.seq_work_log_id.nextval,'回写房龄信息','','','否','成功',sysdate,'','','回写房龄信息');
delete from assessprice.operate_log where proc_name='回写房龄信息' and parameter_name=s_date;
insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
values(sys_guid(),'回写房龄信息',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'成功','');

commit;

    exception when others then
    dbms_output.put_line('捕获错误 ');
    sv_err_sqlcode:=('错误代码：'||SQLCODE);
    sv_err_SQLERRM:=('错误信息：'||SQLERRM);
insert into ASSESSPRICE.WORK_LOG
values(assessprice.seq_work_log_id.nextval,'回写房龄信息','','','是','失败',sysdate,sv_err_sqlcode,sv_err_SQLERRM,'回写房龄信息');
insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
      values(sys_guid(),'回写房龄信息',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'失败:'||sv_err_sqlcode,sv_err_SQLERRM);
commit;

end;

-------------------------------------------
begin
sv_err_sqlcode:=null;
sv_err_SQLERRM:=null;

--开始时间
select sysdate,to_char(sysdate,'yyyy-mm-dd') into v_start_date,s_date from dual;
sv_err_sqlcode:=null;
sv_err_SQLERRM:=null;

---回写区域编码到房源表
merge into assessprice.assess_house a
using(
select a.hou_id,c.region_code,c.region_name
from assessprice.assess_house a
inner join wxzj.fix_district b on a.district_id = b.id  and b.is_deleted = 0
inner join cdfgora.t_region_d c  on b.region_code = c.region_code
) b
on ( a.hou_id = b.hou_id )
when matched then
  update set a.region = b.region_name,a.region_code = b.region_code
;

update assessprice.assess_house h
set h.region_code = case
when h.data_source = '510100' and h.districk in('锦江区','锦江','3锦江区')  then '510104'
when h.data_source = '510100' and h.districk in('武侯区','武侯','武候区')  then '510107'
when h.data_source = '510100' and h.districk in('青羊区','青羊')  then '510105'
when h.data_source = '510100' and h.districk in('金牛区','.金牛区','金牛')  then '510106'
when h.data_source = '510100' and h.districk in('成华区','.成华区','成华')  then '510108'
when h.data_source = '510100' and h.districk in('高新区','高新','高新区（西区）','西航港街道','西航港街道办事处','西航港开发区','中和','中和街道','中和镇','华阳镇')  then '510109'
else h.data_source end
where h.region_code is null ;


merge into assessprice.assess_house a
using (select a.hou_id,b.region_name from assessprice.assess_house a
inner join  cdfgora.t_region_d b on a.region_code = b.region_code
and a.region is null ) b
on(a.hou_id = b.hou_id)
when matched then
  update set a.region = b.region_name;

dbms_output.put_line('回写区域编码到房源表');


--结束时间
select sysdate into v_end_date from dual;

insert into ASSESSPRICE.WORK_LOG values(assessprice.seq_work_log_id.nextval,'回写区域编码到房源表','','','否','成功',sysdate,'','','回写区域编码到房源表');
delete from assessprice.operate_log where proc_name='回写区域编码到房源表' and parameter_name=s_date;
insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
values(sys_guid(),'回写区域编码到房源表',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'成功','');

commit;

    exception when others then
    dbms_output.put_line('捕获错误 ');
    sv_err_sqlcode:=('错误代码：'||SQLCODE);
    sv_err_SQLERRM:=('错误信息：'||SQLERRM);
insert into ASSESSPRICE.WORK_LOG
values(assessprice.seq_work_log_id.nextval,'回写区域编码到房源表','','','是','失败',sysdate,sv_err_sqlcode,sv_err_SQLERRM,'回写区域编码到房源表');
insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
      values(sys_guid(),'回写区域编码到房源表',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'失败:'||sv_err_sqlcode,sv_err_SQLERRM);
commit;

end;

----------------------------------
begin
sv_err_sqlcode:=null;
sv_err_SQLERRM:=null;

--开始时间
select sysdate,to_char(sysdate,'yyyy-mm-dd') into v_start_date,s_date from dual;
sv_err_sqlcode:=null;
sv_err_SQLERRM:=null;

--回写板块id
merge into assessprice.assess_house a
using(
select a.hou_id,b.block_id from assessprice.ASSESS_HOUSE a
inner join assessprice.assess_block_district_rel b on a.district_id = b.district_id
and a.is_deleted = 0 and b.is_deleted = 0
and a.block_id is null
) b
on(a.hou_id = b.hou_id)
when matched then
  update set a.block_id = b.block_id
;
dbms_output.put_line('回写板块id');


--结束时间
select sysdate into v_end_date from dual;

insert into ASSESSPRICE.WORK_LOG values(assessprice.seq_work_log_id.nextval,'回写板块id','','','否','成功',sysdate,'','','回写板块id');
delete from assessprice.operate_log where proc_name='回写板块id' and parameter_name=s_date;
insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
values(sys_guid(),'回写板块id',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'成功','');

commit;

    exception when others then
    dbms_output.put_line('捕获错误 ');
    sv_err_sqlcode:=('错误代码：'||SQLCODE);
    sv_err_SQLERRM:=('错误信息：'||SQLERRM);
insert into ASSESSPRICE.WORK_LOG
values(assessprice.seq_work_log_id.nextval,'回写板块id','','','是','失败',sysdate,sv_err_sqlcode,sv_err_SQLERRM,'回写板块id');
insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
      values(sys_guid(),'回写板块id',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'失败:'||sv_err_sqlcode,sv_err_SQLERRM);
commit;

end;

--计算估值
assessprice.pro_lj_price_min_max_hand;--全量计算方法1、方法2、方法3
assessprice.pro_assesshouse_value;--根据方法1、方法2、方法3，计算最终估值

--结束时间
select sysdate into v_end_date from dual;

insert into ASSESSPRICE.WORK_LOG values(assessprice.seq_work_log_id.nextval,'pro_etl_assesshouse_modify','','','是','成功',sysdate,sv_err_sqlcode,sv_err_SQLERRM,'pro_etl_assesshouse_modify');
insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
values(sys_guid(),'pro_etl_assesshouse_modify',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'成功:'||sv_err_sqlcode,sv_err_SQLERRM);
commit;

    exception when others then
    dbms_output.put_line('捕获错误 ');
    sv_err_sqlcode:=('错误代码：'||SQLCODE);
    sv_err_SQLERRM:=('错误信息：'||SQLERRM);
insert into ASSESSPRICE.WORK_LOG values(assessprice.seq_work_log_id.nextval,'抽取失败','','','是','失败',sysdate,sv_err_sqlcode,sv_err_SQLERRM,'pro_etl_assesshouse_modify');
insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
values(sys_guid(),'pro_etl_assesshouse_modify',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'失败:'||sv_err_sqlcode,sv_err_SQLERRM);

    commit;



end pro_etl_assesshouse_modify;
/

