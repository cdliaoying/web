CREATE function             FUNC_GET_IND_FACTOR(vn_tableid  IN INTEGER,vn_data_source IN INTEGER)
RETURN VARCHAR2  IS
/************************************************************************************************************************************
开发人员：谢勇
开发时间：2016-11-16
变更时间：
变更内容：
输入参数：房屋唯一号 ，区域编码
返回参数：房屋内部因素得分
过程功能：计算房屋内部因素指标得分
************************************************************************************************************************************/
  v_results VARCHAR2(200);    ---返回值
  sv_err_sqlcode VARCHAR2(200); --错误代码
  sv_err_SQLERRM VARCHAR2(200); --错误信息


begin

select sum(b.keypoint_algorithm) into v_results
from assessprice.assess_house a
inner join assessprice.ASSESS_KEYPOINT b on a.hou_id = b.hou_id
and a.is_deleted = 0 and b.is_deleted = 0 and b.phase =1
and a.tableid = vn_tableid and a.data_source = vn_data_source
;

if v_results is null then
  v_results := 'NULL';
end if;

  return(v_results);
-----------------------------------------------------------------
------异常处理---------------------------------------------------
-----------------------------------------------------------------
EXCEPTION  WHEN OTHERS THEN
    ROLLBACK;
    sv_err_sqlcode:=('错误代码：'||SQLCODE);
    sv_err_SQLERRM:=('错误信息：'||SQLERRM);
    v_results:= '-2';
    DBMS_OUTPUT.PUT_LINE(SQLCODE||'---'||SQLERRM);

    -----向日志表插入数据
--insert into ASSESSPRICE.WORK_LOG values('日志ID','估价ID','房屋ID','是否有错','错误名称',sysdate,sv_err_sqlcode,sv_err_SQLERRM,'模块1');

commit;

  RETURN v_results;

end FUNC_GET_IND_FACTOR;
/

