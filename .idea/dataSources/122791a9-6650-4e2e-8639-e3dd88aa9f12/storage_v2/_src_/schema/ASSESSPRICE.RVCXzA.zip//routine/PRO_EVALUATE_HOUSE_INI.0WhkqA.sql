CREATE procedure pro_evaluate_house_ini
is
/************************************************************************************************************************************
开发时间：2017-07-11
变更时间：
变更内容：
输入参数：
返回参数：
过程功能：全量抽取房源数据
************************************************************************************************************************************/
v_start_date date;
v_end_date date;
s_date varchar2(20);

v_sqlcode varchar2(200);
v_sqlerrm varchar2(2000);

v_projid int;
v_data_source varchar2(20);
cursor mycur_1 is
select distinct projid,data_source
from assessprice.evaluate_PROJ_DATA_SOURCE h --;
where if_flag=0;
-- and rownum<20

begin

    --开始时间
    select sysdate,to_char(sysdate,'yyyy-mm-dd') into v_start_date,s_date from dual;
    --EXECUTE IMMEDIATE 'truncate table assessprice.evaluate_house';

    open mycur_1;
     fetch mycur_1 into v_projid,v_data_source;

     LOOP
       EXIT WHEN mycur_1%NOTFOUND;

       --按栋抽取房源
       merge into assessprice.evaluate_house a
       using ( select h.tableid,h.data_source,h.projid,h.hno,h.uno,h.fno,h.rno,h.area,h.outarea,nvl(h.area,0)+nvl(h.outarea,0) as total_area,h.usage,h.districk,
                h.streetscene,h.doorplate,h.additory_doorplate,h.licenceid,h.struct,
                assessprice.FUN_GETREGIONCODE(h.districk,h.data_source) as region_code,
                assessprice.FUN_GETREGIONname(h.districk,h.data_source) as region_name,
                assessprice.func_get_building_shape(h.projid,h.data_source,h.hno,h.uno) as buildingtype,h.etl_time
         from estate.housetable h
         where h.projid=v_projid and h.data_source=v_data_source and nvl(h.area,0)+nvl(h.outarea,0)>0 ) t
       on ( a.tableid=t.tableid and a.data_source=t.data_source )
       when matched then
       update set a.projid=t.projid,
       a.hno=t.hno,
       a.uno=t.uno,
       a.fno=t.fno,
       a.rno=t.rno,
       a.area=t.area,
       a.outarea=t.outarea,
       a.total_area=t.total_area,
       a.usage=t.usage,
       a.streetscene=t.streetscene,
       a.doorplate=t.doorplate,
       a.additory_doorplate=t.additory_doorplate,
       a.licenceid=t.licenceid,
       a.building_type_code=t.buildingtype,
       a.region_code=t.region_code,
       a.region_name=t.region_name,
       a.building_struct=t.struct,
       a.create_time=t.etl_time
       when not matched then
         insert ( tableid,data_source,projid,hno,uno,fno,rno,area,outarea,total_area,usage,streetscene,doorplate,additory_doorplate,licenceid,building_type_code,region_code,region_name,building_struct,create_time )
        values( t.tableid,t.data_source,t.projid,t.hno,t.uno,t.fno,t.rno,t.area,t.outarea,t.total_area,t.usage,
                t.streetscene,t.doorplate,t.additory_doorplate,t.licenceid,t.buildingtype,t.region_code,t.region_name,t.struct,t.etl_time );

       --按栋更新建筑区域ID
       update assessprice.evaluate_house h
       set h.district_id=(
       select distinct b.district_id
       from wxzj.fix_house a inner join wxzj.fix_building b on a.building_id = b.id and a.data_source=b.data_source
       where a.manual_code=h.tableid and a.data_source=h.data_source and rownum=1
       )
       where h.projid=v_projid and h.data_source=v_data_source;

       update assessprice.evaluate_proj_data_source
       set if_flag=1
       where projid=v_projid and data_source=v_data_source;
       
       commit;

       fetch mycur_1 into v_projid,v_data_source;
    END LOOP;
    CLOSE mycur_1;
    --结束时间
    select sysdate into v_end_date from dual;

    delete from assessprice.operate_log where proc_name='pro_evaluate_house_ini' and parameter_name=s_date;
    insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
    values(sys_guid(),'pro_evaluate_house_ini',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'成功','');
    commit;

    exception
    when others then
    v_sqlcode:=('错误代码:'||SQLCODE);
    v_sqlerrm:=('错误信息:'||SQLERRM);
    insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
    values(sys_guid(),'pro_evaluate_house_ini',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'失败:'||v_sqlcode,v_sqlerrm);
    commit;
end pro_evaluate_house_ini;
/

