CREATE function FUNC_GET_IND_FACTOR_BAK(vn_tableid  IN INTEGER,vn_data_source IN INTEGER) 
RETURN VARCHAR2  IS
/************************************************************************************************************************************
开发人员：谢勇
开发时间：2016-11-16
变更时间：
变更内容：
输入参数：房屋唯一号 ，区域编码
返回参数：房屋内部因素得分
过程功能：计算房屋内部因素指标得分
************************************************************************************************************************************/
  v_results VARCHAR2(2000);    ---返回值
  sv_err_sqlcode VARCHAR2(200); --错误代码
  sv_err_SQLERRM VARCHAR2(200); --错误信息

   cursor vc_job
       is
      select

--楼层差
/*fno = abs(目标房源楼层-round(最大楼层数/2,0))*/
case when fno in('0','1','2') then 110
  when fno in('3','4','5') then 105
    when fno in('6','7','8') then 100
      when fno in('9','10','11') then 95
        when fno in('12','13','14') then 90
          else  110 end KEY_1_1_1,
--朝向
case when ORIENTATION = '西北' then 90
  when ORIENTATION = '西' then 92
    when ORIENTATION = '北' then 96
      when ORIENTATION = '东北' then 98
        when ORIENTATION = '西南' then 102
          when ORIENTATION = '南' then 108
            when ORIENTATION = '西南' then 110
              else 110 end  KEY_1_1_2,
--装修
case when FITMENT = '毛坯' then 100
  when FITMENT = '简装' then 105
    when FITMENT = '精装' then 110
      when FITMENT = '豪华装修' then 115
        else 115 end KEY_1_1_3,
--面积段
case when area+outarea < 50 then 85
  when area+outarea >= 50 and area+outarea < 70 then 90
    when area+outarea >= 70 and area+outarea < 90 then 95
      when area+outarea >= 90 and area+outarea < 110 then 100
        when area+outarea >= 110 and area+outarea < 130 then 105
          when area+outarea >= 130 and area+outarea < 150 then 110
            when area+outarea >= 150 then 115
              else 115 end KEY_1_1_4,
--用地面积
case when LAND_AREA >= 0 and LAND_AREA < 20 then 90
  when LAND_AREA >= 20 and LAND_AREA < 50 then 95
    when LAND_AREA >= 50 and LAND_AREA < 100 then 100
      when LAND_AREA >= 100 and LAND_AREA < 200 then 105
        when LAND_AREA >= 200 then 110
          else 110 end KEY_1_1_5,
--物业费
case when PROPERTY_FEE >= 0 and LAND_AREA < 1 then 85
  when PROPERTY_FEE >= 1 and LAND_AREA < 2 then 90
    when PROPERTY_FEE >= 2 and LAND_AREA < 3 then 95
      when PROPERTY_FEE >= 3 and LAND_AREA < 5 then 100
        when PROPERTY_FEE >= 5 and LAND_AREA < 7 then 110
          when PROPERTY_FEE >= 10 then 115
            else 110 end KEY_1_1_6,
--立面年限
case when FACADE = '瓷砖' and  to_number(to_char(sysdate,'yyyy')) - HOUSE_AGE <=5 then 100
  when FACADE = '瓷砖' and  to_number(to_char(sysdate,'yyyy')) - HOUSE_AGE >5 and to_number(to_char(sysdate,'yyyy')) - HOUSE_AGE <=10 then 95
    when FACADE = '瓷砖' and  to_number(to_char(sysdate,'yyyy')) - HOUSE_AGE >10 then 85
      when FACADE = '涂料' and  to_number(to_char(sysdate,'yyyy')) - HOUSE_AGE <=5  then 95
        when FACADE = '涂料' and  to_number(to_char(sysdate,'yyyy')) - HOUSE_AGE >5 and to_number(to_char(sysdate,'yyyy')) - HOUSE_AGE <=10 then 90
          when FACADE = '涂料' and  to_number(to_char(sysdate,'yyyy')) - HOUSE_AGE >10 then 80
            else 100 end KEY_1_1_7,
--结构
case when STRUCT = '框架' then 100
  when STRUCT = '砖混' then 90
    when STRUCT = '砖木' then 85
      when STRUCT = '简易' then 80
        else 100 end KEY_1_1_8,
--建成年代
case when to_number(to_char(sysdate,'yyyy')) - HOUSE_AGE < 3 then 120
   when to_number(to_char(sysdate,'yyyy')) - HOUSE_AGE >= 3 and to_number(to_char(sysdate,'yyyy')) - HOUSE_AGE < 5  then 110
      when to_number(to_char(sysdate,'yyyy')) - HOUSE_AGE >= 5 and to_number(to_char(sysdate,'yyyy')) - HOUSE_AGE < 10  then 105
        when to_number(to_char(sysdate,'yyyy')) - HOUSE_AGE >= 10 and to_number(to_char(sysdate,'yyyy')) - HOUSE_AGE < 15  then 100
          when to_number(to_char(sysdate,'yyyy')) - HOUSE_AGE >= 15 and to_number(to_char(sysdate,'yyyy')) - HOUSE_AGE < 20  then 95
            when to_number(to_char(sysdate,'yyyy')) - HOUSE_AGE >= 20 and to_number(to_char(sysdate,'yyyy')) - HOUSE_AGE < 30  then 90
              when to_number(to_char(sysdate,'yyyy')) - HOUSE_AGE >= 30  then 80
                else 110 end KEY_1_1_9

from assessprice.assess_house a
inner join assessprice.assess_district b on a.district_id = b.district_id
where a.tableid = vn_tableid and a.data_source = vn_data_source
;
       --定义一个游标变量
       vc_row vc_job%rowtype;

begin

for vc_row in vc_job
  loop

v_results := vc_row.key_1_1_1*0.05+vc_row.key_1_1_2*0.1+vc_row.key_1_1_3*0.1+vc_row.key_1_1_4*0.1+vc_row.key_1_1_4*0.1
+vc_row.key_1_1_5*0.1+vc_row.key_1_1_6*0.2+vc_row.key_1_1_7*0.05+vc_row.key_1_1_8*0.1+vc_row.key_1_1_9*0.2;

  end loop;




  return(v_results);


-----------------------------------------------------------------
------异常处理---------------------------------------------------
-----------------------------------------------------------------
EXCEPTION  WHEN OTHERS THEN
    ROLLBACK;
    sv_err_sqlcode:=('错误代码：'||SQLCODE);
    sv_err_SQLERRM:=('错误信息：'||SQLERRM);
    v_results:= '-2';
    DBMS_OUTPUT.PUT_LINE(SQLCODE||'---'||SQLERRM);

    -----向日志表插入数据
--insert into ASSESSPRICE.WORK_LOG values('日志ID','估价ID','房屋ID','是否有错','错误名称',sysdate,sv_err_sqlcode,sv_err_SQLERRM,'模块1');

commit;

  RETURN v_results;

end FUNC_GET_IND_FACTOR_BAK;
/

