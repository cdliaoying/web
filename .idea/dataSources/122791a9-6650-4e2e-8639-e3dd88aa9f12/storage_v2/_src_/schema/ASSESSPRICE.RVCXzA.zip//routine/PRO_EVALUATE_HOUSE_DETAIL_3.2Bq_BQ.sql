CREATE procedure pro_evaluate_house_detail_3 ( s_tableid in int,s_data_source in varchar2,s_date varchar2 )
is
/************************************************************************************************************************************
开发时间：2017-08-15
变更时间：
变更内容：
输入参数：s_type='ini',初始化，'add'，增量；yyyy-mm-dd
返回参数：
过程功能：评估方法2：根据传入的tableid和data_source计算案例明细
************************************************************************************************************************************/
v_start_date date;
v_end_date date;

v_sqlcode varchar2(200);
v_sqlerrm varchar2(2000);

--建筑区划ID
v_district_id varchar2(50);

v_ii int;
v_jj int; --统计案例数量

v_case_1 int;--案例数1
v_case_3 int;--案例数3

v_tr_price_max decimal(18,4);--均价
v_tr_price_min decimal(18,4);--均价
v_fun_price_3 decimal(18,4);--均价

v_front_row int;--前20%的条数
v_end_row int;--后20%的条数

v_add_lng decimal(15,10);--评估房源坐标
v_add_lat decimal(15,10);--评估房源坐标
v_region varchar2(20); --评估房源区域

v_deal_avgprice decimal(13,2);--备案均价

begin

    --开始时间
    select sysdate into v_start_date from dual;

    v_ii:=0;

    select h.district_id,1
    into v_district_id,v_ii
    from assessprice.assess_house h where h.tableid=s_tableid and h.data_source=s_data_source and rownum=1;
 

    if v_district_id is not null then
      select b.region,b.add_lng,b.add_lat
      into v_region,v_add_lng,v_add_lat
      from assessprice.tmp_lj_district_rel b
      where b.district_id=v_district_id;
    end if;
     
    
    --按district_id，获得LJ成交房源情况,将明细案例数据插入到表：evaluate_house_detail
    --先删除本期评估数据
    delete from assessprice.evaluate_house_detail
    where evaluate_tableid=s_tableid and evaluate_data_source=s_data_source and evaluate_id=s_tableid||'-'||s_data_source||'-'||s_date and proc_name='pro_evaluate_house_detail_3';

    insert into assessprice.evaluate_house_detail (evaluate_data_source,evaluate_tableid,evaluate_id,evaluate_date,case_id,proc_name,
      case_type,case_tableid,case_data_source,his_price,buydate,
      price,total_area,verification_code,rate,
      lj_no,lj_name,usage,decoration,building_year,total_floor,lj_date,
      located_floor,house_type,elevator_num,
      elevator_house,elevator,avgprice)

    --LJ成交房源
    select s_data_source,s_tableid,s_tableid||'-'||s_data_source||'-'||s_date,to_date(s_date,'yyyy-mm-dd'),lth.lj_no,'pro_evaluate_house_detail_3',
        'LJ_TR',0,'' data_source,0 price,sysdate buydate,
        lth.total_tr_price,lth.total_area,lth.verification_code,0,
        lth.lj_no,lth.lj_name,lth.usage_1,lth.decoration,lth.building_year,lth.total_floor,lth.tr_date,
      lth.located_floor,lth.BEDROOM||'室'||lth.livingroom||'厅',lth.elevator_num,
      lth.elevator_house,lth.elevator,v_deal_avgprice
    from assessprice.lj_tr_house lth
    where lth.lj_name in
    (
    select distinct lth.lj_name
    from assessprice.evaluate_verification ev inner join assessprice.assess_house h on ev.tableid_int=h.tableid and ev.data_source=h.data_source
    inner join assessprice.lj_tr_house lth on ev.verifi_code=lth.verification_code
    where h.district_id in ( select h.district_id
    from assessprice.assess_house h
    where h.tableid=s_tableid and h.data_source=s_data_source )

    union

    select distinct lth.lj_name
    from assessprice.evaluate_verification ev inner join assessprice.assess_house h on ev.tableid_int=h.tableid and ev.data_source=h.data_source
    inner join assessprice.lj_listed_house lth on ev.verifi_code=lth.verification_code
    where h.district_id in ( select h.district_id
    from assessprice.assess_house h
    where h.tableid=s_tableid and h.data_source=s_data_source )
    ) and lth.usage_1 like '%住宅%'
    and lth.tr_date between to_date(s_date,'yyyy-mm-dd') - 365 and to_date(s_date,'yyyy-mm-dd') --当期业务时间在-365天以内

    union all

    select s_data_source,s_tableid,s_tableid||'-'||s_data_source||'-'||s_date,to_date(s_date,'yyyy-mm-dd'),w2.lj_no,'pro_evaluate_house_detail_3',
        'LJ_LIST',0,'' data_source,0 price,sysdate buydate,
        w2.estimate_price,w2.total_area,w2.verification_code,0,
        w2.lj_no,w2.lj_name,w2.usage_1,w2.decoration,w2.building_year,w2.total_floor,w2.listed_date,
      w2.located_floor,w2.BEDROOM||'室'||w2.livingroom||'厅',w2.elevator_num,
      w2.elevator_house,w2.elevator,0
    from assessprice.lj_listed_house w2
    where w2.lj_name in
    (
    select distinct lth.lj_name
    from assessprice.evaluate_verification ev inner join assessprice.assess_house h on ev.tableid_int=h.tableid and ev.data_source=h.data_source
    inner join assessprice.lj_tr_house lth on ev.verifi_code=lth.verification_code
    where h.district_id in ( select h.district_id
    from assessprice.assess_house h
    where h.tableid=s_tableid and h.data_source=s_data_source )

    union

    select distinct lth.lj_name
    from assessprice.evaluate_verification ev inner join assessprice.assess_house h on ev.tableid_int=h.tableid and ev.data_source=h.data_source
    inner join assessprice.lj_listed_house lth on ev.verifi_code=lth.verification_code
    where h.district_id in ( select h.district_id
    from assessprice.assess_house h
    where h.tableid=s_tableid and h.data_source=s_data_source )
    ) and w2.usage_1 like '%住宅%'
    and w2.listed_date between to_date(s_date,'yyyy-mm-dd') - 365 and to_date(s_date,'yyyy-mm-dd') --当期业务时间在-365天以内
    ;

    --按LJ_NO去掉重复数据，规则：如果LJ_NO重复，则保留LJ_TR
    delete from assessprice.evaluate_house_detail tt
    where tt.case_type='LJ_LIST'
    and tt.lj_no in (
    select t.lj_no from assessprice.evaluate_house_detail t
    where evaluate_id=s_tableid||'-'||s_data_source||'-'||s_date and proc_name='pro_evaluate_house_detail_3'
    group by t.lj_no
    having count(1)>1
    )
    and evaluate_id=s_tableid||'-'||s_data_source||'-'||s_date and proc_name='pro_evaluate_house_detail_3';

  --统计案例数量
  select count(1)
  into v_case_1
  from assessprice.evaluate_house_detail t
  where t.evaluate_id=s_tableid||'-'||s_data_source||'-'||s_date and proc_name='pro_evaluate_house_detail_3';



  if v_case_1>=2 then
    --如果方法3明细数据>=2，计算评估结果

    if v_case_1>=2 and v_case_1<=4 then
      select min(t.price/t.total_area),max(t.price/t.total_area),sum(t.price)/sum(t.total_area)
      into v_tr_price_min,v_tr_price_max,v_fun_price_3
    from evaluate_house_detail t
    where t.proc_name='pro_evaluate_house_detail_3' and t.evaluate_id=s_tableid||'-'||s_data_source||'-'||s_date and proc_name='pro_evaluate_house_detail_3';
    else
        v_front_row:=0;
        v_end_row:=0;

      select case when ceil(v_case_1*0.1)=1 then 2 else ceil(v_case_1*0.1) end ,floor(v_case_1*0.9) into v_front_row,v_end_row from dual;

        select min(tt.price/tt.total_area),max(tt.price/tt.total_area)
      into v_tr_price_min,v_tr_price_max
      from (
      select t.*,rownum as ts
      from
      (
      select t.evaluate_tableid,t.evaluate_data_source,t.price,t.total_area
      from assessprice.evaluate_house_detail t
      where  evaluate_id=s_tableid||'-'||s_data_source||'-'||s_date and proc_name='pro_evaluate_house_detail_3'
      order by price ) t
      ) tt
      where tt.ts between v_front_row and v_end_row;

      v_front_row:=0;
        v_end_row:=0;
        select case when ceil(v_case_1*0.2)=1 then 2 else ceil(v_case_1*0.2) end ,floor(v_case_1*0.8) into v_front_row,v_end_row from dual;

      select sum(tt.price)/sum(tt.total_area)
      into v_fun_price_3
      from (
      select t.*,rownum as ts
      from
      (
      select t.evaluate_tableid,t.evaluate_data_source,t.price,t.total_area
      from assessprice.evaluate_house_detail t
      where  evaluate_id=s_tableid||'-'||s_data_source||'-'||s_date and proc_name='pro_evaluate_house_detail_3'
      order by price ) t
      ) tt
      where tt.ts between v_front_row and v_end_row;
    end if;

    merge into assessprice.evaluate_house_result t
        using (select s_tableid||'-'||s_data_source||'-'||s_date as assess_id,
                            s_tableid as evaluate_tableid,
                            s_data_source as data_source,
                            v_tr_price_min as tr_price_min,
                            v_tr_price_max tr_price_max,
                              v_case_1 as CASE_NUM_3_IN,
                              v_fun_price_3 as fun_price_3
                  from dual ) h
        on ( t.assess_id=h.assess_id)
        when matched then
        update set t.tr_price_min=h.tr_price_min,t.tr_price_max=h.tr_price_max,t.CASE_NUM_3_IN=h.CASE_NUM_3_IN,t.fun_price_3=h.fun_price_3,CASE_NUM_3_out=0
        when not matched then
        insert( assess_id,evaluate_tableid,data_source,assess_date,tr_price_min,tr_price_max,CASE_NUM_3_IN,fun_price_3)
        values(s_tableid||'-'||s_data_source||'-'||s_date,s_tableid,s_data_source,to_date(s_date,'yyyy-mm-dd'),v_tr_price_min,v_tr_price_max,v_case_1,v_fun_price_3 );
  else
      --如果方法3明细数据<2，按距离计算案例明细
      v_jj:=0;
      select count(1)
      into v_jj
      from tmp_lj_district_rel b
    where b.district_id=v_district_id;

      if v_jj>0 then
        select b.region,b.add_lng,b.add_lat
        into v_region,v_add_lng,v_add_lat
      from tmp_lj_district_rel b
      where b.district_id=v_district_id and rownum=1;  
       
        insert into assessprice.evaluate_house_detail (evaluate_data_source,evaluate_tableid,evaluate_id,evaluate_date,case_id,proc_name,
        case_type,case_tableid,case_data_source,his_price,buydate,
        price,total_area,verification_code,rate,
        lj_no,lj_name,usage,decoration,building_year,total_floor,lj_date,
        located_floor,house_type,elevator_num,
        elevator_house,elevator,avgprice,LJ_DISTINCE)

    --LJ成交房源
    select s_data_source,s_tableid,s_tableid||'-'||s_data_source||'-'||s_date,to_date(s_date,'yyyy-mm-dd'),lth.lj_no,'pro_evaluate_house_detail_3',
        'LJ_TR',0,'' data_source,0 price,sysdate buydate,
        lth.total_tr_price,lth.total_area,lth.verification_code,0,
        lth.lj_no,lth.lj_name,lth.usage_1,lth.decoration,lth.building_year,lth.total_floor,lth.tr_date,
      lth.located_floor,lth.BEDROOM||'室'||lth.livingroom||'厅',lth.elevator_num,
      lth.elevator_house,lth.elevator,v_deal_avgprice,FUNC_GET_EARTH_DISTANCE(tldr.longtitude_add,tldr.latitude_add,v_add_lng,v_add_lat)
    from assessprice.lj_tr_house lth /*inner join assessprice.tmp_lj_district_rel tldr on lth.lj_name=tldr.lj_name*/
    inner join assessprice.lj_project tldr on lth.lj_name=tldr.lj_name
    where lth.lj_name in
    (
    select distinct tldr.lj_name
    from assessprice.lj_project tldr inner join assessprice.lj_tr_house lth on tldr.lj_name=lth.lj_name
    where FUNC_GET_EARTH_DISTANCE(tldr.longtitude_add,tldr.latitude_add,v_add_lng,v_add_lat)<=3000

    union

    select distinct tldr.lj_name
    from assessprice.lj_project tldr inner join assessprice.lj_listed_house lth on tldr.lj_name=lth.lj_name
    where FUNC_GET_EARTH_DISTANCE(tldr.longtitude_add,tldr.latitude_add,v_add_lng,v_add_lat)<=3000
    ) and lth.usage_1 like '%住宅%'
    and lth.tr_date between to_date(s_date,'yyyy-mm-dd') - 365 and to_date(s_date,'yyyy-mm-dd') --当期业务时间在-365天以内

    union all

    select s_data_source,s_tableid,s_tableid||'-'||s_data_source||'-'||s_date,to_date(s_date,'yyyy-mm-dd'),w2.lj_no,'pro_evaluate_house_detail_3',
      'LJ_LIST',0,'' data_source,0 price,sysdate buydate,
      w2.estimate_price,w2.total_area,w2.verification_code,0,
      w2.lj_no,w2.lj_name,w2.usage_1,w2.decoration,w2.building_year,w2.total_floor,w2.listed_date,
      w2.located_floor,w2.BEDROOM||'室'||w2.livingroom||'厅',w2.elevator_num,
      w2.elevator_house,w2.elevator,0,FUNC_GET_EARTH_DISTANCE(tldr.longtitude_add,tldr.latitude_add,v_add_lng,v_add_lat)
    from assessprice.lj_listed_house w2 inner join assessprice.lj_project tldr on w2.lj_name=tldr.lj_name
    where w2.lj_name in
    (
    select distinct tldr.lj_name
    from assessprice.lj_project tldr inner join assessprice.lj_tr_house lth on tldr.lj_name=lth.lj_name
    where FUNC_GET_EARTH_DISTANCE(tldr.longtitude_add,tldr.latitude_add,v_add_lng,v_add_lat)<=3000
    union
    select distinct tldr.lj_name
    from assessprice.lj_project tldr inner join assessprice.lj_listed_house lth on tldr.lj_name=lth.lj_name
    where FUNC_GET_EARTH_DISTANCE(tldr.longtitude_add,tldr.latitude_add,v_add_lng,v_add_lat)<=3000
    ) and w2.usage_1 like '%住宅%'
    and w2.listed_date between to_date(s_date,'yyyy-mm-dd') - 365 and to_date(s_date,'yyyy-mm-dd') --当期业务时间在-365天以内
    and rownum<=30
    ;

    --按LJ_NO去掉重复数据，规则：如果LJ_NO重复，则保留LJ_TR
    --delete from assessprice.evaluate_house_detail tt where tt.lj_distince>3000;

    delete from assessprice.evaluate_house_detail tt
    where tt.case_type='LJ_LIST'
    and tt.lj_no in (
    select t.lj_no from assessprice.evaluate_house_detail t
    where evaluate_id=s_tableid||'-'||s_data_source||'-'||s_date and proc_name='pro_evaluate_house_detail_3'
    group by t.lj_no
    having count(1)>1
    )
    and evaluate_id=s_tableid||'-'||s_data_source||'-'||s_date and proc_name='pro_evaluate_house_detail_3';

    end if;

    --按距离计算后，统计案例数量
    select count(1)
    into v_case_3
    from assessprice.evaluate_house_detail t
    where t.evaluate_id=s_tableid||'-'||s_data_source||'-'||s_date and proc_name='pro_evaluate_house_detail_3';
 

    --按距离计算时，如果案例数量大于15，则按距离+业务日期排序后，取前15条数据
    if v_case_3>15 then
      delete from assessprice.evaluate_house_detail t3
      where t3.uuid in (
      select t2.uuid
      from
      (
      select t1.uuid,rownum as lj_ts
      from
      (
      select t.*
      from assessprice.evaluate_house_detail t
          where t.evaluate_id=s_tableid||'-'||s_data_source||'-'||s_date and proc_name='pro_evaluate_house_detail_3'
          order by t.lj_distince,lj_date desc ) t1 ) t2
      where t2.lj_ts>15 ) ;
      
      v_case_3:=15;
      
    end if; 

    if v_case_3>=2 and v_case_3<=4 then
      select min(t.price/t.total_area),max(t.price/t.total_area),sum(t.price)/sum(t.total_area)
      into v_tr_price_min,v_tr_price_max,v_fun_price_3
    from evaluate_house_detail t
    where t.proc_name='pro_evaluate_house_detail_3' and t.evaluate_id=s_tableid||'-'||s_data_source||'-'||s_date and proc_name='pro_evaluate_house_detail_3';

    elsif v_case_3>=5 then
        v_front_row:=0;
        v_end_row:=0;

      select case when ceil(v_case_3*0.1)=1 then 2 else ceil(v_case_3*0.1) end ,floor(v_case_3*0.9) into v_front_row,v_end_row from dual;
 

        select min(tt.price/tt.total_area),max(tt.price/tt.total_area)
      into v_tr_price_min,v_tr_price_max
      from (
      select t.*,rownum as ts
      from
      (
      select t.evaluate_tableid,t.evaluate_data_source,t.price,t.total_area
      from assessprice.evaluate_house_detail t
      where  evaluate_id=s_tableid||'-'||s_data_source||'-'||s_date and proc_name='pro_evaluate_house_detail_3'
      order by price ) t
      ) tt
      where tt.ts between v_front_row and v_end_row;

      v_front_row:=0;
        v_end_row:=0;
        select case when ceil(v_case_3*0.2)=1 then 2 else ceil(v_case_3*0.2) end ,floor(v_case_3*0.8) into v_front_row,v_end_row from dual;

      select sum(tt.price)/sum(tt.total_area)
      into v_fun_price_3
      from (
      select t.*,rownum as ts
      from
      (
      select t.evaluate_tableid,t.evaluate_data_source,t.price,t.total_area
      from assessprice.evaluate_house_detail t
      where  evaluate_id=s_tableid||'-'||s_data_source||'-'||s_date and proc_name='pro_evaluate_house_detail_3'
      order by price ) t
      ) tt
      where tt.ts between v_front_row and v_end_row;
    end if;

    merge into assessprice.evaluate_house_result t
        using (select s_tableid||'-'||s_data_source||'-'||s_date as assess_id,
                            s_tableid as evaluate_tableid,
                            s_data_source as data_source,
                            v_tr_price_min as tr_price_min,
                            v_tr_price_max tr_price_max,
                            v_case_1 as CASE_NUM_3_IN,
                              v_case_3 as CASE_NUM_3_out,
                              v_fun_price_3 as fun_price_3
                  from dual ) h
        on ( t.assess_id=h.assess_id)
        when matched then
        update set t.tr_price_min=h.tr_price_min,t.tr_price_max=h.tr_price_max,t.CASE_NUM_3_IN=h.CASE_NUM_3_IN,t.fun_price_3=h.fun_price_3,t.case_num_3_out=v_case_3
        when not matched then
        insert( assess_id,evaluate_tableid,data_source,assess_date,tr_price_min,tr_price_max,CASE_NUM_3_IN,CASE_NUM_3_out,fun_price_3)
        values(s_tableid||'-'||s_data_source||'-'||s_date,s_tableid,s_data_source,to_date(s_date,'yyyy-mm-dd'),v_tr_price_min,v_tr_price_max,v_case_1,v_case_3,v_fun_price_3 );
  end if;

    --结束时间
    select sysdate into v_end_date from dual;

    delete from assessprice.operate_log where proc_name='pro_evaluate_house_detail_3' and parameter_name=s_date;
    insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
    values(sys_guid(),'pro_evaluate_house_detail_3',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'成功','');
    commit;

    exception
    when others then
    v_sqlcode:=('错误代码:'||SQLCODE);
    v_sqlerrm:=('错误信息:'||SQLERRM);
    insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
    values(sys_guid(),'pro_evaluate_house_detail_3',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'失败:'||v_sqlcode,v_sqlerrm);
    commit;
end pro_evaluate_house_detail_3;
/

