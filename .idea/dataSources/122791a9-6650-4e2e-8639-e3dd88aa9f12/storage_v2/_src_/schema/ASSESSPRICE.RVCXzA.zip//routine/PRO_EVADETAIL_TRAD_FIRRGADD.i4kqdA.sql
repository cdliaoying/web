CREATE procedure pro_evadetail_trad_firrgadd (
s_tableid in int,s_data_source in varchar2,
v_streetscene_firstreg in varchar2,v_doorplate_firstreg in varchar2,v_additory_firstreg in varchar2,
s_date in varchar2 )
is
/************************************************************************************************************************************
开发时间：2017-07-11
变更时间：
变更内容：
输入参数：
返回参数：
过程功能：按初始登记地址查询评估房源
************************************************************************************************************************************/
v_start_date date;
v_end_date date;

v_sqlcode varchar2(200);
v_sqlerrm varchar2(2000);

begin

    --开始时间
    select sysdate into v_start_date from dual;

    --当天只保留评估房源一次评估结果
    delete assessprice.evaluate_house_detail where evaluate_tableid=s_tableid and data_source=s_data_source and evaluate_date=to_date(s_date,'yyyy-mm-dd') and case_type='初始登记地址评估备案';

    --根据传入的tabelid,data_source查询房源楼盘表地址，初始登记地址，证载地址

    insert into assessprice.evaluate_house_detail (evaluate_tableid,evaluate_id,evaluate_date,case_id,case_type,case_tableid,
    data_source,region_code,buydate,price,total_area,his_price)

    select s_tableid as evaluate_tableid,--需要评估的房源tableid
           s_tableid||'-'||s_data_source||'-'||s_date as assess_id,
           to_date(s_date,'yyyy-mm-dd') as assess_date,
           a.case_id,'初始登记地址评估备案' case_type,
           a.tableid as case_tableid,
           a.data_source,
           a.region_code,
           a.buydate,
           a.price/a.total_area,
           a.total_area,
           h.price/h.total_area as his_price
  from assessprice.evaluate_tradehouse a left join assessprice.evaluate_newhouse h on a.tableid=h.tableid and a.data_source=h.data_source
  where ( a.tableid,a.data_source ) in
  (
   select distinct aa.tableid,aa.data_source
   from assessprice.evaluate_house aa
   where ( decode(aa.streetscene,null,'999999','','999999',aa.streetscene)=v_streetscene_firstreg and
           decode(aa.doorplate,null,'999999','','999999',aa.doorplate)=v_doorplate_firstreg and
           decode(aa.additory_doorplate,null,'999999','','999999',aa.additory_doorplate)=v_additory_firstreg )
     )
    and a.usage in ('住宅','公寓','别墅')
    and a.total_area>0
    ;

    --结束时间
    select sysdate into v_end_date from dual;

    delete from assessprice.operate_log where proc_name='pro_evadetail_trad_firrgadd' and parameter_name=s_date;
    insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
    values(sys_guid(),'pro_evadetail_trad_firrgadd',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'成功','');
    commit;

    exception
    when others then
    v_sqlcode:=('错误代码:'||SQLCODE);
    v_sqlerrm:=('错误信息:'||SQLERRM);
    insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
    values(sys_guid(),'pro_evadetail_trad_firrgadd',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'失败:'||v_sqlcode,v_sqlerrm);
    commit;
end pro_evadetail_trad_firrgadd;
/

