CREATE function             FUNC_GET_REG_FACTOR(vn_tableid  IN INTEGER,vn_data_source IN INTEGER)
RETURN VARCHAR2  IS
/************************************************************************************************************************************
开发人员：谢勇
开发时间：2016-11-16
变更时间：
变更内容：
输入参数：房屋唯一号 ，区域编码
返回参数：房屋外部因素得分
过程功能：计算房屋外部因素指标得分
************************************************************************************************************************************/

  v_results VARCHAR2(2000);    ---返回值
  sv_err_sqlcode VARCHAR2(200); --错误代码
  sv_err_SQLERRM VARCHAR2(200); --错误信息
     cursor vc_job
       is
       select
--医院
case when HOSPITAL = 0 then 15
  when HOSPITAL = 1 then 20
    when HOSPITAL >= 2 then 25
      else 25 end KEY_1_2_1_1,


--学校
case when SCHOOL = 0 then 15
  when SCHOOL = 1 then 20
    when SCHOOL >= 2 then 25
      else 25 end KEY_1_2_1_2,


--银行
case when BANK = 0 then 15
  when BANK = 1 then 18
    when BANK = 2 then 19
      when BANK = 3 then 20
        when BANK = 4 then 21
          when BANK >= 5 then 22
           else 22 end KEY_1_2_1_3,

--超市
case when MARKET = 0 then 15
  when MARKET = 1 then 18
    when MARKET = 2 then 19
      when MARKET = 3 then 20
        when MARKET = 4 then 21
          when MARKET >= 5 then 22
           else 22 end KEY_1_2_1_4,

--饭馆
case when RESTAURANT = 0 then 15
  when RESTAURANT = 1 then 18
    when RESTAURANT = 2 then 19
      when RESTAURANT = 3 then 20
        when RESTAURANT = 4 then 21
          when RESTAURANT >= 5 then 22
            else 22 end KEY_1_2_1_5,


--公交
case when BUS = 0 then 0
   when BUS in (1,2) then 5
     when BUS in (3,4,5) then 10
       when BUS in (6,7,8) then 15
         when BUS in (9,10,11) then 20
           when BUS in (12,13,14) then 25
             when BUS >=15 then 30
               else 30 end KEY_1_2_2_1,

--BRT
case when BRT = 0 then 0
  when BRT = 1 then 30
    else 30 end KEY_1_2_2_2,
--地铁
case when METRO = '无' then 0
  when METRO = '普通' then 30
    when METRO = '换乘' then 40
    else 40 end KEY_1_2_2_3,

--自然环境内容
case when RIVER = '临靠'  then 100
  when RIVER = '附近'then 50
    when RIVER = '较远'  then 0
      else 100 end KEY_1_2_3_1
from assessprice.assess_house a
inner join assessprice.assess_district b on a.district_id = b.district_id
where a.tableid = vn_tableid and a.data_source = vn_data_source
;

          --定义一个游标变量
       vc_row vc_job%rowtype;

begin

for vc_row in vc_job
  loop

v_results := vc_row.key_1_2_1_1*0.35+vc_row.key_1_2_1_2*0.35+vc_row.key_1_2_3_1*0.35+vc_row.key_1_2_1_4*0.35
+vc_row.key_1_2_1_5*0.35+vc_row.key_1_2_2_1*0.35+vc_row.key_1_2_2_2*0.35+vc_row.key_1_2_2_3*0.35
++vc_row.key_1_2_3_1*0.3;

  end loop;



  return(v_results);

-----------------------------------------------------------------
------异常处理---------------------------------------------------
-----------------------------------------------------------------
EXCEPTION  WHEN OTHERS THEN
    ROLLBACK;
    sv_err_sqlcode:=('错误代码：'||SQLCODE);
    sv_err_SQLERRM:=('错误信息：'||SQLERRM);
    v_results:= '-2';
    DBMS_OUTPUT.PUT_LINE(SQLCODE||'---'||SQLERRM);

    -----向日志表插入数据
    -----向日志表插入数据
--insert into ASSESSPRICE.WORK_LOG values('日志ID','估价ID','房屋ID','是否有错','错误名称',sysdate,sv_err_sqlcode,sv_err_SQLERRM,'模块1');
commit;

  RETURN v_results;
end FUNC_GET_REG_FACTOR;
/

