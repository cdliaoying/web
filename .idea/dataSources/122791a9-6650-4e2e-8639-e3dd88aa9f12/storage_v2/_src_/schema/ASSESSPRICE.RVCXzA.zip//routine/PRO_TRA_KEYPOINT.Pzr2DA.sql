CREATE procedure             PRO_TRA_KEYPOINT
is
/************************************************************************************************************************************
开发人员：谢勇
开发时间：2016-11-16
变更时间：
变更内容：
输入参数：
返回参数：
过程功能：增量新增或者更新房屋评估系统房源指标映射数据
************************************************************************************************************************************/

sv_err_sqlcode varchar2(200);
sv_err_SQLERRM varchar2(2000);

begin

----------------------------------------------------------------------------------
----房源映射表数据抽取
-----------------------------------------------------------------------------------

--增量更新楼层差数据
merge into assessprice.ASSESS_KEYPOINT a
using (SELECT a.hou_id,b.keypoint_code,a.fno keypoint_value,b.weight,
0 is_deleted,0 phase,1 version,sysdate sys_create_time,sysdate sys_update_time,1 sys_create_id
FROM assessprice.assess_house a
inner join assessprice.assess_configuration_table b
on 1=1 and a.is_deleted = 0 and b.isactivate = 1 and b.is_deleted = 0
and b.id = 4
and a.sys_update_time >= sysdate-1) b
on(a.hou_id = b.hou_id and a.keypoint_code = 'KEY_1_1_1')
when matched then
  update set
  keypoint_value = b.keypoint_value,
  sys_update_time = b.sys_update_time
when not matched then
insert (id,hou_id,keypoint_code,keypoint_value,weight,is_deleted,phase,version,sys_create_time,sys_update_time,sys_create_id)
values(assessprice.seq_assess_keypoint_id.nextval,b.hou_id,b.keypoint_code,b.keypoint_value,b.weight,b.is_deleted,b.phase,b.version,
b.sys_create_time,b.sys_update_time,b.sys_create_id
)
;


--增量更新朝向数据
merge into assessprice.ASSESS_KEYPOINT a
using (SELECT a.hou_id,b.keypoint_code,a.ORIENTATION keypoint_value,b.weight,
0 is_deleted,0 phase,1 version,sysdate sys_create_time,sysdate sys_update_time,1 sys_create_id
FROM assessprice.assess_house a
inner join assessprice.assess_configuration_table b
on 1=1 and a.is_deleted = 0 and b.isactivate = 1 and b.is_deleted = 0
and b.id = 5
and a.sys_update_time >= sysdate-1) b
on(a.hou_id = b.hou_id  and a.keypoint_code = 'KEY_1_1_2')
when matched then
  update set
  keypoint_value = b.keypoint_value,
  sys_update_time = b.sys_update_time
when not matched then
insert (id,hou_id,keypoint_code,keypoint_value,weight,is_deleted,phase,version,sys_create_time,sys_update_time,sys_create_id)
values(assessprice.seq_assess_keypoint_id.nextval,b.hou_id,b.keypoint_code,b.keypoint_value,b.weight,b.is_deleted,b.phase,b.version,
b.sys_create_time,b.sys_update_time,b.sys_create_id
)
;


--增量更新装修数据
merge into assessprice.ASSESS_KEYPOINT a
using (SELECT a.hou_id,b.keypoint_code,a.FITMENT keypoint_value,b.weight,
0 is_deleted,0 phase,1 version,sysdate sys_create_time,sysdate sys_update_time,1 sys_create_id
FROM assessprice.assess_house a
inner join assessprice.assess_configuration_table b
on 1=1 and a.is_deleted = 0 and b.isactivate = 1 and b.is_deleted = 0
and b.id = 6
and a.sys_update_time >= sysdate-1) b
on(a.hou_id = b.hou_id  and a.keypoint_code = 'KEY_1_1_3')
when matched then
  update set
  keypoint_value = b.keypoint_value,
  sys_update_time = b.sys_update_time
when not matched then
insert (id,hou_id,keypoint_code,keypoint_value,weight,is_deleted,phase,version,sys_create_time,sys_update_time,sys_create_id)
values(assessprice.seq_assess_keypoint_id.nextval,b.hou_id,b.keypoint_code,b.keypoint_value,b.weight,b.is_deleted,b.phase,b.version,
b.sys_create_time,b.sys_update_time,b.sys_create_id
)
;



--增量更新面积段数据
merge into assessprice.ASSESS_KEYPOINT a
using (SELECT a.hou_id,b.keypoint_code,nvl(a.area,0)+nvl(a.outarea,0) keypoint_value,b.weight,
0 is_deleted,0 phase,1 version,sysdate sys_create_time,sysdate sys_update_time,1 sys_create_id
FROM assessprice.assess_house a
inner join assessprice.assess_configuration_table b
on 1=1 and a.is_deleted = 0 and b.isactivate = 1 and b.is_deleted = 0
and b.id = 7
and a.sys_update_time >= sysdate-1) b
on(a.hou_id = b.hou_id  and a.keypoint_code = 'KEY_1_1_4')
when matched then
  update set
  keypoint_value = b.keypoint_value,
  sys_update_time = b.sys_update_time
when not matched then
insert (id,hou_id,keypoint_code,keypoint_value,weight,is_deleted,phase,version,sys_create_time,sys_update_time,sys_create_id)
values(assessprice.seq_assess_keypoint_id.nextval,b.hou_id,b.keypoint_code,b.keypoint_value,b.weight,b.is_deleted,b.phase,b.version,
b.sys_create_time,b.sys_update_time,b.sys_create_id
)
;

--增量更新用地面积段数据
merge into assessprice.ASSESS_KEYPOINT a
using (SELECT a.hou_id,b.keypoint_code,nvl(a.land_area,0) keypoint_value,b.weight,
0 is_deleted,0 phase,1 version,sysdate sys_create_time,sysdate sys_update_time,1 sys_create_id
FROM assessprice.assess_house a
inner join assessprice.assess_configuration_table b
on 1=1 and a.is_deleted = 0 and b.isactivate = 1 and b.is_deleted = 0
and b.id = 8
and a.sys_update_time >= sysdate-1) b
on(a.hou_id = b.hou_id  and a.keypoint_code = 'KEY_1_1_5')
when matched then
  update set
  keypoint_value = b.keypoint_value,
  sys_update_time = b.sys_update_time
when not matched then
insert (id,hou_id,keypoint_code,keypoint_value,weight,is_deleted,phase,version,sys_create_time,sys_update_time,sys_create_id)
values(assessprice.seq_assess_keypoint_id.nextval,b.hou_id,b.keypoint_code,b.keypoint_value,b.weight,b.is_deleted,b.phase,b.version,
b.sys_create_time,b.sys_update_time,b.sys_create_id
)
;


--增量更新物业费数据
merge into assessprice.ASSESS_KEYPOINT a
using (SELECT a.hou_id,b.keypoint_code,nvl(a.land_area,0) keypoint_value,b.weight,
0 is_deleted,0 phase,1 version,sysdate sys_create_time,sysdate sys_update_time,1 sys_create_id
FROM assessprice.assess_house a
inner join assessprice.assess_district c on a.district_id = c.district_id and a.is_deleted = 0 and c.is_deleted = 0
inner join assessprice.assess_configuration_table b on 1=1 and b.isactivate =1 and b.is_deleted = 0
and b.id = 9
WHERE  a.sys_update_time >= sysdate-1) b
on(a.hou_id = b.hou_id  and a.keypoint_code = 'KEY_1_1_6')
when matched then
  update set
  keypoint_value = b.keypoint_value,
  sys_update_time = b.sys_update_time
when not matched then
insert (id,hou_id,keypoint_code,keypoint_value,weight,is_deleted,phase,version,sys_create_time,sys_update_time,sys_create_id)
values(assessprice.seq_assess_keypoint_id.nextval,b.hou_id,b.keypoint_code,b.keypoint_value,b.weight,b.is_deleted,b.phase,b.version,
b.sys_create_time,b.sys_update_time,b.sys_create_id
)
;


--增量更新立面年限数据
merge into assessprice.ASSESS_KEYPOINT a
using (SELECT a.hou_id,b.keypoint_code,a.FACADE keypoint_value,b.weight,
0 is_deleted,0 phase,1 version,sysdate sys_create_time,sysdate sys_update_time,1 sys_create_id
FROM assessprice.assess_house a
inner join assessprice.assess_district c on a.district_id = c.district_id and a.is_deleted = 0 and c.is_deleted = 0
inner join assessprice.assess_configuration_table b on 1=1 and b.isactivate =1 and b.is_deleted = 0
and b.id = 10
WHERE  a.sys_update_time >= sysdate-1) b
on(a.hou_id = b.hou_id  and a.keypoint_code = 'KEY_1_1_7')
when matched then
  update set
  keypoint_value = b.keypoint_value,
  sys_update_time = b.sys_update_time
when not matched then
insert (id,hou_id,keypoint_code,keypoint_value,weight,is_deleted,phase,version,sys_create_time,sys_update_time,sys_create_id)
values(assessprice.seq_assess_keypoint_id.nextval,b.hou_id,b.keypoint_code,b.keypoint_value,b.weight,b.is_deleted,b.phase,b.version,
b.sys_create_time,b.sys_update_time,b.sys_create_id
)
;


--增量更新建筑结构数据
merge into assessprice.ASSESS_KEYPOINT a
using (SELECT a.hou_id,b.keypoint_code,a.struct  keypoint_value,b.weight,
0 is_deleted,0 phase,1 version,sysdate sys_create_time,sysdate sys_update_time,1 sys_create_id
FROM assessprice.assess_house a
inner join assessprice.assess_configuration_table b
on 1=1 and a.is_deleted = 0 and b.isactivate = 1 and b.is_deleted = 0
and b.id = 11
and a.sys_update_time >= sysdate-1) b
on(a.hou_id = b.hou_id  and a.keypoint_code = 'KEY_1_1_8')
when matched then
  update set
  keypoint_value = b.keypoint_value,
  sys_update_time = b.sys_update_time
when not matched then
insert (id,hou_id,keypoint_code,keypoint_value,weight,is_deleted,phase,version,sys_create_time,sys_update_time,sys_create_id)
values(assessprice.seq_assess_keypoint_id.nextval,b.hou_id,b.keypoint_code,b.keypoint_value,b.weight,b.is_deleted,b.phase,b.version,
b.sys_create_time,b.sys_update_time,b.sys_create_id
)
;


--增量更新建成年代数据

merge into assessprice.ASSESS_KEYPOINT a
using (SELECT a.hou_id,b.keypoint_code,a.HOUSE_AGE  keypoint_value,b.weight,
0 is_deleted,0 phase,1 version,sysdate sys_create_time,sysdate sys_update_time,1 sys_create_id
FROM assessprice.assess_house a
inner join assessprice.assess_configuration_table b
on 1=1 and a.is_deleted = 0 and b.isactivate = 1 and b.is_deleted = 0
and b.id = 12
and a.sys_update_time >= sysdate-1) b
on(a.hou_id = b.hou_id  and a.keypoint_code = 'KEY_1_1_9')
when matched then
  update set
  keypoint_value = b.keypoint_value,
  sys_update_time = b.sys_update_time
when not matched then
insert (id,hou_id,keypoint_code,keypoint_value,weight,is_deleted,phase,version,sys_create_time,sys_update_time,sys_create_id)
values(assessprice.seq_assess_keypoint_id.nextval,b.hou_id,b.keypoint_code,b.keypoint_value,b.weight,b.is_deleted,b.phase,b.version,
b.sys_create_time,b.sys_update_time,b.sys_create_id
)
;



insert into ASSESSPRICE.WORK_LOG values(assessprice.seq_work_log_id.nextval，'抽取数据成功','','','否','',sysdate,sv_err_sqlcode,sv_err_SQLERRM,'基础数据抽取模块');
commit;
    exception when others then
    dbms_output.put_line('捕获错误 ');
    sv_err_sqlcode:=('错误代码：'||SQLCODE);
    sv_err_SQLERRM:=('错误信息：'||SQLERRM);
insert into ASSESSPRICE.WORK_LOG values(assessprice.seq_work_log_id.nextval,'捕获错误','','','是否有错','错误名称',sysdate,sv_err_sqlcode,sv_err_SQLERRM,'评估基础数据抽取模块');

    commit;

end PRO_TRA_KEYPOINT;
/

