CREATE procedure PRO_ASSESS
is
/************************************************************************************************************************************
开发人员：谢勇
开发时间：2016-11-16
变更时间：
变更内容：
输入参数：
返回参数：房屋评估单价
过程功能：计算房屋单价
************************************************************************************************************************************/
v_date date;


sv_err_sqlcode varchar2(200);
sv_err_SQLERRM varchar2(2000);
begin
  v_date := trunc(sysdate)-1;

  insert into ASSESSPRICE.WORK_LOG values(assessprice.seq_work_log_id.nextval,'估价计算开始','','','','',sysdate,'','','估价计算模块');

/*****************************************************************
方法一：评估价格
****************************************************************/

merge into assessprice.assess_house a
using(select
a.hou_id,c.price
from  assessprice.assess_house a
inner join assessprice.assess_district b on a.district_id = b.district_id
and a.is_deleted = 0 and b.is_deleted = 0
---tmp_pro_avg_price 这个表为临时过程中间表
inner join tmp_pro_avg_price c on b.district_id = c.district_id
and a.fun_price_1 is null
and a.sys_update_time >= v_date
) b
on(a.hou_id = b.hou_id)
 when matched then
    update set a.fun_price_1 = b.price;


  insert into ASSESSPRICE.WORK_LOG values(assessprice.seq_work_log_id.nextval,'方法一计算成功','','','是','成功',sysdate,'','','估价计算模块');
  commit;
/*****************************************************************
方法二：评估价格
****************************************************************/
----------------------------
--成都市区
----------------------------

--1有块id能匹配
merge into assessprice.assess_house a
using(
select a.hou_id,c.avgprice
from  assessprice.assess_house  a
inner join assessprice.TMP_ASSESSPRICE_BLOCK_PRICE c
on a.block_id = c.block_id and a.data_source = c.ods_data_source
and a.is_deleted = 0
and case when a.totalarea < 50 then 85
  when  a.totalarea >= 50 and a.totalarea < 70 then 90
    when  a.totalarea >= 70 and a.totalarea < 90 then 95
      when  a.totalarea >= 90 and a.totalarea < 110 then 100
        when  a.totalarea >= 110 and a.totalarea < 130 then 105
          when  a.totalarea >= 130 and a.totalarea < 150 then 110
            else 115 end = c.area_type_score
              and a.fun_price_2 is null
              and a.sys_update_time >= v_date

) b
on(a.hou_id = b.hou_id)
when matched then
  update set a.fun_price_2 = b.avgprice;
--有块ID不能匹配
merge into assessprice.assess_house a
using(
select a.hou_id,c.avgprice,row_number()over(partition by a.hou_id order by abs(a.totalarea - c.area_type_area)) row_id
from assessprice.assess_house a
inner join assessprice.TMP_ASSESSPRICE_BLOCK_PRICE c on a.block_id = c.block_id and a.data_source = c.ods_data_source
and a.is_deleted = 0
and a.fun_price_2 is null
and a.sys_update_time >=v_date
) b
on(a.hou_id = b.hou_id and b.row_id =1)
when matched then
  update set a.fun_price_2  = b.avgprice
  ;



--无块id
--1有区域id能匹配
merge into assessprice.assess_house a
using(
select a.hou_id,c.avgprice
from  assessprice.assess_house  a
inner join assessprice.tmp_assess_region_price c
on a.region_code = c.region_id
and a.is_deleted = 0
and case when a.totalarea < 50 then 85
  when  a.totalarea >= 50 and a.totalarea < 70 then 90
    when  a.totalarea >= 70 and a.totalarea < 90 then 95
      when  a.totalarea >= 90 and a.totalarea < 110 then 100
        when  a.totalarea >= 110 and a.totalarea < 130 then 105
          when  a.totalarea >= 130 and a.totalarea < 150 then 110
            else 115 end = c.area_type_score
              and a.fun_price_2 is null
              and a.sys_update_time >=v_date
) b
on(a.hou_id = b.hou_id)
when matched then
  update set a.fun_price_2 = b.avgprice;
--有区域ID不能匹配
merge into assessprice.assess_house a
using(
select a.hou_id,c.avgprice,row_number()over(partition by a.hou_id order by abs(a.totalarea - c.area_type_area)) row_id
from assessprice.assess_house a
inner join assessprice.tmp_assess_region_price c on a.region_code = c.region_id and a.is_deleted = 0
and a.fun_price_2 is null
and a.sys_update_time >=v_date
) b
on(a.hou_id = b.hou_id and b.row_id =1)
when matched then
  update set a.fun_price_2  = b.avgprice
  ;

  insert into ASSESSPRICE.WORK_LOG values(assessprice.seq_work_log_id.nextval,'方法二计算成功','','','是','成功',sysdate,'','','估价计算模块');
  commit;

/*****************************************************************
方法三：评估价格
****************************************************************/
--回写项目均价
merge into assessprice.assess_house h
using(
select c.hou_id,a.avg_price
from  assessprice.tmp_lj_pro_avg_price a
inner join assessprice.tmp_lj_dist_rel b on a.project = b.lj_名称
and a.block = b.lj_小区_板块
and a.status = 1
and b.status = 1
inner join assessprice.assess_house c on b.id = c.district_id and c.is_deleted = 0
and c.sys_update_time >= v_date
) a on(h.hou_id = a.hou_id)
when matched then
  update set h.fun_price_3 = a.avg_price;


--回写板块均价
merge into assessprice.assess_house h
using(
select c.hou_id,a.avgprice
from  assessprice.tmp_lj_block_price a
inner join assessprice.tmp_lj_dist_rel b on a.block = b.lj_小区_板块
and b.status = 1
inner join assessprice.assess_house c on b.id = c.district_id and c.is_deleted = 0
and c.fun_price_3 is null
and c.sys_update_time >= v_date
) a on(h.hou_id = a.hou_id)
when matched then
  update set h.fun_price_3 = a.avgprice;



--回写区域均价
merge into assessprice.assess_house h
using(
select c.hou_id,a.avgprice
from  assessprice.tmp_lj_region_price a
inner join assessprice.assess_house c on a.region = c.region and c.is_deleted = 0
and c.fun_price_3 is null
and c.sys_update_time >= v_date
) a on(h.hou_id = a.hou_id)
when matched then
  update set h.fun_price_3 = a.avgprice;
  insert into ASSESSPRICE.WORK_LOG values(assessprice.seq_work_log_id.nextval,'方法三计算成功','','','是','成功',sysdate,'','','估价计算模块');
  commit;
/*****************************************************************
最终计算价格
****************************************************************/
----最终价格计算
update assessprice.assess_house a
set a.assess_value = round(0.075*a.fun_price_1 + 0.075*a.fun_price_2 + 0.85*a.fun_price_3,2)
,a.assess_valuedate = sysdate
where a.fun_price_1 is not null
and a.fun_price_2 is not null
and a.fun_price_3 is not null
and a.sys_update_time >= v_date
;

update assessprice.assess_house a
set a.assess_value = round( 0.15*a.fun_price_2 + 0.85*a.fun_price_3,2)
,a.assess_valuedate = sysdate
where a.fun_price_1 is  null
and a.fun_price_2 is not null
and a.fun_price_3 is not null
and a.sys_update_time >= v_date
;

update assessprice.assess_house a
set a.assess_value = a.fun_price_3
,a.assess_valuedate = sysdate
where a.fun_price_1 is  null
and a.fun_price_2 is  null
and a.fun_price_3 is not null
and a.sys_update_time >= v_date
;


insert into ASSESSPRICE.WORK_LOG values(assessprice.seq_work_log_id.nextval,'估价计算成功','','','否','成功',sysdate,sv_err_sqlcode,sv_err_SQLERRM,'估价计算模块');
  commit;
    exception when others then
    dbms_output.put_line('捕获错误 ');
    sv_err_sqlcode:=('错误代码：'||SQLCODE);
    sv_err_SQLERRM:=('错误信息：'||SQLERRM);
insert into ASSESSPRICE.WORK_LOG values(assessprice.seq_work_log_id.nextval,'估价计算失败','','','是','失败',sysdate,sv_err_sqlcode,sv_err_SQLERRM,'估计计算模块');

    commit;


end PRO_ASSESS;
/

