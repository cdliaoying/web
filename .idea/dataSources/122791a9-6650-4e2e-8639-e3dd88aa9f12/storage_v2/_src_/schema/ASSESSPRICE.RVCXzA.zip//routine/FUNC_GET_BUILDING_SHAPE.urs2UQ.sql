CREATE function FUNC_GET_BUILDING_SHAPE(v_projid IN VARCHAR2 ,v_data_source IN VARCHAR2,v_hno in VARCHAR2,v_uno in VARCHAR2) RETURN VARCHAR2  IS
  v_building_type VARCHAR2(50);---返回值
  vn_floor int;--楼层
  vn_if_business_office int;--是否有商业或办公
  vn_if_two_three_floor int;--是否有2楼或3楼

/************************************************************************************************************************************
开发人员：tsn
开发时间：2017-04-07
变更时间：计算住宅房屋建筑形态
变更内容：
输入参数：
返回参数：
过程功能：
************************************************************************************************************************************/

begin
  vn_floor:=0;
  v_building_type:='';

  select max(regexp_substr(h.fno,'[0-9]+')+0)
  into vn_floor
  from estate.housetable h
  where h.projid =v_projid and h.data_source =v_data_source
        and decode(h.hno,null,'abcd','','abcd',h.hno)=decode(v_hno,null,'abcd','','abcd',v_hno)
        and h.usage in ('住宅','公寓','别墅','成套住宅');



  --是否有商业或办公
  select count(1)
  into vn_if_business_office
  from
  (
  select distinct h.projid,h.data_source,decode(h.hno,null,'abcd','','abcd',h.hno) as ld
  from estate.housetable h
  where h.projid=v_projid and h.data_source=v_data_source
  and decode(h.hno,null,'abcd','','abcd',h.hno)=decode(v_hno,null,'abcd','','abcd',v_hno)
  and h.usage in ('住宅','公寓','别墅','成套住宅') ) a
  left join
  (
  select distinct h.projid,h.data_source,decode(h.hno,null,'abcd','','abcd',h.hno) as ld
  from estate.housetable h
  where h.projid=v_projid and h.data_source=v_data_source
  and decode(h.hno,null,'abcd','','abcd',h.hno)=decode(v_hno,null,'abcd','','abcd',v_hno)
  and h.usage in ('办公用房','办公','商业用房','商业服务','商业、金融、信息','商业')
  ) b on a.projid=b.projid and a.data_source=b.data_source and a.ld=b.ld
  where length(b.projid)>0;

  --是否有2楼或3楼
  select count(1)
  into vn_if_two_three_floor
  from
  (
  select distinct h.projid,h.data_source,h.hno,h.fno
  from estate.housetable h
  where h.projid=v_projid and h.data_source=v_data_source
  and decode(h.hno,null,'abcd','','abcd',h.hno)=decode(v_hno,null,'abcd','','abcd',v_hno)
  and regexp_substr(h.fno,'[0-9]+') in (2,3) and length(trim(h.fno))=1 ) t ;

  if vn_floor<=3 and vn_if_business_office=1 and vn_if_two_three_floor< 2 then
     select case when tt1.fysl>2 and vn_floor>1 then '2035'
             when tt1.fysl=1 then '2032'
             when tt1.fysl=2 then '2033'
             when tt1.fysl>2 and vn_floor<=1 then '2034' end bslx
     into v_building_type
     from
     (
     select h.projid,h.data_source,
            decode(h.hno,null,'abcd','','abcd',h.hno) as donghao,
            decode(h.uno,null,'abcd','','abcd',h.uno) danyuan,
            count(1) as fysl
   from estate.housetable h
   where h.projid=v_projid and h.data_source=v_data_source
         and decode(h.hno,null,'abcd','','abcd',h.hno)=decode(v_hno,null,'abcd','','abcd',v_hno)
         and decode(h.uno,null,'abcd','','abcd',h.uno)=decode(v_uno,null,'abcd','','abcd',v_uno)
         and h.usage in ('住宅','公寓','别墅','成套住宅')
         and (h.area+h.outarea) >100
     group by h.projid,h.data_source,decode(h.hno,null,'abcd','','abcd',h.hno),
         decode(h.uno,null,'abcd','','abcd',h.uno) ) tt1 ;

     --设置别墅的代码:2036,不分独栋、联排
     v_building_type:='2036';

  else
     v_building_type:= (case when vn_floor <= 7 then '60'
                                 when vn_floor between 8 and 18 then '2030'
                                 when vn_floor between 19 and 33 then '61'
                                 when vn_floor > 33 then '2031' end );
  end if;
  select decode(v_building_type,null,'','','',v_building_type)
  into v_building_type
  from dual ;


return v_building_type;
end FUNC_GET_BUILDING_SHAPE;
/

