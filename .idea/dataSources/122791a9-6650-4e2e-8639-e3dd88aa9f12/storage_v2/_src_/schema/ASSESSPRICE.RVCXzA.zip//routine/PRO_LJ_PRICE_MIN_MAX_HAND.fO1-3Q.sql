CREATE procedure pro_lj_price_min_max_hand
is
/************************************************************************************************************************************
开发：tsn
时间：2017-04-14
变更：计算assess_house表中的均价及最小、最大参考均价，计算结果放在表：assess_house中
内容：
输入参数：
返回参数：房屋评估单价
过程功能：计算房屋单价
************************************************************************************************************************************/
v_start_date date;
v_end_date date;

s_date varchar2(20);

v_sqlcode varchar2(200);
v_sqlerrm varchar2(2000);


begin
  --开始时间
  select sysdate,to_char(sysdate,'yyyy-mm-dd') into v_start_date,s_date from dual;

     --全量方法3

     --1、匹配lj_name+building_type
     merge into assessprice.assess_house h
     using (
     select distinct h.district_id,h.building_type,p.avgprice_min,p.avgprice_max,p.avgprice,p.avgarea,p.day_amount
     from assessprice.assess_house h inner join assessprice.tmp_lj_district_rel t on h.district_id=t.district_id
     inner join assessprice.lj_project_building_price p on t.lj_name=p.lj_name and h.building_type=p.building_type  ) tt
     on (h.district_id=tt.district_id and h.building_type=tt.building_type )
     when matched then
     update set h.tr_price_min=tt.avgprice_min,h.tr_price_max=tt.avgprice_max,h.tr_price=tt.avgprice,h.RISK_BROAD_MID=0,h.lj_avgarea=tt.avgarea,h.day_amount=tt.day_amount ;

     commit;

     --2、匹配lj_name
     merge into assessprice.assess_house h
     using (
     select distinct h.district_id,p.avgprice_min,p.avgprice_max,p.avgprice,p.avgarea,p.day_amount
     from assessprice.assess_house h inner join assessprice.tmp_lj_district_rel t on h.district_id=t.district_id
     inner join assessprice.lj_project_price p on t.lj_name=p.lj_name ) tt
     on (h.district_id=tt.district_id )
     when matched then
     update set h.tr_price_min=tt.avgprice_min,h.tr_price_max=tt.avgprice_max,h.tr_price=tt.avgprice,h.RISK_BROAD_MID=1,h.lj_avgarea=tt.avgarea,h.day_amount=tt.day_amount
     where decode(h.risk_broad_mid,null,5,'',5,h.risk_broad_mid) not in (0)
     ;
     commit;

     --3、匹配block_name+building_type
     merge into assessprice.assess_house h
     using (
     select distinct h.district_id,h.building_type,p.avgprice_min,p.avgprice_max,p.avgprice,p.avgarea,p.day_amount
     from assessprice.assess_house h inner join assessprice.tmp_lj_district_rel t on h.district_id=t.district_id
     inner join assessprice.lj_block_building_price p on t.lj_block=p.lj_block and h.building_type=p.building_type
     where decode(h.risk_broad_mid,null,5,'',5,h.risk_broad_mid) not in (0,1) ) tt
     on (h.district_id=tt.district_id and h.building_type=tt.building_type )
     when matched then
     update set h.tr_price_min=tt.avgprice_min,h.tr_price_max=tt.avgprice_max,h.tr_price=tt.avgprice,h.RISK_BROAD_MID=2,h.lj_avgarea=tt.avgarea,h.day_amount=tt.day_amount
     --where decode(h.risk_broad_mid,null,5,'',5,h.risk_broad_mid) not in (0,1)
     ;
     commit;

     --4、匹配block_name
     merge into assessprice.assess_house h
     using (
     select distinct h.district_id,p.avgprice_min,p.avgprice_max,p.avgprice,p.avgarea,p.day_amount
     from assessprice.assess_house h inner join assessprice.tmp_lj_district_rel t on h.district_id=t.district_id
     inner join assessprice.lj_block_price p on t.lj_block=p.lj_block
     where decode(h.risk_broad_mid,null,5,'',5,h.risk_broad_mid) not in (0,1,2) ) tt
     on (h.district_id=tt.district_id )
     when matched then
     update set h.tr_price_min=tt.avgprice_min,h.tr_price_max=tt.avgprice_max,h.tr_price=tt.avgprice,h.RISK_BROAD_MID=3,h.lj_avgarea=tt.avgarea,h.day_amount=tt.day_amount
     --where decode(h.risk_broad_mid,null,5,'',5,h.risk_broad_mid) not in (0,1,2)
     ;
     commit;


     --5、匹配region_name+building_type
     merge into assessprice.assess_house h
     using (
     select distinct h.building_type,p.region_code,p.avgprice_min,p.avgprice_max,p.avgprice,p.avgarea,p.day_amount
     from assessprice.assess_house h inner join assessprice.lj_region_building_price p on h.region_code=p.region_code and h.building_type=p.building_type
     where decode(h.risk_broad_mid,null,5,'',5,h.risk_broad_mid) not in (0,1,2,3)
      ) tt
     on (h.region_code=tt.region_code and h.building_type=tt.building_type )
     when matched then
     update set h.tr_price_min=tt.avgprice_min,h.tr_price_max=tt.avgprice_max,h.tr_price=tt.avgprice,h.RISK_BROAD_MID=4,h.lj_avgarea=tt.avgarea,h.day_amount=tt.day_amount
     --where decode(h.risk_broad_mid,null,5,'',5,h.risk_broad_mid) not in (0,1,2,3)
     ;
     commit;


     --6、匹配region_name
     merge into assessprice.assess_house h
     using (
     select distinct p.avgprice_min,p.avgprice_max,p.avgprice,p.region_code,p.avgarea,p.day_amount
     from assessprice.assess_house h inner join assessprice.lj_region_price p on h.region_code=p.region_code
     where decode(h.risk_broad_mid,null,5,'',5,h.risk_broad_mid) not in (0,1,2,3,4)
     ) tt
     on (h.region_code=tt.region_code )
     when matched then
     update set h.tr_price_min=tt.avgprice_min,h.tr_price_max=tt.avgprice_max,h.tr_price=tt.avgprice,h.RISK_BROAD_MID=5,h.lj_avgarea=tt.avgarea,h.day_amount=tt.day_amount
     --where decode(h.risk_broad_mid,null,5,'',5,h.risk_broad_mid) not in (0,1,2,3,4)
     ;
     commit;

     --10、更新assess_house表中的NEW_FUN_PRICE_3=tr_price*(     (h.score_house_area+h.score_floor_difference)/(h.score_lj_avgarea+100) )
     update assessprice.assess_house h
     set h.NEW_FUN_PRICE_3 = tr_price*( decode(h.score_house_area,null,100,h.score_house_area)+decode(h.score_floor_difference,null,100,h.score_floor_difference) ) /( decode(h.score_lj_avgarea,null,100,h.score_lj_avgarea)+100 );

     commit;

     --11、判断价格是否低估，高估。风险标识，估价结果。如果小于TR_PRICE_MIN，2--低估，或大于TR_PRICE_MAX，1--高估。在min和max之间，0--正常。
     update assessprice.assess_house h
     set RISK_ASSESS = case when NEW_FUN_PRICE_3<TR_PRICE_MIN then 2
                                         when NEW_FUN_PRICE_3>TR_PRICE_MAX then 1
                                         else 0 end;
     commit;

     --全量计算方法1
     merge into assessprice.assess_house a
   using(select
   a.hou_id,c.price
   from  assessprice.assess_house a
   inner join assessprice.assess_district b on a.district_id = b.district_id
   and a.is_deleted = 0 and b.is_deleted = 0
   ---tmp_pro_avg_price 这个表为临时过程中间表
   inner join tmp_pro_avg_price c on b.district_id = c.district_id
   and a.fun_price_1 is null
   ) b
   on(a.hou_id = b.hou_id)
    when matched then
      update set a.fun_price_1 = b.price;


     --全量计算方法2

   --1有块id能匹配
   merge into assessprice.assess_house a
   using(
    select a.hou_id,c.avgprice
    from  assessprice.assess_house  a
    inner join assessprice.TMP_ASSESSPRICE_BLOCK_PRICE c
    on a.block_id = c.block_id and a.data_source = c.ods_data_source
    and a.is_deleted = 0
    and case when a.totalarea < 50 then 85
      when  a.totalarea >= 50 and a.totalarea < 70 then 90
        when  a.totalarea >= 70 and a.totalarea < 90 then 95
          when  a.totalarea >= 90 and a.totalarea < 110 then 100
            when  a.totalarea >= 110 and a.totalarea < 130 then 105
              when  a.totalarea >= 130 and a.totalarea < 150 then 110
                else 115 end = c.area_type_score
                  and a.fun_price_2 is null
    ) b
    on(a.hou_id = b.hou_id)
    when matched then
      update set a.fun_price_2 = b.avgprice;

    --有块ID不能匹配
    merge into assessprice.assess_house a
    using(
    select a.hou_id,c.avgprice,row_number()over(partition by a.hou_id order by abs(a.totalarea - c.area_type_area)) row_id
    from assessprice.assess_house a
    inner join assessprice.TMP_ASSESSPRICE_BLOCK_PRICE c on a.block_id = c.block_id and a.data_source = c.ods_data_source
    and a.is_deleted = 0
    and a.fun_price_2 is null
    ) b
    on(a.hou_id = b.hou_id and b.row_id =1)
    when matched then
      update set a.fun_price_2  = b.avgprice
      ;

    --无块id
    --1有区域id能匹配
    merge into assessprice.assess_house a
    using(
    select a.hou_id,c.avgprice
    from  assessprice.assess_house  a
    inner join assessprice.tmp_assess_region_price c
    on a.region_code = c.region_id
    and a.is_deleted = 0
    and case when a.totalarea < 50 then 85
      when  a.totalarea >= 50 and a.totalarea < 70 then 90
        when  a.totalarea >= 70 and a.totalarea < 90 then 95
          when  a.totalarea >= 90 and a.totalarea < 110 then 100
            when  a.totalarea >= 110 and a.totalarea < 130 then 105
              when  a.totalarea >= 130 and a.totalarea < 150 then 110
                else 115 end = c.area_type_score
                  and a.fun_price_2 is null
    ) b
    on(a.hou_id = b.hou_id)
    when matched then
      update set a.fun_price_2 = b.avgprice;
    --有区域ID不能匹配
    merge into assessprice.assess_house a
    using(
    select a.hou_id,c.avgprice,row_number()over(partition by a.hou_id order by abs(a.totalarea - c.area_type_area)) row_id
    from assessprice.assess_house a
    inner join assessprice.tmp_assess_region_price c on a.region_code = c.region_id and a.is_deleted = 0
    and a.fun_price_2 is null
    ) b
    on(a.hou_id = b.hou_id and b.row_id =1)
    when matched then
      update set a.fun_price_2  = b.avgprice
      ;

  --结束时间
  select sysdate into v_end_date from dual;

  delete from assessprice.operate_log where proc_name='pro_lj_price_min_max_hand' and parameter_name=s_date;
  insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
  values(sys_guid(),'pro_lj_price_min_max_hand',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'成功','');
  commit;


  exception
  when others then
  v_sqlcode:=('错误代码:'||SQLCODE);
  v_sqlerrm:=('错误信息:'||SQLERRM);
  insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
  values(sys_guid(),'pro_lj_price_min_max_hand',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'失败:'||v_sqlcode,v_sqlerrm);
  commit;
end pro_lj_price_min_max_hand;
/

