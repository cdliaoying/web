CREATE procedure             PRO_ASSESS_FUN_PRICE_2
is
/************************************************************************************************************************************
开发人员：唐遂宁
开发时间：2017-03-30
变更时间：按评估方法1进行计算，计算结果放在表：TMP_ASSESSPRICE_BLOCK_PRICE、TMP_ASSESS_REGION_PRICE_MID、TMP_ASSESS_REGION_PRICE中
变更内容：
输入参数：
返回参数：房屋评估单价
过程功能：计算房屋单价
************************************************************************************************************************************/
sv_err_sqlcode varchar2(200);
sv_err_SQLERRM varchar2(2000);

begin

  /*****************************************************************
    方法二：评估价格
  ****************************************************************/
  EXECUTE IMMEDIATE 'truncate table assessprice.TMP_ASSESSPRICE_BLOCK_PRICE';        --1、最近180天板块备案均价
  EXECUTE IMMEDIATE 'truncate table assessprice.TMP_ASSESS_REGION_PRICE_MID';       --2、最近180天区域均价中间表
  EXECUTE IMMEDIATE 'truncate table assessprice.TMP_ASSESS_REGION_PRICE';               --3、最近180天区域均价表

    --1、最近180天板块备案均价：TMP_ASSESSPRICE_BLOCK_PRICE
    insert into assessprice.TMP_ASSESSPRICE_BLOCK_PRICE (ods_data_source,block_id,block_name,area_type,avgprice,cnt,area_type_name,area_type_score,area_type_area)
    SELECT a.ods_data_source,
                a.block_id,
                a.block_name,
        case when (nvl(h.area,0)+nvl(h.outarea,0)) < 50 then 1
          when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 50 and (nvl(h.area,0)+nvl(h.outarea,0)) < 70 then 2
            when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 70 and (nvl(h.area,0)+nvl(h.outarea,0)) < 90 then 3
              when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 90 and (nvl(h.area,0)+nvl(h.outarea,0)) < 110 then 4
                when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 110 and (nvl(h.area,0)+nvl(h.outarea,0)) < 130 then 5
                  when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 130 and (nvl(h.area,0)+nvl(h.outarea,0)) < 150 then 6
                    else 7 end area_type,
        round(sum(h.price)/sum(nvl(h.area,0)+nvl(h.outarea,0)),2) avgprice,
              count(h.tableid) cnt,
              case when (nvl(h.area,0)+nvl(h.outarea,0)) < 50 then '< 50'
          when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 50 and (nvl(h.area,0)+nvl(h.outarea,0)) < 70 then '50-70'
            when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 70 and (nvl(h.area,0)+nvl(h.outarea,0)) < 90 then '70-90'
              when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 90 and (nvl(h.area,0)+nvl(h.outarea,0)) < 110 then '90-110'
                when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 110 and (nvl(h.area,0)+nvl(h.outarea,0)) < 130 then '110-130'
                  when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 130 and (nvl(h.area,0)+nvl(h.outarea,0)) < 150 then '130-150'
                    else '> 150' end area_type_name,
        case when (nvl(h.area,0)+nvl(h.outarea,0)) < 50 then 85
          when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 50 and (nvl(h.area,0)+nvl(h.outarea,0)) < 70 then 90
            when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 70 and (nvl(h.area,0)+nvl(h.outarea,0)) < 90 then 95
              when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 90 and (nvl(h.area,0)+nvl(h.outarea,0)) < 110 then 100
                when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 110 and (nvl(h.area,0)+nvl(h.outarea,0)) < 130 then 105
                  when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 130 and (nvl(h.area,0)+nvl(h.outarea,0)) < 150 then 110
                    else 115 end area_type_score,
           case when (nvl(h.area,0)+nvl(h.outarea,0)) < 50 then 40
          when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 50 and (nvl(h.area,0)+nvl(h.outarea,0)) < 70 then 60
            when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 70 and (nvl(h.area,0)+nvl(h.outarea,0)) < 90 then 80
              when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 90 and (nvl(h.area,0)+nvl(h.outarea,0)) < 110 then 100
                when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 110 and (nvl(h.area,0)+nvl(h.outarea,0)) < 130 then 120
                  when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 130 and (nvl(h.area,0)+nvl(h.outarea,0)) < 150 then 140
                    else 160 end area_type_area
   FROM estate.contract c inner join estate.housetable h on c.contractid=h.contractid and c.data_source=h.data_source and c.status=500 and h.usage in ('住宅','成套住宅','非成套住宅','公寓','别墅')
   inner join estate.presell p on p.licenceid = h.licenceid and h.data_source = p.data_source and p.phase in ('有效', '查封', '暂停', '注销', '移交', '变更中') and p.licenceid not in ('1023', '1024', '1992', '99999','8535')
   inner join assessprice.assess_block_rel a on p.licenceid = a.licenceid and p.data_source = a.ods_data_source
   where trunc(c.buydate) >= trunc(sysdate - 180)
   GROUP BY a.ods_data_source,a.block_id,a.block_name,
   case when (nvl(h.area,0)+nvl(h.outarea,0)) < 50 then 1
    when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 50 and (nvl(h.area,0)+nvl(h.outarea,0)) < 70 then 2
      when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 70 and (nvl(h.area,0)+nvl(h.outarea,0)) < 90 then 3
        when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 90 and (nvl(h.area,0)+nvl(h.outarea,0)) < 110 then 4
          when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 110 and (nvl(h.area,0)+nvl(h.outarea,0)) < 130 then 5
            when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 130 and (nvl(h.area,0)+nvl(h.outarea,0)) < 150 then 6
              else 7 end,
  case when (nvl(h.area,0)+nvl(h.outarea,0)) < 50 then '< 50'
          when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 50 and (nvl(h.area,0)+nvl(h.outarea,0)) < 70 then '50-70'
            when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 70 and (nvl(h.area,0)+nvl(h.outarea,0)) < 90 then '70-90'
              when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 90 and (nvl(h.area,0)+nvl(h.outarea,0)) < 110 then '90-110'
                when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 110 and (nvl(h.area,0)+nvl(h.outarea,0)) < 130 then '110-130'
                  when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 130 and (nvl(h.area,0)+nvl(h.outarea,0)) < 150 then '130-150'
                    else '> 150' end,
  case when (nvl(h.area,0)+nvl(h.outarea,0)) < 50 then 85
          when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 50 and (nvl(h.area,0)+nvl(h.outarea,0)) < 70 then 90
            when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 70 and (nvl(h.area,0)+nvl(h.outarea,0)) < 90 then 95
              when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 90 and (nvl(h.area,0)+nvl(h.outarea,0)) < 110 then 100
                when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 110 and (nvl(h.area,0)+nvl(h.outarea,0)) < 130 then 105
                  when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 130 and (nvl(h.area,0)+nvl(h.outarea,0)) < 150 then 110
                    else 115 end,
           case when (nvl(h.area,0)+nvl(h.outarea,0)) < 50 then 40
          when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 50 and (nvl(h.area,0)+nvl(h.outarea,0)) < 70 then 60
            when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 70 and (nvl(h.area,0)+nvl(h.outarea,0)) < 90 then 80
              when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 90 and (nvl(h.area,0)+nvl(h.outarea,0)) < 110 then 100
                when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 110 and (nvl(h.area,0)+nvl(h.outarea,0)) < 130 then 120
                  when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 130 and (nvl(h.area,0)+nvl(h.outarea,0)) < 150 then 140
                    else 160 end;

  --2、最近180天区域均价表
  insert into assessprice.TMP_ASSESS_REGION_PRICE (region,region_id,area_type,avgprice,cnt,area_type_name,area_type_score,area_type_area )
  SELECT
    case
    when h.data_source = '510100' and h.districk in('锦江区','锦江','3锦江区')  then '锦江区'
    when h.data_source = '510100' and h.districk in('武侯区','武侯','武候区')  then '武侯区'
    when h.data_source = '510100' and h.districk in('青羊区','青羊')  then '青羊区'
    when h.data_source = '510100' and h.districk in('金牛区','.金牛区','金牛')  then '金牛区'
    when h.data_source = '510100' and h.districk in('成华区','.成华区','成华')  then '成华区'
    when h.data_source = '510100' and h.districk in('高新区','高新','高新区（西区）','西航港街道','西航港街道办事处','西航港开发区','中和','中和街道','中和镇','华阳镇','高新南区')  then '高新区'
    when h.data_source !='510100' then to_char(t1.region_code)
   end as region,
   case
    when h.data_source = '510100' and h.districk in('锦江区','锦江','3锦江区')  then '510104'
    when h.data_source = '510100' and h.districk in('武侯区','武侯','武候区')  then '510107'
    when h.data_source = '510100' and h.districk in('青羊区','青羊')  then '510105'
    when h.data_source = '510100' and h.districk in('金牛区','.金牛区','金牛')  then '510106'
    when h.data_source = '510100' and h.districk in('成华区','.成华区','成华')  then '510108'
    when h.data_source = '510100' and h.districk in('高新区','高新','高新区（西区）','西航港街道','西航港街道办事处','西航港开发区','中和','中和街道','中和镇','华阳镇','高新南区')  then '510109'
    else h.data_source
   end as region_id,
   case when (nvl(h.area,0)+nvl(h.outarea,0)) < 50 then 1
    when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 50 and (nvl(h.area,0)+nvl(h.outarea,0)) < 70 then 2
      when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 70 and (nvl(h.area,0)+nvl(h.outarea,0)) < 90 then 3
        when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 90 and (nvl(h.area,0)+nvl(h.outarea,0)) < 110 then 4
          when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 110 and (nvl(h.area,0)+nvl(h.outarea,0)) < 130 then 5
            when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 130 and (nvl(h.area,0)+nvl(h.outarea,0)) < 150 then 6
              else 7 end area_type,
   round(sum(h.price)/sum(nvl(h.area,0)+nvl(h.outarea,0)),2) avgprice,
   count(h.tableid) cnt,
   case when (nvl(h.area,0)+nvl(h.outarea,0)) < 50 then '< 50'
          when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 50 and (nvl(h.area,0)+nvl(h.outarea,0)) < 70 then '50-70'
            when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 70 and (nvl(h.area,0)+nvl(h.outarea,0)) < 90 then '70-90'
              when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 90 and (nvl(h.area,0)+nvl(h.outarea,0)) < 110 then '90-110'
                when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 110 and (nvl(h.area,0)+nvl(h.outarea,0)) < 130 then '110-130'
                  when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 130 and (nvl(h.area,0)+nvl(h.outarea,0)) < 150 then '130-150'
                    else '> 150' end area_type_name,
   case when (nvl(h.area,0)+nvl(h.outarea,0)) < 50 then 85
          when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 50 and (nvl(h.area,0)+nvl(h.outarea,0)) < 70 then 90
            when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 70 and (nvl(h.area,0)+nvl(h.outarea,0)) < 90 then 95
              when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 90 and (nvl(h.area,0)+nvl(h.outarea,0)) < 110 then 100
                when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 110 and (nvl(h.area,0)+nvl(h.outarea,0)) < 130 then 105
                  when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 130 and (nvl(h.area,0)+nvl(h.outarea,0)) < 150 then 110
                    else 115 end area_type_score,
           case when (nvl(h.area,0)+nvl(h.outarea,0)) < 50 then 40
          when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 50 and (nvl(h.area,0)+nvl(h.outarea,0)) < 70 then 60
            when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 70 and (nvl(h.area,0)+nvl(h.outarea,0)) < 90 then 80
              when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 90 and (nvl(h.area,0)+nvl(h.outarea,0)) < 110 then 100
                when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 110 and (nvl(h.area,0)+nvl(h.outarea,0)) < 130 then 120
                  when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 130 and (nvl(h.area,0)+nvl(h.outarea,0)) < 150 then 140
                    else 160 end area_type_area
  FROM estate.contract c inner join estate.housetable h on c.contractid=h.contractid and c.data_source=h.data_source and c.status=500 and h.usage in ('住宅','成套住宅','非成套住宅','公寓','别墅')
  inner join estate.presell p on p.licenceid = h.licenceid and h.data_source = p.data_source and p.phase in ('有效', '查封', '暂停', '注销', '移交', '变更中') and p.licenceid not in ('1023', '1024', '1992', '99999','8535')
  left join cdfgora.t_region_d t1 on p.data_source=t1.region_code
  where trunc(c.buydate) >= trunc(sysdate - 180)
  GROUP BY
  case
    when h.data_source = '510100' and h.districk in('锦江区','锦江','3锦江区')  then '锦江区'
    when h.data_source = '510100' and h.districk in('武侯区','武侯','武候区')  then '武侯区'
    when h.data_source = '510100' and h.districk in('青羊区','青羊')  then '青羊区'
    when h.data_source = '510100' and h.districk in('金牛区','.金牛区','金牛')  then '金牛区'
    when h.data_source = '510100' and h.districk in('成华区','.成华区','成华')  then '成华区'
    when h.data_source = '510100' and h.districk in('高新区','高新','高新区（西区）','西航港街道','西航港街道办事处','西航港开发区','中和','中和街道','中和镇','华阳镇','高新南区')  then '高新区'
    when h.data_source !='510100' then to_char(t1.region_code)
   end,
   case
    when h.data_source = '510100' and h.districk in('锦江区','锦江','3锦江区')  then '510104'
    when h.data_source = '510100' and h.districk in('武侯区','武侯','武候区')  then '510107'
    when h.data_source = '510100' and h.districk in('青羊区','青羊')  then '510105'
    when h.data_source = '510100' and h.districk in('金牛区','.金牛区','金牛')  then '510106'
    when h.data_source = '510100' and h.districk in('成华区','.成华区','成华')  then '510108'
    when h.data_source = '510100' and h.districk in('高新区','高新','高新区（西区）','西航港街道','西航港街道办事处','西航港开发区','中和','中和街道','中和镇','华阳镇','高新南区')  then '510109'
    else h.data_source
   end,
   case when (nvl(h.area,0)+nvl(h.outarea,0)) < 50 then 1
    when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 50 and (nvl(h.area,0)+nvl(h.outarea,0)) < 70 then 2
      when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 70 and (nvl(h.area,0)+nvl(h.outarea,0)) < 90 then 3
        when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 90 and (nvl(h.area,0)+nvl(h.outarea,0)) < 110 then 4
          when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 110 and (nvl(h.area,0)+nvl(h.outarea,0)) < 130 then 5
            when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 130 and (nvl(h.area,0)+nvl(h.outarea,0)) < 150 then 6
              else 7 end,
   case when (nvl(h.area,0)+nvl(h.outarea,0)) < 50 then '< 50'
          when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 50 and (nvl(h.area,0)+nvl(h.outarea,0)) < 70 then '50-70'
            when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 70 and (nvl(h.area,0)+nvl(h.outarea,0)) < 90 then '70-90'
              when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 90 and (nvl(h.area,0)+nvl(h.outarea,0)) < 110 then '90-110'
                when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 110 and (nvl(h.area,0)+nvl(h.outarea,0)) < 130 then '110-130'
                  when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 130 and (nvl(h.area,0)+nvl(h.outarea,0)) < 150 then '130-150'
                    else '> 150' end,
   case when (nvl(h.area,0)+nvl(h.outarea,0)) < 50 then 85
          when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 50 and (nvl(h.area,0)+nvl(h.outarea,0)) < 70 then 90
            when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 70 and (nvl(h.area,0)+nvl(h.outarea,0)) < 90 then 95
              when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 90 and (nvl(h.area,0)+nvl(h.outarea,0)) < 110 then 100
                when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 110 and (nvl(h.area,0)+nvl(h.outarea,0)) < 130 then 105
                  when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 130 and (nvl(h.area,0)+nvl(h.outarea,0)) < 150 then 110
                    else 115 end,
           case when (nvl(h.area,0)+nvl(h.outarea,0)) < 50 then 40
          when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 50 and (nvl(h.area,0)+nvl(h.outarea,0)) < 70 then 60
            when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 70 and (nvl(h.area,0)+nvl(h.outarea,0)) < 90 then 80
              when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 90 and (nvl(h.area,0)+nvl(h.outarea,0)) < 110 then 100
                when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 110 and (nvl(h.area,0)+nvl(h.outarea,0)) < 130 then 120
                  when  (nvl(h.area,0)+nvl(h.outarea,0)) >= 130 and (nvl(h.area,0)+nvl(h.outarea,0)) < 150 then 140
                    else 160 end;

    delete ASSESSPRICE.WORK_LOG where name='方法二' and trunc(in_date)=trunc(sysdate);
    insert into ASSESSPRICE.WORK_LOG
    values(assessprice.seq_work_log_id.nextval,'方法二','','','是','成功',trunc(sysdate),'','','估价计算模块');
    commit;

    exception when others then
    dbms_output.put_line('捕获错误 ');
    sv_err_sqlcode:=('错误代码：'||SQLCODE);
    sv_err_SQLERRM:=('错误信息：'||SQLERRM);
  insert into ASSESSPRICE.WORK_LOG
  values(assessprice.seq_work_log_id.nextval,'方法二','','','是','失败',trunc(sysdate),sv_err_sqlcode,sv_err_SQLERRM,'估价计算模块');
  commit;
end PRO_ASSESS_FUN_PRICE_2;
/

