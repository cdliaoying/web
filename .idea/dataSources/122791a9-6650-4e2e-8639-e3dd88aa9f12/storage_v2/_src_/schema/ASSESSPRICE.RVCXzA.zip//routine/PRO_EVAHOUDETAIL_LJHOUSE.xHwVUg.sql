CREATE procedure pro_evahoudetail_ljhouse ( s_tableid in int,s_data_source in varchar2,s_date in varchar2 )
is
/************************************************************************************************************************************
开发时间：2017-07-11
变更时间：
变更内容：
输入参数：
返回参数：
过程功能：抽取链家案例数据
************************************************************************************************************************************/
v_start_date date;
v_end_date date;

v_i int ;
v_j int ;
v_k int;

v_sqlcode varchar2(200);
v_sqlerrm varchar2(2000);


--楼盘表地址
v_streetscene_housetable varchar2(200);
v_doorplate_housetable varchar2(60);
v_additory_housetable varchar2(60);

--初始登记地址
v_streetscene_firstreg varchar2(200);
v_doorplate_firstreg varchar2(60);
v_additory_firstreg varchar2(60);


/*
--证载地址
v_streetscene_end varchar2(200);
v_doorplate_end varchar2(60);
v_additory_end varchar2(60);
*/

begin

    --开始时间
    select sysdate into v_start_date from dual;

    --根据传入的tabelid,data_source查询房源楼盘表地址，初始登记地址，证载地址

    v_i:=0;
    v_j:=0;

    select count(1) into v_i
    from estate.housetable h where h.tableid=s_tableid and h.data_source=s_data_source;

    delete from assessprice.evaluate_house_detail where evaluate_tableid=s_tableid and data_source=s_data_source and evaluate_date=to_date(s_date,'yyyy-mm-dd') and case_type in ( 'lj_listed','lj_tr') ;

    ---------------------------------------------------按楼盘表地址取数据
    if v_i>0 then
      --查询该套房源的楼盘表地址
      select decode(h.streetscene,'','999999',null,'999999',h.streetscene),
             decode(h.doorplate,'','999999',null,'999999',h.doorplate),
             decode(h.additory_doorplate,'','999999',null,'999999',h.additory_doorplate)
      into v_streetscene_housetable,v_doorplate_housetable,v_additory_housetable
      from estate.housetable h
      where h.tableid=s_tableid and h.data_source=s_data_source and rownum=1;

      --查询LJ_NAME
      select count(1)
      into v_k
      from evaluate_registeraddress_lj t
      where ( decode(t.streetscene,null,'999999','','999999',t.streetscene) =v_streetscene_housetable
                  and decode(t.doorplate,null,'999999','','999999',t.doorplate) =v_doorplate_housetable
                  and decode(t.additory_doorplate,null,'999999','','999999',t.additory_doorplate) =v_additory_housetable ) ;

      if v_k>0 then
        insert into assessprice.evaluate_house_detail (evaluate_tableid,data_source,evaluate_date,lj_no,buydate,case_type,region_name,price,total_area,usage,decoration,building_year,total_floor,located_floor,house_type,elevator_num,elevator_house,elevator)

        select s_tableid,s_data_source,to_date(s_date,'yyyy-mm-dd'),'lj_listed',t.lj_no,t.listed_date,t.region,t.price,t.total_area,t.usage_1,t.decoration,t.building_year,t.total_floor,t.located_floor,t.bedroom||'室'||t.livingroom||'厅' house_type,t.elevator_num,t.elevator_house,t.elevator
      from assessprice.lj_listed_house t
      where t.lj_name in
        (
        select distinct t.lj_name
          from evaluate_registeraddress_lj t
          where ( decode(t.streetscene,null,'999999','','999999',t.streetscene) =v_streetscene_housetable
                      and decode(t.doorplate,null,'999999','','999999',t.doorplate) =v_doorplate_housetable
                      and decode(t.additory_doorplate,null,'999999','','999999',t.additory_doorplate) =v_additory_housetable )
        )

        union all

        select s_tableid,s_data_source,to_date(s_date,'yyyy-mm-dd'),'lj_tr',t.lj_no,t.tr_date,t.region,t.total_tr_price/t.total_area,t.total_area,t.usage_1,t.decoration,t.building_year,t.total_floor,t.located_floor,t.bedroom||'室'||t.livingroom||'厅'||t.kitchen||'厨'||t.bathroom||'卫' house_type,t.elevator_num,t.elevator_house,t.elevator
        from assessprice.lj_tr_house t
        where t.lj_name in
        (
        select distinct t.lj_name
          from evaluate_registeraddress_lj t
          where ( decode(t.streetscene,null,'999999','','999999',t.streetscene) =v_streetscene_housetable
                      and decode(t.doorplate,null,'999999','','999999',t.doorplate) =v_doorplate_housetable
                      and decode(t.additory_doorplate,null,'999999','','999999',t.additory_doorplate) =v_additory_housetable )
        )
        ;
        end if;
    end if;
    ---------------------------------------------------按楼盘表地址取数据


    ---------------------------------------------------按初始登记取数据

  select count(1) into v_j
  from hregister.registrations r inner join hregister.buildinght b on r.id=b.regiid and r.data_source=b.data_source
  where r.status in (1500,1501) and r.regikind in ('初始登记')
  and b.tableid=s_tableid and b.data_source=s_data_source;

  if v_j>0 then

    --查询该套房源的初始登记地址
    select decode(t.street,'','999999',null,'999999',t.street),
               decode(t.sno,'','999999',null,'999999',t.sno),
               decode(t.saddno,'','999999',null,'999999',t.saddno)
    into v_streetscene_firstreg,v_doorplate_firstreg,v_additory_firstreg
    from
      (
      select b.street,b.sno,b.saddno
      from hregister.registrations r inner join hregister.buildinght b on r.id=b.regiid and r.data_source=b.data_source
      where r.status in (1500,1501) and r.regikind in ('初始登记')
      and b.tableid=s_tableid and b.data_source=s_data_source
      order by r.indate desc ) t
    where rownum=1;

    v_k:=0;
    --查询LJ_NAME
      select count(1)
      into v_k
      from evaluate_registeraddress_lj t
      where ( decode(t.streetscene,null,'999999','','999999',t.streetscene) =v_streetscene_firstreg
                  and decode(t.doorplate,null,'999999','','999999',t.doorplate) =v_doorplate_firstreg
                  and decode(t.additory_doorplate,null,'999999','','999999',t.additory_doorplate) =v_additory_firstreg )
                  ;

      if v_k >0 then
        insert into assessprice.evaluate_house_detail (evaluate_tableid,data_source,evaluate_date,lj_no,buydate,case_type,region_name,price,total_area,usage,decoration,building_year,total_floor,located_floor,house_type,elevator_num,elevator_house,elevator)
        select s_tableid,s_data_source,to_date(s_date,'yyyy-mm-dd'),'lj_listed',t.lj_no,t.listed_date,t.region,t.price,t.total_area,t.usage_1,t.decoration,t.building_year,t.total_floor,t.located_floor,t.bedroom||'室'||t.livingroom||'厅' house_type,t.elevator_num,t.elevator_house,t.elevator
      from assessprice.lj_listed_house t
      where t.lj_name in
      (
      select distinct t.lj_name
        from evaluate_registeraddress_lj t
        where ( decode(t.streetscene,null,'999999','','999999',t.streetscene) =v_streetscene_firstreg
                    and decode(t.doorplate,null,'999999','','999999',t.doorplate) =v_doorplate_firstreg
                    and decode(t.additory_doorplate,null,'999999','','999999',t.additory_doorplate) =v_additory_firstreg )
      )
      union all
      select s_tableid,s_data_source,to_date(s_date,'yyyy-mm-dd'),'lj_tr',t.lj_no,t.tr_date,t.region,t.total_tr_price/t.total_area,t.total_area,t.usage_1,t.decoration,t.building_year,t.total_floor,t.located_floor,t.bedroom||'室'||t.livingroom||'厅'||t.kitchen||'厨'||t.bathroom||'卫' house_type,t.elevator_num,t.elevator_house,t.elevator
      from assessprice.lj_tr_house t
      where t.lj_name in
      (
      select distinct t.lj_name
        from evaluate_registeraddress_lj t
        where ( decode(t.streetscene,null,'999999','','999999',t.streetscene) =v_streetscene_firstreg
                    and decode(t.doorplate,null,'999999','','999999',t.doorplate) =v_doorplate_firstreg
                    and decode(t.additory_doorplate,null,'999999','','999999',t.additory_doorplate) =v_additory_firstreg )
      );
      end if;
    end if;
    ---------------------------------------------------按初始登记取数据

    --结束时间
    select sysdate into v_end_date from dual;

    delete from assessprice.operate_log where proc_name='pro_evahoudetail_ljhouse' and parameter_name=s_date;
    insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
    values(sys_guid(),'pro_evahoudetail_ljhouse',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'成功','');
    commit;

    exception
    when others then
    v_sqlcode:=('错误代码:'||SQLCODE);
    v_sqlerrm:=('错误信息:'||SQLERRM);
    insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
    values(sys_guid(),'pro_evahoudetail_ljhouse',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'失败:'||v_sqlcode,v_sqlerrm);
    commit;
end pro_evahoudetail_ljhouse;
/

