CREATE procedure pro_evaluate_regadd_lj ( s_type in varchar2,s_date in varchar2 )
is
/************************************************************************************************************************************
开发时间：2017-07-11
变更时间：
变更内容：
输入参数：s_type='ini',初始化，'add'，增量；yyyy-mm-dd
返回参数：
过程功能：证载地址与链家项目关系。通过房源核实码建立关联
************************************************************************************************************************************/
v_start_date date;
v_end_date date;

v_sqlcode varchar2(200);
v_sqlerrm varchar2(2000);


begin

    --开始时间
    select sysdate into v_start_date from dual;

    if s_type='ini' then
    --全量抽取证载地址与链家项目关系
    merge into assessprice.evaluate_registeraddress_lj a
    using ( select distinct h.streetscene,h.doorplate,h.additory_doorplate,b.lj_name
         from assessprice.evaluate_house_base_info a inner join estate.housetable h on a.tableid=h.tableid and a.data_source=h.data_source
                inner join assessprice.lj_listed_house b on a.house_resource_code=b.verification_code
         union all
         select distinct bt.street,bt.sno,bt.saddno,b.lj_name
         from assessprice.evaluate_house_base_info a inner join hregister.buildinght bt on a.tableid=bt.tableid and a.data_source=bt.data_source
               inner join hregister.registrations r on r.id=bt.regiid and r.data_source=bt.data_source
               inner join assessprice.lj_listed_house b on a.house_resource_code=b.verification_code
         where r.regitype='所有权登记' and r.regikind='初始登记' and r.phase not in ('撤件','退件','修正')

       ) t  on ( decode( a.streetscene,null,'999999','','999999',a.streetscene ) = decode( t.streetscene,null,'999999','','999999',t.streetscene )  and
                    decode( a.doorplate,null,'999999','','999999',a.doorplate ) = decode( t.doorplate,null,'999999','','999999',t.doorplate )  and
                    decode( a.additory_doorplate,null,'999999','','999999',a.additory_doorplate ) = decode( t.additory_doorplate,null,'999999','','999999',t.additory_doorplate ) and
                    decode( a.lj_name,null,'999999','','999999',a.lj_name ) = decode( t.lj_name,null,'999999','','999999',t.lj_name )
       )
       when not matched then
        insert ( streetscene,doorplate,additory_doorplate,lj_name  )
        values( t.streetscene,t.doorplate,t.additory_doorplate,t.lj_name );
    /*
    else
    --增量抽取证载地址与链家项目关系
    merge into assessprice.evaluate_registeraddress_lj a
    using (  select distinct h.streetscene,h.doorplate,h.additory_doorplate,b.lj_name
          from assessprice.evaluate_house_base_info a inner join estate.housetable h on a.tableid=h.tableid and a.data_source=h.data_source
                 inner join assessprice.lj_listed_house b on a.house_resource_code=b.verification_code
         where h.streetscene is not null and h.etl_time between to_date(s_date||' 00:00:00','yyyy-mm-dd hh24:mi:ss') and to_date(s_date||' 23:59:59','yyyy-mm-dd hh24:mi:ss')
       ) t on ( decode( a.streetscene,null,'999999','','999999',a.streetscene ) = decode( t.streetscene,null,'999999','','999999',t.streetscene )  and
                    decode( a.doorplate,null,'999999','','999999',a.doorplate ) = decode( t.doorplate,null,'999999','','999999',t.doorplate )  and
                    decode( a.additory_doorplate,null,'999999','','999999',a.additory_doorplate ) = decode( t.additory_doorplate,null,'999999','','999999',t.additory_doorplate )
       )
       when not matched then
        insert ( streetscene,doorplate,additory_doorplate,lj_name  )
        values( t.streetscene,t.doorplate,t.additory_doorplate,t.lj_name );
    */

    end if;

    --结束时间
    select sysdate into v_end_date from dual;

    delete from assessprice.operate_log where proc_name='pro_evaluate_regadd_lj' and parameter_name=s_date;
    insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
    values(sys_guid(),'pro_evaluate_regadd_lj',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'成功','');
    commit;

    exception
    when others then
    v_sqlcode:=('错误代码:'||SQLCODE);
    v_sqlerrm:=('错误信息:'||SQLERRM);
    insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
    values(sys_guid(),'pro_evaluate_regadd_lj',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'失败:'||v_sqlcode,v_sqlerrm);
    commit;
end pro_evaluate_regadd_lj;
/

