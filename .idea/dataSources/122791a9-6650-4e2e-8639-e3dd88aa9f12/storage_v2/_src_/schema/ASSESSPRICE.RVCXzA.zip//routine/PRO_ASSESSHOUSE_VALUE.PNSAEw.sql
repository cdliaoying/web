CREATE procedure pro_assesshouse_value
is
/************************************************************************************************************************************
开发人员：唐遂宁
开发时间：2017-04-14
变更时间：计算assess_house表中的最终价格及评估日期，计算结果放在表：assess_house中
变更内容：
输入参数：
返回参数：房屋评估单价
过程功能：计算房屋单价
************************************************************************************************************************************/
v_start_date date;
v_end_date date;

s_date varchar2(20);

v_sqlcode varchar2(200);
v_sqlerrm varchar2(2000);


begin
    --开始时间
    select sysdate,to_char(sysdate,'yyyy-mm-dd') into v_start_date,s_date from dual;

    --1、fun_price_1,fun_price_2,new_fun_price_3都不为空的情况
    update assessprice.assess_house h
  set h.assess_value=round(0.075*h.fun_price_1 + 0.075*h.fun_price_2 + 0.85*h.new_fun_price_3,2),
      h.assess_valuedate=sysdate
  where h.fun_price_1 is not null and h.fun_price_2 is not null and h.new_fun_price_3 is not null;
  commit;

  --2、fun_price_1 is null ,fun_price_2 is not null ,new_fun_price_3 is not null
    update assessprice.assess_house h
  set h.assess_value=round(0.15*h.fun_price_2 + 0.85*h.new_fun_price_3,2),
      h.assess_valuedate=sysdate
  where h.fun_price_1 is null and h.fun_price_2 is not null and h.new_fun_price_3 is not null;
  commit;

  --3、fun_price_1 is not null ,fun_price_2 is null ,new_fun_price_3 is not null
    update assessprice.assess_house h
  set h.assess_value=round(0.15*h.fun_price_1 + 0.85*h.new_fun_price_3,2),
      h.assess_valuedate=sysdate
  where h.fun_price_1 is not null and h.fun_price_2 is null and h.new_fun_price_3 is not null;
  commit;

  --4、fun_price_1 is not null ,fun_price_2 is not null ,new_fun_price_3 is null
    update assessprice.assess_house h
  set h.assess_value=round(0.5*h.fun_price_1 + 0.5*h.fun_price_2,2),
      h.assess_valuedate=sysdate
  where h.fun_price_1 is not null and h.fun_price_2 is not null and h.new_fun_price_3 is null;
  commit;

  --5、fun_price_1 is not null ,fun_price_2 is null ,new_fun_price_3 is null
    update assessprice.assess_house h
  set h.assess_value=round(h.fun_price_1,2),
      h.assess_valuedate=sysdate
  where h.fun_price_1 is not null and h.fun_price_2 is null and h.new_fun_price_3 is null;
  commit;

  --6、fun_price_1 is null ,fun_price_2 is not null ,new_fun_price_3 is null
    update assessprice.assess_house h
  set h.assess_value=round(h.fun_price_2,2),
      h.assess_valuedate=sysdate
  where h.fun_price_1 is null and h.fun_price_2 is not null and h.new_fun_price_3 is null;
  commit;

  --7、fun_price_1 is null ,fun_price_2 is null ,new_fun_price_3 is not null
    update assessprice.assess_house h
  set h.assess_value=round(h.new_fun_price_3,2),
      h.assess_valuedate=sysdate
  where h.fun_price_1 is null and h.fun_price_2 is null and h.new_fun_price_3 is not null;
  commit;

  --8、fun_price_1 is null ,fun_price_2 is null ,new_fun_price_3 is null
    update assessprice.assess_house h
  set h.RISK_BROAD_MID=6,h.assess_valuedate=sysdate
  where h.fun_price_1 is null and h.fun_price_2 is null and h.new_fun_price_3 is not null;
  commit;
    
    insert into assessprice.his_assess_house(hou_id,tableid,data_source,assess_value,assess_valuedate,indate)
    select h.hou_id,h.tableid,h.data_source,h.assess_value,h.assess_valuedate,sysdate 
    from assess_house h;
    
    --结束时间
    select sysdate into v_end_date from dual;

    delete from assessprice.operate_log where proc_name='pro_assesshouse_value' and parameter_name=s_date;
    insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
    values(sys_guid(),'pro_assesshouse_value',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'成功','');
    commit;

    exception
    when others then
    v_sqlcode:=('错误代码:'||SQLCODE);
    v_sqlerrm:=('错误信息:'||SQLERRM);
    insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
    values(sys_guid(),'pro_assesshouse_value',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'失败:'||v_sqlcode,v_sqlerrm);
    commit;
end pro_assesshouse_value;
/

