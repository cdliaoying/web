CREATE procedure PRO_lj_block_building_price
is
/************************************************************************************************************************************
开发人员：唐遂宁
开发时间：2017-04-14
变更时间：计算项目与建筑形态的均价及最小、最大参考均价，计算结果放在表：lj_block_building_price中
变更内容：
输入参数：
返回参数：房屋评估单价
过程功能：计算房屋单价
************************************************************************************************************************************/
sv_err_sqlcode varchar2(200);
sv_err_SQLERRM varchar2(2000);

v_lj_block_1 varchar2(255);
v_lj_block_2 varchar2(255);

v_building_house_1 varchar2(10);
v_building_house_2 varchar2(10);

v_cjts_1 int;
v_cjts_2 int;

v_cjts int;

v_row_10 int;--排除的10%的数据
v_day  int;--天数
v_exit_flag int;

--在180天内符合要求的数据

cursor mycur_1 is
select trim(t.lj_block),
       trim(t.building_house),
       count(1) as cjts
from assessprice.lj_tr_house t
where trunc(t.tr_date) between trunc(sysdate-180) and trunc(sysdate) and t.usage_1 in ('普通住宅','别墅')
group by trim(t.lj_block),trim(t.building_house)
having count(1)>=5;

--在180天内不符合要求的数据

cursor mycur_2 is
select trim(t.lj_block),
       trim(t.building_house),
       count(1) as cjts
from assessprice.lj_tr_house t
where trunc(t.tr_date) between trunc(sysdate-180) and trunc(sysdate) and t.usage_1 in ('普通住宅','别墅')
group by trim(t.lj_block),trim(t.building_house)
having count(1)<5;

begin

  /*****************************************************************
    计算项目与建筑形态的均价及最小、最大参考均价。在链家数据导入lj_tr_house、lj_listed_house后处理
  ****************************************************************/

  EXECUTE IMMEDIATE 'truncate table assessprice.lj_block_building_price';        --、链家项目名称、建筑形态成交均价

  v_day:=180;
  v_exit_flag:=0;

  --处理在180天内符合要求的数据
  begin
     open mycur_1;
     fetch mycur_1 into v_lj_block_1,v_building_house_1,v_cjts_1;

     LOOP
       EXIT WHEN mycur_1%NOTFOUND;

       --需要排除的数据条数
       select round(v_cjts_1*0.1)
       into v_row_10
       from dual;

     --计算最小参考均价
     merge into assessprice.lj_block_building_price h
     using(
             select tt.lj_block,tt.building_house,tt.cjjj,tt.building_type
         from
          (
          select t.*,rownum as ss
          from
          (
          select t.lj_block,t.building_house,t.total_tr_price,t.total_area,t.total_tr_price/t.total_area as cjjj,d1.code as building_type
          from assessprice.lj_tr_house t left join assessprice.assess_parameter_dict d1 on t.building_house=d1.name and d1.parameter_type='build_shape_house'
          where t.lj_block=v_lj_block_1 and t.building_house=v_building_house_1 and t.usage_1 in ('普通住宅','别墅')
          and trunc(t.tr_date) between trunc(sysdate-180) and trunc(sysdate)
          order by cjjj ) t ) tt
          where tt.ss=v_row_10+1
    ) a on (h.lj_block = a.lj_block and h.building_house=a.building_house )
    when matched then update set h.avgprice_min = a.cjjj,h.day_amount=180
    when not matched then
    insert (lj_block,building_house,avgprice_min,building_type,day_amount)
    values(a.lj_block,a.building_house,a.cjjj,a.building_type,180) ;

     --计算最大参考均价
     merge into assessprice.lj_block_building_price h
     using(
             select tt.lj_block,tt.building_house,tt.cjjj,tt.building_type
         from
          (
          select t.*,rownum as ss
          from
          (
          select t.lj_block,t.building_house,t.total_tr_price,t.total_area,t.total_tr_price/t.total_area as cjjj,d1.code as building_type
          from assessprice.lj_tr_house t left join assessprice.assess_parameter_dict d1 on t.building_house=d1.name and d1.parameter_type='build_shape_house'
          where t.lj_block=v_lj_block_1 and t.building_house=v_building_house_1
          and trunc(t.tr_date) between trunc(sysdate-180) and trunc(sysdate) and t.usage_1 in ('普通住宅','别墅')
          order by cjjj ) t ) tt
          where tt.ss= (v_cjts_1 - v_row_10)
    ) a on (h.lj_block = a.lj_block and h.building_house=a.building_house )
    when matched then update set h.avgprice_max = a.cjjj,h.day_amount=180
    when not matched then
    insert (lj_block,building_house,avgprice_max,building_type,day_amount)
    values(a.lj_block,a.building_house,a.cjjj,a.building_type,180) ;

     --计算参考均价
       merge into assessprice.lj_block_building_price h
     using(
             select aaa.lj_block,aaa.building_house,aaa.building_type,sum(aaa.total_tr_price)/sum(aaa.total_area) as cjjj,sum(aaa.total_area)/count(1) as avgarea
         from
         (
         select tt.lj_block,tt.building_house,tt.cjjj,tt.total_tr_price,tt.total_area,tt.ss,tt.building_type
                 from
                  (
                  select t.*,rownum as ss
                  from
                  (
                  select t.lj_block,t.building_house,t.total_tr_price,t.total_area,t.total_tr_price/t.total_area as cjjj,d1.code as building_type
                  from assessprice.lj_tr_house t left join assessprice.assess_parameter_dict d1 on t.building_house=d1.name and d1.parameter_type='build_shape_house'
                  where t.lj_block=v_lj_block_1 and t.building_house=v_building_house_1
                  and trunc(t.tr_date) between trunc(sysdate-180) and trunc(sysdate) and t.usage_1 in ('普通住宅','别墅')
                  order by cjjj ) t ) tt
                  where tt.ss between (v_row_10+1) and (v_cjts_1 - v_row_10) ) aaa
         group by aaa.lj_block,aaa.building_house,aaa.building_type

    ) a on (h.lj_block = a.lj_block and h.building_house=a.building_house )
    when matched then update set h.avgprice = a.cjjj,h.avgarea=a.avgarea,h.day_amount=180
    when not matched then
    insert (lj_block,building_house,avgprice,building_type,avgarea,day_amount)
    values(a.lj_block,a.building_house,a.cjjj,a.building_type,a.avgarea,180) ;

       fetch mycur_1 into v_lj_block_1,v_building_house_1,v_cjts_1;
     END LOOP;
     CLOSE mycur_1;
  end;

  --处理在180天内不符合要求的数据
  begin

     open mycur_2;
     fetch mycur_2 into v_lj_block_2,v_building_house_2,v_cjts_2;

     LOOP
       EXIT WHEN mycur_2%NOTFOUND;

       begin
             LOOP
             Exit When(v_exit_flag=1 or v_day>360);
             select count(1)
                    into v_cjts
             from
              (
              select t.lj_block,
                   t.building_house,
                   t.total_tr_price,
                   t.total_area
              from assessprice.lj_tr_house t
              where trunc(t.tr_date) between trunc(sysdate - v_day) and trunc(sysdate)
              and t.lj_block=v_lj_block_2 and t.building_house=v_building_house_2 and t.usage_1 in ('普通住宅','别墅')
              union all
              select t.lj_block,t.building_house,t.estimate_price,t.total_area
              from assessprice.lj_listed_house t
              where trunc(t.listed_date) between trunc(sysdate - v_day) and trunc(sysdate)
              and t.lj_block=v_lj_block_2 and t.building_house=v_building_house_2 ) t;

              --当达到房源要求时，退出
              if v_cjts>=5 then
                v_exit_flag:=1;
              elsif v_cjts<5 and v_day<=360 then
                v_day:=v_day+30;
              end if;

              --dbms_output.put_line('v_lj_block_2'||v_lj_block_2||' ,v_building_house_2= '||v_building_house_2||', v_day='||v_day||' ,v_cjts='||v_cjts);

           END LOOP;
     end;

     --dbms_output.put_line('v_lj_block_2'||v_lj_block_2||' ,v_building_house_2= '||v_building_house_2||', v_day='||v_day||' ,v_cjts='||v_cjts);

     --房源符合数量才进行计算
     if v_cjts>=5 then
         --需要排除的数据条数
         select round(v_cjts*0.1)
         into v_row_10
         from dual;
         --计算最小参考均价
         merge into assessprice.lj_block_building_price h
         using(
               select tt.lj_block,tt.building_house,tt.cjjj,tt.building_type
               from
              (
              select t.*,rownum as ss
              from
              (

              select t.lj_block,t.building_house,t.total_tr_price,t.total_area,t.total_tr_price/t.total_area as cjjj,d1.code as building_type
              from assessprice.lj_tr_house t left join assessprice.assess_parameter_dict d1 on t.building_house=d1.name and d1.parameter_type='build_shape_house'
              where t.lj_block=v_lj_block_2 and t.building_house=v_building_house_2 and trunc(t.tr_date) between trunc(sysdate-v_day) and trunc(sysdate) and t.usage_1 in ('普通住宅','别墅')
          union all
            select t.lj_block,t.building_house,t.estimate_price,t.total_area,t.estimate_price/t.total_area as cjjj,d1.code as building_type
          from assessprice.lj_listed_house t left join assessprice.assess_parameter_dict d1 on t.building_house=d1.name and d1.parameter_type='build_shape_house'
          where t.lj_block=v_lj_block_2 and t.building_house=v_building_house_2 and trunc(t.listed_date) between trunc(sysdate-v_day) and trunc(sysdate)
          order by cjjj

              ) t ) tt
              where tt.ss=v_row_10+1
        ) a on (h.lj_block = a.lj_block and h.building_house=a.building_house )
        when matched then update set h.avgprice_min = a.cjjj,h.day_amount=v_day
        when not matched then
        insert (lj_block,building_house,avgprice_min,building_type,day_amount)
        values(a.lj_block,a.building_house,a.cjjj,a.building_type,v_day) ;

        --dbms_output.put_line('v_lj_block_2='||v_lj_block_2||' ,v_building_house_2= '||v_building_house_2||', v_day='||v_day||' ,v_cjts='||v_cjts||' v_row_10= '||v_row_10);

         --计算最大参考均价
         merge into assessprice.lj_block_building_price h
         using(
           select tt.lj_block,tt.building_house,tt.cjjj,tt.building_type
           from
            (
            select t.*,rownum as ss
            from
            (

                select t.lj_block,t.building_house,t.total_tr_price,t.total_area,t.total_tr_price/t.total_area as cjjj,d1.code as building_type
              from assessprice.lj_tr_house t  left join assessprice.assess_parameter_dict d1 on t.building_house=d1.name and d1.parameter_type='build_shape_house'
              where t.lj_block=v_lj_block_2 and t.building_house=v_building_house_2 and trunc(t.tr_date) between trunc(sysdate-v_day) and trunc(sysdate) and t.usage_1 in ('普通住宅','别墅')
          union all
            select t.lj_block,t.building_house,t.estimate_price,t.total_area,t.estimate_price/t.total_area as cjjj,d1.code as building_type
          from assessprice.lj_listed_house t left join assessprice.assess_parameter_dict d1 on t.building_house=d1.name and d1.parameter_type='build_shape_house'
          where t.lj_block=v_lj_block_2 and t.building_house=v_building_house_2 and trunc(t.listed_date) between trunc(sysdate-v_day) and trunc(sysdate)
          order by cjjj

            ) t ) tt
            where tt.ss= (v_cjts - v_row_10)
          ) a on (h.lj_block = a.lj_block and h.building_house=a.building_house )
          when matched then update set h.avgprice_max = a.cjjj,h.day_amount=v_day
          when not matched then
          insert (lj_block,building_house,avgprice_max,building_type,day_amount)
          values(a.lj_block,a.building_house,a.cjjj,a.building_type,v_day) ;

         --计算参考均价
           merge into assessprice.lj_block_building_price h
         using(
                 select aaa.lj_block,aaa.building_house,sum(aaa.total_tr_price)/sum(aaa.total_area) as cjjj,aaa.building_type,sum(aaa.total_area)/count(1) as avgarea
             from
             (
             select tt.lj_block,tt.building_house,tt.cjjj,tt.total_tr_price,tt.total_area,tt.ss,tt.building_type
                     from
                      (
                      select t.*,rownum as ss
                      from
                      (

              select t.lj_block,t.building_house,t.total_tr_price,t.total_area,t.total_tr_price/t.total_area as cjjj,d1.code as building_type
              from assessprice.lj_tr_house t  left join assessprice.assess_parameter_dict d1 on t.building_house=d1.name and d1.parameter_type='build_shape_house'
              where t.lj_block=v_lj_block_2 and t.building_house=v_building_house_2 and trunc(t.tr_date) between trunc(sysdate-v_day) and trunc(sysdate) and t.usage_1 in ('普通住宅','别墅')
          union all
            select t.lj_block,t.building_house,t.estimate_price,t.total_area,t.estimate_price/t.total_area as cjjj,d1.code as building_type
          from assessprice.lj_listed_house t  left join assessprice.assess_parameter_dict d1 on t.building_house=d1.name and d1.parameter_type='build_shape_house'
          where t.lj_block=v_lj_block_2 and t.building_house=v_building_house_2 and trunc(t.listed_date) between trunc(sysdate-v_day) and trunc(sysdate)
          order by cjjj

                      ) t ) tt
                      where tt.ss between (v_row_10+1) and (v_cjts - v_row_10) ) aaa
             group by aaa.lj_block,aaa.building_house,aaa.building_type

        ) a on (h.lj_block = a.lj_block and h.building_house=a.building_house )
        when matched then update set h.avgprice = a.cjjj,h.avgarea=a.avgarea,h.day_amount=v_day
        when not matched then
        insert (lj_block,building_house,avgprice,building_type,avgarea,day_amount)
        values(a.lj_block,a.building_house,a.cjjj,a.building_type,a.avgarea,v_day) ;

     end if;

       --重新设定初始值
       v_exit_flag:=0;
       v_day:=180;

       fetch mycur_2 into v_lj_block_2,v_building_house_2,v_cjts_2;
     END LOOP;
     CLOSE mycur_2;
  end;

  delete ASSESSPRICE.WORK_LOG where name='PRO_lj_block_building_price' and trunc(in_date)=trunc(sysdate);
  insert into ASSESSPRICE.WORK_LOG
  values(assessprice.seq_work_log_id.nextval,'PRO_lj_block_building_price','','','是','成功',trunc(sysdate),'','','PRO_lj_block_building_price');
  commit;

  exception when others then
  dbms_output.put_line('捕获错误 ');
  sv_err_sqlcode:=('错误代码：'||SQLCODE);
  sv_err_SQLERRM:=('错误信息：'||SQLERRM);
  insert into ASSESSPRICE.WORK_LOG
  values(assessprice.seq_work_log_id.nextval,'PRO_lj_block_building_price','','','是','失败',trunc(sysdate),sv_err_sqlcode,sv_err_SQLERRM,'PRO_lj_block_building_price');
  commit;
end PRO_lj_block_building_price;
/

