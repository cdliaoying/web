CREATE function func_get_houseavgprice( s_tableid in int,s_data_source in varchar2 ) RETURN DECIMAL
IS
  --楼盘表地址
v_streetscene_housetable varchar2(200);
v_doorplate_housetable varchar2(60);
v_additory_housetable varchar2(60);

--初始登记地址
v_streetscene_firstreg varchar2(200);
v_doorplate_firstreg varchar2(60);
v_additory_firstreg varchar2(60);

v_i int;
v_j int;
v_k int;

v_ii int;
v_jj int;
v_kk int;

v_front_row int;--前20%的条数
v_end_row int;--后20%的条数

v_deal_avgprice decimal(13,2);--备案均价

--v_str varchar2(100);

begin

    v_i:=0;
    v_j:=0;
    v_k:=0;

    --先清空临时表
    
    --v_str := 'truncate table assessprice.evaluate_newhouse_tmp';
    
    --execute immediate v_str;
    
    --EXECUTE IMMEDIATE 'truncate table assessprice.evaluate_newhouse_tmp';

    --根据tableid,data_source，查询本栋前后90天内的新房备案
    select count(1)
    into v_i
  from assessprice.evaluate_newhouse a inner join
  (
  select h.projid,h.data_source,h.building_type_code,h.buydate
  from evaluate_newhouse h
  where h.tableid=13828808 and h.data_source='510100' and h.usage in ('住宅','公寓','别墅')
  ) b on a.projid=b.projid and a.data_source=b.data_source and a.building_type_code=b.building_type_code
  where abs(ceil(a.buydate-b.buydate))<=90 and a.total_area>0;

  dbms_output.put_line(v_i);

  if v_i>=3 then
    --处理同栋前后90内达标的情况
    --assessprice.evaluate_newhouse_tmp
    insert into assessprice.evaluate_newhouse_tmp(tableid,data_source,price,total_area)
    select distinct a.tableid,a.data_source,a.price,a.total_area
      from assessprice.evaluate_newhouse a inner join
      (
      select h.projid,h.data_source,h.building_type_code,h.buydate
      from evaluate_newhouse h
      where h.tableid=13828808 and h.data_source='510100' and h.usage in ('住宅','公寓','别墅')
      ) b on a.projid=b.projid and a.data_source=b.data_source and a.building_type_code=b.building_type_code
      where abs(ceil(a.buydate-b.buydate))<=90 and a.total_area>0;
    else
           --如果同栋前后90内未达3套的情况时，按预售证进行处理
           select count(1)
       into v_j
       from assessprice.evaluate_newhouse a inner join
      (
      select distinct h.licenceid,h.data_source,h.building_type_code,h.buydate
      from evaluate_newhouse h
      where h.tableid=13828808 and h.data_source='510100' and h.usage in ('住宅','公寓','别墅')
      ) b on a.licenceid=b.licenceid and a.data_source=b.data_source and a.building_type_code=b.building_type_code
      where abs(ceil(a.buydate-b.buydate))<=90 and a.total_area>0;

      if v_j>=3 then
        --处理同栋前后90内未达3套，但预售证达标的情况
        insert into assessprice.evaluate_newhouse_tmp(tableid,data_source,price,total_area)
            select distinct a.tableid,a.data_source,a.price,a.total_area
          from assessprice.evaluate_newhouse a inner join
         (
         select distinct h.licenceid,h.data_source,h.building_type_code,h.buydate
         from evaluate_newhouse h
         where h.tableid=13828808 and h.data_source='510100' and h.usage in ('住宅','公寓','别墅')
         ) b on a.licenceid=b.licenceid and a.data_source=b.data_source and a.building_type_code=b.building_type_code
         where abs(ceil(a.buydate-b.buydate))<=90 and a.total_area>0;

      else
          --处理同栋前后90内未达3套，预售证也未达标的情况，查询出此房源证载地址并备案的情况
          v_ii:=0;
          v_jj:=0;

          select count(1) into v_ii
          from estate.housetable h where h.tableid=s_tableid and h.data_source=s_data_source;

          if v_ii>0 then
          --查询该套房源的楼盘表地址
          select decode(h.streetscene,'','999999',null,'999999',h.streetscene),
                 decode(h.doorplate,'','999999',null,'999999',h.doorplate),
                 decode(h.additory_doorplate,'','999999',null,'999999',h.additory_doorplate)
          into v_streetscene_housetable,v_doorplate_housetable,v_additory_housetable
        from estate.housetable h
        where h.tableid=s_tableid and h.data_source=s_data_source
        and rownum=1;
        end if;

        select count(1) into v_jj
        from hregister.registrations r inner join hregister.buildinght b on r.id=b.regiid and r.data_source=b.data_source
        where r.status in (1500,1501) and r.regikind in ('初始登记')
        and b.tableid=s_tableid and b.data_source=s_data_source;

        if v_jj>0 then
        --查询该套房源的初始登记地址
          select decode(t.street,'','999999',null,'999999',t.street),
                 decode(t.sno,'','999999',null,'999999',t.sno),
                 decode(t.saddno,'','999999',null,'999999',t.saddno)
          into v_streetscene_firstreg,v_doorplate_firstreg,v_additory_firstreg
        from
        (
        select b.street,b.sno,b.saddno
        from hregister.registrations r inner join hregister.buildinght b on r.id=b.regiid and r.data_source=b.data_source
        where r.status in (1500,1501) and r.regikind in ('初始登记')
        and b.tableid=s_tableid and b.data_source=s_data_source
        order by r.indate desc ) t
        where rownum=1;
        end if;

        --通过证载地址取已备案的房源情况
        select count(1) into v_k
        from assessprice.evaluate_newhouse aa
        where ( decode(aa.streetscene,null,'999999','','999999',aa.streetscene)=v_streetscene_housetable and
                 decode(aa.doorplate,null,'999999','','999999',aa.doorplate)=v_doorplate_housetable and
                 decode(aa.additory_doorplate,null,'999999','','999999',aa.additory_doorplate)=v_additory_housetable )
           or ( decode(aa.streetscene,null,'999999','','999999',aa.streetscene)=v_streetscene_firstreg and
                 decode(aa.doorplate,null,'999999','','999999',aa.doorplate)=v_doorplate_firstreg and
                 decode(aa.additory_doorplate,null,'999999','','999999',aa.additory_doorplate)=v_additory_firstreg );

        if v_k>3 then
          insert into assessprice.evaluate_newhouse_tmp(tableid,data_source,price,total_area)
          select distinct aa.tableid,aa.data_source,aa.price,aa.total_area
          from assessprice.evaluate_newhouse aa
          where ( decode(aa.streetscene,null,'999999','','999999',aa.streetscene)=v_streetscene_housetable and
                   decode(aa.doorplate,null,'999999','','999999',aa.doorplate)=v_doorplate_housetable and
                   decode(aa.additory_doorplate,null,'999999','','999999',aa.additory_doorplate)=v_additory_housetable )
             or ( decode(aa.streetscene,null,'999999','','999999',aa.streetscene)=v_streetscene_firstreg and
                   decode(aa.doorplate,null,'999999','','999999',aa.doorplate)=v_doorplate_firstreg and
                   decode(aa.additory_doorplate,null,'999999','','999999',aa.additory_doorplate)=v_additory_firstreg );
        end if;
      end if;
    end if;

    select count(1) into v_kk from assessprice.evaluate_newhouse_tmp;

    if v_kk>=3 then
      --如果新房备案大于3套，才进行计算备案均价
        select case when ceil(v_kk*0.2)=1 then 2 else ceil(v_kk*0.2) end ,floor(v_kk*0.8) into v_front_row,v_end_row from dual;

      select sum(tt.price)/sum(tt.total_area)
      into v_deal_avgprice
    from (
    select t.*,rownum as ts
    from
    (
    select tableid,data_source,price,total_area
    from assessprice.evaluate_newhouse_tmp order by price/total_area ) t ) tt
    where tt.ts between v_front_row and v_end_row;
    end if;
    
return v_deal_avgprice;
end func_get_houseavgprice;
/

