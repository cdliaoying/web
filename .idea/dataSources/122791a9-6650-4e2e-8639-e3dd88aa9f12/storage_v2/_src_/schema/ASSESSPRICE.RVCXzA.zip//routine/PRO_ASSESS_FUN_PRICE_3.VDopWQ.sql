CREATE procedure PRO_ASSESS_FUN_PRICE_3
is
/************************************************************************************************************************************
开发人员：唐遂宁
开发时间：2017-03-30
变更时间：按评估方法1进行计算，计算结果放在表：tmp_lj_pro_avg_price、tmp_lj_district_rel、tmp_lj_region_price、tmp_lj_block_price中
变更内容：
输入参数：
返回参数：房屋评估单价
过程功能：计算房屋单价
************************************************************************************************************************************/
sv_err_sqlcode varchar2(200);
sv_err_SQLERRM varchar2(2000);

begin

  /*****************************************************************
    方法三：评估价格。在链家数据导入tmp_lj_pro_avg_price后处理
  ****************************************************************/

  EXECUTE IMMEDIATE 'truncate table assessprice.tmp_lj_region_price';        --3、链家区域成交均价

    --1、在链家数据导入tmp_lj_pro_avg_price后处理：tmp_lj_pro_avg_price
    update assessprice.tmp_lj_pro_avg_price a set a.status = 1,a.id = rownum where  1=1 ;
  update assessprice.tmp_lj_pro_avg_price a set a.status = 0 where  a.avg_price in('暂无均价信息','0','#N/A');
  update assessprice.tmp_lj_pro_avg_price a set a.status = 0
  where a.id in(
  select id
  from (
      select a.id ,a.project,a.region,row_number()over(partition by a.project,a.region order by id desc) row_id
      from assessprice.tmp_lj_pro_avg_price a
      )
    where row_id >=2);
  commit;

    update assessprice.tmp_lj_pro_avg_price  a
  set a.region =
  case
  when a.region like '%成华%' then '成华区'
  when a.region like '%龙泉驿%' then '龙泉驿区'
  when a.region like '%青羊%' then '青羊区'
  when a.region like '%武侯%' then '武侯区'
  when a.region like '%高新%' then '高新区'
  when a.region like '%温江%' then '温江区'
  when a.region like '%锦江%' then '锦江区'
  when a.region like '%双流%' then '双流县'
  when a.region like '%金牛%' then '金牛区'
  when a.region like '%新都%' then '新都区'
  when a.region like '%郫都%' then '郫县'
  else a.region end
  where 1=1;

    --2、在链家数据导入TMP_LJ_DISTRICT_REL后处理：TMP_LJ_DISTRICT_REL
    update assessprice.TMP_LJ_DISTRICT_REL  a
  set a.region =
  case
  when a.region like '%成华%' then '成华区'
  when a.region like '%龙泉驿%' then '龙泉驿区'
  when a.region like '%青羊%' then '青羊区'
  when a.region like '%武侯%' then '武侯区'
  when a.region like '%高新%' then '高新区'
  when a.region like '%温江%' then '温江区'
  when a.region like '%锦江%' then '锦江区'
  when a.region like '%双流%' then '双流县'
  when a.region like '%金牛%' then '金牛区'
  when a.region like '%新都%' then '新都区'
  when a.region like '%郫都%' then '郫县'
  else a.region end
  where 1=1;

    update assessprice.TMP_LJ_DISTRICT_REL  a set a.status = 1 where 1=1;

  update assessprice.TMP_LJ_DISTRICT_REL  a
  set a.status = 0
  where a.id in(
  select id from (select id, row_number()over(partition by id order by id ) row_id from assessprice.TMP_LJ_DISTRICT_REL )where row_id >=2
  );

    --3、链家区域成交均价
    insert into  assessprice.tmp_lj_region_price(region,avgprice)
  select a.region,round(sum(a.avg_price)/count(*),2) avgprice
  from  assessprice.tmp_lj_pro_avg_price a
  where a.status =1
  group by a.region;

    delete ASSESSPRICE.WORK_LOG where name='方法三' and trunc(in_date)=trunc(sysdate);
    insert into ASSESSPRICE.WORK_LOG
    values(assessprice.seq_work_log_id.nextval,'方法三','','','是','成功',trunc(sysdate),'','','估价计算模块');
    commit;

    exception when others then
    dbms_output.put_line('捕获错误 ');
    sv_err_sqlcode:=('错误代码：'||SQLCODE);
    sv_err_SQLERRM:=('错误信息：'||SQLERRM);
  insert into ASSESSPRICE.WORK_LOG
  values(assessprice.seq_work_log_id.nextval,'方法三','','','是','失败',trunc(sysdate),sv_err_sqlcode,sv_err_SQLERRM,'估价计算模块');
  commit;
end PRO_ASSESS_FUN_PRICE_3;
/

