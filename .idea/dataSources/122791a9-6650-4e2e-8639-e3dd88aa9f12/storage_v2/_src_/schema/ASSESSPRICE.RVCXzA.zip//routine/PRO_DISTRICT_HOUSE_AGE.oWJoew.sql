CREATE procedure pro_district_house_age ( s_type varchar2,s_date varchar2 )
is
/************************************************************************************************************************************
开发时间：2017-07-11
变更时间：
变更内容：
输入参数：s_type='ini',初始化，'add'，增量；yyyy-mm-dd
返回参数：
过程功能：加工房源的建筑年代。建筑年代.取同一建筑区划ID下，最小最始登记日期
************************************************************************************************************************************/
v_start_date date;
v_end_date date;

v_sqlcode varchar2(200);
v_sqlerrm varchar2(2000); 

begin

    --开始时间
    select sysdate into v_start_date from dual;


    if s_type='ini' then
      merge into assessprice.assess_house h 
      using (
        SELECT b.district_id,to_number(to_char(min(r.indate),'yyyy')) as house_age
          FROM wxzj.fix_house a inner join wxzj.fix_building b on a.building_id = b.id and a.is_deleted = 0 and b.is_deleted = 0 and a.manual_code is not null
          inner join hregister.buildinght bt on a.manual_code=bt.tableid and a.data_source=bt.data_source
          inner join hregister.registrations r on bt.regiid=r.id and bt.data_source=r.data_source
          where r.status in (1500,1501) and r.regitype='所有权登记' and r.regikind='初始登记'
          and nvl2(translate(a.manual_code,'/1234567890','/'),'CHAR','NUMBER')='NUMBER'
          and r.indate is not null
          group by b.district_id 
      ) t 
      on (h.district_id = t.district_id)
      when matched then
        update set h.house_age=t.house_age; 
    --elsif s_type='add' then
    end if;

    --结束时间
    select sysdate into v_end_date from dual;

    delete from assessprice.operate_log where proc_name='pro_district_house_age' and parameter_name=s_date;
    insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
    values(sys_guid(),'pro_district_house_age',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'成功','');
    commit;

    exception
    when others then
    v_sqlcode:=('错误代码:'||SQLCODE);
    v_sqlerrm:=('错误信息:'||SQLERRM);
    insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
    values(sys_guid(),'pro_district_house_age',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'失败:'||v_sqlcode,v_sqlerrm);
    commit;
end pro_district_house_age;
/

