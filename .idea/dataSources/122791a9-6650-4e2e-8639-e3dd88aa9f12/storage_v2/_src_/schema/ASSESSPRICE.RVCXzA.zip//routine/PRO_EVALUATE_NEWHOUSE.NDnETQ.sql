CREATE procedure pro_evaluate_newhouse ( s_type in varchar2,s_date in varchar2 )
is
/************************************************************************************************************************************
开发时间：2017-07-11
变更时间：
变更内容：
输入参数：s_type='ini',初始化，'add'，增量；yyyy-mm-dd
返回参数：
过程功能：增量抽取房源数据
************************************************************************************************************************************/
v_start_date date;
v_end_date date;

v_sqlcode varchar2(200);
v_sqlerrm varchar2(2000);


begin

    --开始时间
    select sysdate into v_start_date from dual;

    if s_type='ini' then
    --全量抽取房源
    merge into assessprice.evaluate_newhouse a
    using ( select h.tableid,h.data_source,h.usage,h.licenceid,h.projid,
                assessprice.FUN_GETREGIONCODE(h.districk,h.data_source) as region_code,
                assessprice.FUN_GETREGIONname(h.districk,h.data_source) as region_name,
                assessprice.func_get_building_shape(h.projid,h.data_source,h.hno,h.uno) as buildingtype,
                c.buydate,
                nvl(h.area,0)+nvl(h.outarea,0) as total_area,
                h.price,
                h.streetscene,
                h.doorplate,
                h.additory_doorplate
         from estate.housetable h inner join estate.contract c on h.contractid=c.contractid and h.data_source=c.data_source
         where c.buydate is not null and c.status in (500) and nvl(h.area,0)+nvl(h.outarea,0)>0
       ) t  on ( a.tableid=t.tableid and a.data_source=t.data_source )
       when matched then
       update set a.projid=t.projid,
       a.total_area=t.total_area,
       a.usage=t.usage,
       a.licenceid=t.licenceid,
       a.building_type_code=t.buildingtype,
       a.region_code=t.region_code,
       a.region_name=t.region_name,
       a.buydate=t.buydate,
       a.price=t.price,
       a.streetscene=t.streetscene,
       a.doorplate=t.doorplate,
       a.additory_doorplate=t.additory_doorplate
       when not matched then
        insert ( tableid,data_source,projid,total_area,usage,licenceid,building_type_code,region_code,region_name,buydate,price,streetscene,doorplate,additory_doorplate )
        values( t.tableid,t.data_source,t.projid,t.total_area,t.usage,
                t.licenceid,t.buildingtype,t.region_code,t.region_name,t.buydate,t.price,t.streetscene,t.doorplate,t.additory_doorplate );
    else

    --增量抽取房源
    merge into assessprice.evaluate_newhouse a
    using ( select h.tableid,h.data_source,h.usage,h.licenceid,h.projid,
                assessprice.FUN_GETREGIONCODE(h.districk,h.data_source) as region_code,
                assessprice.FUN_GETREGIONname(h.districk,h.data_source) as region_name,
                assessprice.func_get_building_shape(h.projid,h.data_source,h.hno,h.uno) as buildingtype,
                c.buydate,
                nvl(h.area,0)+nvl(h.outarea,0) as total_area,
                h.price,
                h.streetscene,
                h.doorplate,
                h.additory_doorplate
         from estate.housetable h inner join estate.contract c on h.contractid=c.contractid and h.data_source=c.data_source
         where c.buydate is not null and c.buydate between to_date(s_date||' 00:00:00','yyyy-mm-dd hh24:mi:ss') and to_date(s_date||' 23:59:59','yyyy-mm-dd hh24:mi:ss')
                   and c.status in (500) and nvl(h.area,0)+nvl(h.outarea,0)>0
       ) t  on ( a.tableid=t.tableid and a.data_source=t.data_source )
       when matched then
       update set a.projid=t.projid,
       a.total_area=t.total_area,
       a.usage=t.usage,
       a.licenceid=t.licenceid,
       a.building_type_code=t.buildingtype,
       a.region_code=t.region_code,
       a.region_name=t.region_name,
       a.buydate=t.buydate,
       a.price=t.price,
       a.streetscene=t.streetscene,
       a.doorplate=t.doorplate,
       a.additory_doorplate=t.additory_doorplate
       when not matched then
        insert ( tableid,data_source,projid,total_area,usage,licenceid,building_type_code,region_code,region_name,buydate,price,streetscene,doorplate,additory_doorplate )
        values( t.tableid,t.data_source,t.projid,t.total_area,t.usage,
                t.licenceid,t.buildingtype,t.region_code,t.region_name,t.buydate,t.price,t.streetscene,t.doorplate,t.additory_doorplate );

    end if;

    --结束时间
    select sysdate into v_end_date from dual;

    delete from assessprice.operate_log where proc_name='pro_evaluate_newhouse' and parameter_name=s_date;
    insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
    values(sys_guid(),'pro_evaluate_newhouse',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'成功','');
    commit;

    exception
    when others then
    v_sqlcode:=('错误代码:'||SQLCODE);
    v_sqlerrm:=('错误信息:'||SQLERRM);
    insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
    values(sys_guid(),'pro_evaluate_newhouse',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'失败:'||v_sqlcode,v_sqlerrm);
    commit;
end pro_evaluate_newhouse;
/

