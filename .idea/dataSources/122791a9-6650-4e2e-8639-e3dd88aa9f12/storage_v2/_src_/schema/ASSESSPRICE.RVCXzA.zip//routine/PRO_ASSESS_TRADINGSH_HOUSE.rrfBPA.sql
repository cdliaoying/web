CREATE procedure PRO_assess_tradingsh_house ( etl_type in varchar2)
is
/************************************************************************************************************************************
开发：tsn
开发时间：2017-04-21
变更时间：etl新房备案价、评估价、二手房价格，计算结果放在表：lj_assess_tradingsh_house中
变更内容：
输入参数：etl_type=init,全量，add,增量
返回参数：etl新房备案价、评估价、二手房价格
过程功能：etl新房备案价、评估价、二手房价格
************************************************************************************************************************************/
v_sqlcode varchar2(200);
v_sqlerrm varchar2(2000);

v_start_date date;
v_end_date date;

s_date varchar2(20);

begin

    --1、处理新房合同情况
    begin
      --开始时间
      select sysdate,to_char(sysdate,'yyyy-mm-dd') into v_start_date,s_date from dual;
      v_sqlcode:=null;
      v_sqlerrm:=null;

      if etl_type='init' then
        --全量抽取新房合同数据
        merge into assessprice.assess_tradingsh_house h
        using ( select h.tableid,h.data_source,nvl(h.area,0)+nvl(h.outarea,0) as total_area,h.area,h.outarea,h.price,c.buydate
        from estate.contract c inner join estate.housetable h on c.contractid=h.contractid and c.data_source=h.data_source
        where c.status in (450,460,500)
        ) t
        on (h.tableid=t.tableid and h.data_source=t.data_source)
        when matched then update set h.total_area=t.total_area,h.area=t.area,h.outarea=t.outarea,h.price=t.price,h.buydate=t.buydate
        when not matched then insert (tableid,data_source,total_area,area,outarea,price,buydate)
          values(t.tableid,t.data_source,t.total_area,t.area,t.outarea,t.price,t.buydate);
      end if;

      if etl_type='add' then
        --增量抽取新房合同数据
        merge into assessprice.assess_tradingsh_house h
        using ( select h.tableid,h.data_source,nvl(h.area,0)+nvl(h.outarea,0) as total_area,h.area,h.outarea,h.price,c.buydate
        from estate.contract c inner join estate.housetable h on c.contractid=h.contractid and c.data_source=h.data_source
        where c.status in (450,460,500) and trunc(c.etl_time)=trunc(sysdate - 1 )
        ) t
        on (h.tableid=t.tableid and h.data_source=t.data_source)
        when matched then update set h.total_area=t.total_area,h.area=t.area,h.outarea=t.outarea,h.price=t.price,h.buydate=t.buydate
        when not matched then insert (tableid,data_source,total_area,area,outarea,price,buydate)
          values(t.tableid,t.data_source,t.total_area,t.area,t.outarea,t.price,t.buydate);
      end if;

      --结束时间
      select sysdate into v_end_date from dual;
      
      delete from assessprice.operate_log where proc_name='assess_tradingsh_house'||'新房合同数据' and parameter_name=s_date;
      
      insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
      values(sys_guid(),'assess_tradingsh_house'||'新房合同数据',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'成功','');
      
      commit;

      exception
      when others then
      v_sqlcode:=('错误代码:'||SQLCODE);
      v_sqlerrm:=('错误信息:'||SQLERRM);
      insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
      values(sys_guid(),'assess_tradingsh_house'||'新房合同数据',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'失败:'||v_sqlcode,v_sqlerrm);
      
      commit;
    end;

    ------------------------------------------------------------2、处理存量房评估数据
    begin
      --开始时间
      select sysdate,to_char(sysdate,'yyyy-mm-dd') into v_start_date,s_date from dual;
      v_sqlcode:=null;
      v_sqlerrm:=null;
      if etl_type='init' then
        --全量抽取存房评估数据
        merge into assessprice.assess_tradingsh_house h
        using ( select h.tableid,h.data_source,h.house_area,p.house_money,to_date(t.contract_time,'yyyy-mm-dd hh24:mi:ss') as contract_time
        from trading.rep_person_rel@dl_206.moban.com r inner join trading.eval_house@dl_206.moban.com h on r.relation_uuid=h.uuid
        inner join trading.eval_house_price@dl_206.moban.com p on h.uuid=p.eval_house_uuid
        inner join trading.eval_report@dl_206.moban.com t on r.rep_uuid=t.uuid
        where r.relation_table='eval_house'
        and t.contract_time is not null
        and h.tableid is not null
        and (h.tableid,h.data_source) in (
          select h.tableid,h.data_source
          from trading.rep_person_rel@dl_206.moban.com r inner join trading.eval_house@dl_206.moban.com h on r.relation_uuid=h.uuid
          inner join trading.eval_house_price@dl_206.moban.com p on h.uuid=p.eval_house_uuid
          inner join trading.eval_report@dl_206.moban.com t on r.rep_uuid=t.uuid
          where r.relation_table='eval_house'
          and t.contract_time is not null
          and h.tableid is not null
          group by h.tableid,h.data_source
          having count(1)=1)
        ) t
        on (h.tableid=t.tableid and h.data_source=t.data_source)

        when matched then update set h.total_area=t.house_area,h.trading_money=t.house_money,h.trading_date=t.contract_time

        when not matched then insert (tableid,data_source,total_area,trading_money,trading_date)
          values(t.tableid,t.data_source,t.house_area,t.house_money,t.contract_time) ;
      end if;

      if etl_type='add' then
        --增量抽取存量房评估数据
        merge into assessprice.assess_tradingsh_house h
        using ( select h.tableid,h.data_source,h.house_area,p.house_money,to_date(t.contract_time,'yyyy-mm-dd hh24:mi:ss') as contract_time
        from trading.rep_person_rel@dl_206.moban.com r inner join trading.eval_house@dl_206.moban.com h on r.relation_uuid=h.uuid
        inner join trading.eval_house_price@dl_206.moban.com p on h.uuid=p.eval_house_uuid
        inner join trading.eval_report@dl_206.moban.com t on r.rep_uuid=t.uuid
        where r.relation_table='eval_house'
        and t.contract_time is not null
        and h.tableid is not null
        and trunc( to_date(t.contract_time,'yyyy-mm-dd hh24:mi:ss') ) = trunc ( sysdate - 1 )
        and (h.tableid,h.data_source) in (
          select h.tableid,h.data_source
          from trading.rep_person_rel@dl_206.moban.com r inner join trading.eval_house@dl_206.moban.com h on r.relation_uuid=h.uuid
          inner join trading.eval_house_price@dl_206.moban.com p on h.uuid=p.eval_house_uuid
          inner join trading.eval_report@dl_206.moban.com t on r.rep_uuid=t.uuid
          where r.relation_table='eval_house'
          and t.contract_time is not null
          and h.tableid is not null
          and trunc( to_date(t.contract_time,'yyyy-mm-dd hh24:mi:ss') ) = trunc ( sysdate - 1 )
          group by h.tableid,h.data_source
          having count(1)=1)
        ) t
        on (h.tableid=t.tableid and h.data_source=t.data_source)

        when matched then update set h.total_area=t.house_area,h.trading_money=t.house_money,h.trading_date=t.contract_time

        when not matched then insert (tableid,data_source,total_area,trading_money,trading_date)
          values(t.tableid,t.data_source,t.house_area,t.house_money,t.contract_time) ;
      end if;

      --结束时间
      select sysdate into v_end_date from dual;

      delete from assessprice.operate_log where proc_name='assess_tradingsh_house'||'存量房评估数据' and parameter_name=s_date;
      insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
      values(sys_guid(),'assess_tradingsh_house'||'存量房评估数据',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'成功','');
      commit;

      exception
      when others then
      v_sqlcode:=('错误代码:'||SQLCODE);
      v_sqlerrm:=('错误信息:'||SQLERRM);
      insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
      values(sys_guid(),'assess_tradingsh_house'||'存量房评估数据',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'失败:'||v_sqlcode,v_sqlerrm);
      commit;
    end;

    --3、处理二手房评估数据
    begin
      --开始时间
      select sysdate,to_char(sysdate,'yyyy-mm-dd') into v_start_date,s_date from dual;
      v_sqlcode:=null;
      v_sqlerrm:=null;
      if etl_type='init' then
        /*****************************************************************
        全量抽取二手房备案数据
        ****************************************************************/

        merge into assessprice.assess_tradingsh_house h
        using ( select sh.tableid,sh.data_source,nvl(sh.area,0)+nvl(sh.outarea,0) as house_area,
                     sh.area,sh.outarea,c.money, c.printdate ,c.supervision_amount,c.loan_amount
        from estate.shcontract c inner join estate.shtable sh on c.shcontid=sh.shcontid and c.data_source=sh.data_source
        where c.status in ('已发证','登记','有效')
        and ( sh.tableid,sh.data_source ) in (
        select sh.tableid,sh.data_source
        from estate.shcontract c inner join estate.shtable sh on c.shcontid=sh.shcontid and c.data_source=sh.data_source
        where c.status in ('已发证','登记','有效')
        group by sh.tableid,sh.data_source
        having count(1)=1 )
         ) t
        on (h.tableid=t.tableid and h.data_source=t.data_source)
        when matched then
          update set h.total_area=t.house_area,
                   h.area=t.area,
                   h.outarea=t.outarea,
                   h.sh_money=t.money,
                   h.sh_printdate=t.printdate,
                   h.sh_supervision_amount=t.supervision_amount,
                   h.sh_loan_amount=t.loan_amount
        when not matched then insert (tableid,data_source,total_area,area,outarea,sh_money,sh_printdate,sh_supervision_amount,sh_loan_amount)
          values(t.tableid,t.data_source,t.house_area,t.area,t.outarea,t.money,t.printdate,t.supervision_amount,t.loan_amount);
      end if;

      if etl_type='add' then
        --增量抽取二手房备案数据
        merge into assessprice.assess_tradingsh_house h
        using ( select sh.tableid,sh.data_source,nvl(sh.area,0)+nvl(sh.outarea,0) as house_area,
                     sh.area,sh.outarea,c.money, c.printdate ,c.supervision_amount,c.loan_amount
        from estate.shcontract c inner join estate.shtable sh on c.shcontid=sh.shcontid and c.data_source=sh.data_source
        where c.status in ('已发证','登记','有效')
        and trunc(c.etl_time)=trunc(sysdate - 1)
        and ( sh.tableid,sh.data_source ) in (
        select sh.tableid,sh.data_source
        from estate.shcontract c inner join estate.shtable sh on c.shcontid=sh.shcontid and c.data_source=sh.data_source
        where c.status in ('已发证','登记','有效')
        and trunc(c.etl_time)=trunc(sysdate - 1)
        group by sh.tableid,sh.data_source
        having count(1)=1 )
         ) t
        on (h.tableid=t.tableid and h.data_source=t.data_source)
        when matched then
          update set h.total_area=t.house_area,
                   h.area=t.area,
                   h.outarea=t.outarea,
                   h.sh_money=t.money,
                   h.sh_printdate=t.printdate,
                   h.sh_supervision_amount=t.supervision_amount,
                   h.sh_loan_amount=t.loan_amount
        when not matched then insert (tableid,data_source,total_area,area,outarea,sh_money,sh_printdate,sh_supervision_amount,sh_loan_amount)
          values(t.tableid,t.data_source,t.house_area,t.area,t.outarea,t.money,t.printdate,t.supervision_amount,t.loan_amount);
      end if;

      --结束时间
      select sysdate into v_end_date from dual;

      delete from assessprice.operate_log where proc_name='assess_tradingsh_house'||'二手房备案数据' and parameter_name=s_date;
      insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
      values(sys_guid(),'assess_tradingsh_house'||'二手房备案数据',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'成功','');
      commit;

      exception
      when others then
      v_sqlcode:=('错误代码:'||SQLCODE);
      v_sqlerrm:=('错误信息:'||SQLERRM);
      insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
      values(sys_guid(),'assess_tradingsh_house'||'二手房备案数据',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'失败:'||v_sqlcode,v_sqlerrm);

      commit;
    end;
end PRO_assess_tradingsh_house;
/

