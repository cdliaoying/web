CREATE procedure PRO_lj_price_building_min_max
is
/************************************************************************************************************************************
开发：tsn
时间：2017-04-14
变更：计算assess_house表中的均价及最小、最大参考均价，计算结果放在表：assess_house中
内容：
输入参数：
返回参数：房屋评估单价
过程功能：计算房屋单价
************************************************************************************************************************************/
v_start_date date;
v_end_date date;

s_date varchar2(20);

v_sqlcode varchar2(200);
v_sqlerrm varchar2(2000);

v_projid number;
v_data_source varchar2(20);

v_floor_max number;--最大楼层
v_number_flag varchar2(10);--是否为数字


cursor mycur_1 is
select projid,data_source
from assessprice.TMP_PROJ_DATA_SOURCE
where if_flag=0;

begin
  --开始时间
  select sysdate,to_char(sysdate,'yyyy-mm-dd') into v_start_date,s_date from dual;

  open mycur_1;
     fetch mycur_1 into v_projid,v_data_source;

     LOOP
       EXIT WHEN mycur_1%NOTFOUND;

       --更新建筑形态
       merge into assessprice.assess_house h
       using (
       select h.projid,h.tableid,h.data_source,func_get_building_shape(h.projid,h.data_source,h.hno,h.uno) as building_house
       from estate.housetable h
       where h.usage in ('成套住宅','住宅','公寓','别墅') and h.projid=v_projid and h.data_source=v_data_source
       ) t on ( h.tableid=t.tableid and h.data_source=t.data_source )
       when matched then update set h.building_type = t.building_house;
       commit;

     --dbms_output.put_line('1、SQLERRM='||SQLERRM);


     update assessprice.assess_house h
     set h.region_code = case
       when h.data_source = '510100' and h.districk in('锦江区','锦江','3锦江区')  then '510104'
       when h.data_source = '510100' and h.districk in('武侯区','武侯','武候区')  then '510107'
       when h.data_source = '510100' and h.districk in('青羊区','青羊')  then '510105'
       when h.data_source = '510100' and h.districk in('金牛区','.金牛区','金牛')  then '510106'
       when h.data_source = '510100' and h.districk in('成华区','.成华区','成华')  then '510108'
       when h.data_source = '510100' and h.districk in('高新区','高新','高新区（西区）','西航港街道','西航港街道办事处','西航港开发区','中和','中和街道','中和镇','华阳镇')  then '510109'
       else h.data_source end
     where h.region_code is null and h.projid=v_projid and h.data_source=v_data_source;
     commit;

     merge into assessprice.assess_house a
     using (select a.hou_id,b.region_name
            from assessprice.assess_house a inner join cdfgora.t_region_d b on a.region_code = b.region_code and a.region is null
            and a.projid=v_projid and a.data_source=v_data_source ) b
     on(a.hou_id = b.hou_id)
     when matched then
     update set a.region = b.region_name;
     commit;

     --1、是否能匹配lj_name+building_type
     merge into assessprice.assess_house h
     using (
     select distinct h.district_id,h.building_type,p.avgprice_min,p.avgprice_max,p.avgprice,p.avgarea
     from assessprice.assess_house h inner join assessprice.tmp_lj_district_rel t on h.district_id=t.district_id and (h.tr_price=0 or h.tr_price is null )
     inner join assessprice.lj_project_building_price p on t.lj_name=p.lj_name and h.building_type=p.building_type and h.projid=v_projid and h.data_source=v_data_source ) tt
     on (h.district_id=tt.district_id and h.building_type=tt.building_type )
     when matched then
     update set h.tr_price_min=tt.avgprice_min,h.tr_price_max=tt.avgprice_max,h.tr_price=tt.avgprice,h.RISK_BROAD=0,h.lj_avgarea=tt.avgarea;
     commit;

     --dbms_output.put_line('2、SQLERRM='||SQLERRM);

     --2、是否能匹配lj_name
     merge into assessprice.assess_house h
     using (
     select distinct h.district_id,p.avgprice_min,p.avgprice_max,p.avgprice,p.avgarea
     from assessprice.assess_house h inner join assessprice.tmp_lj_district_rel t on h.district_id=t.district_id and (h.tr_price=0 or h.tr_price is null )  and h.projid=v_projid and h.data_source=v_data_source
     inner join assessprice.lj_project_price p on t.lj_name=p.lj_name ) tt
     on (h.district_id=tt.district_id )
     when matched then
     update set h.tr_price_min=tt.avgprice_min,h.tr_price_max=tt.avgprice_max,h.tr_price=tt.avgprice,h.RISK_BROAD=0,h.lj_avgarea=tt.avgarea;
     commit;

     --dbms_output.put_line('3、SQLERRM='||SQLERRM);


     --3、是否能匹配block_name+building_type
     merge into assessprice.assess_house h
     using (
     select distinct h.district_id,h.building_type,p.avgprice_min,p.avgprice_max,p.avgprice,p.avgarea
     from assessprice.assess_house h inner join assessprice.tmp_lj_district_rel t on h.district_id=t.district_id and (h.tr_price=0 or h.tr_price is null )   and h.projid=v_projid and h.data_source=v_data_source
     inner join assessprice.lj_block_building_price p on t.lj_block=p.lj_block and h.building_type=p.building_type ) tt
     on (h.district_id=tt.district_id and h.building_type=tt.building_type )
     when matched then
     update set h.tr_price_min=tt.avgprice_min,h.tr_price_max=tt.avgprice_max,h.tr_price=tt.avgprice,h.RISK_BROAD=1,h.lj_avgarea=tt.avgarea;
     commit;

     --dbms_output.put_line('4、SQLERRM='||SQLERRM);



     --4、是否能匹配block_name
     merge into assessprice.assess_house h
     using (
     select distinct h.district_id,p.avgprice_min,p.avgprice_max,p.avgprice,p.avgarea
     from assessprice.assess_house h inner join assessprice.tmp_lj_district_rel t on h.district_id=t.district_id and (h.tr_price=0 or h.tr_price is null )   and h.projid=v_projid and h.data_source=v_data_source
     inner join assessprice.lj_block_price p on t.lj_block=p.lj_block ) tt
     on (h.district_id=tt.district_id )
     when matched then
     update set h.tr_price_min=tt.avgprice_min,h.tr_price_max=tt.avgprice_max,h.tr_price=tt.avgprice,h.RISK_BROAD=1,h.lj_avgarea=tt.avgarea;
     commit;

     --dbms_output.put_line('5、SQLERRM='||SQLERRM);

     --5、是否能匹配region_name+building_type
     merge into assessprice.assess_house h
     using (
     select distinct h.building_type,p.region_code,p.avgprice_min,p.avgprice_max,p.avgprice,p.avgarea
     from assessprice.assess_house h inner join assessprice.lj_region_building_price p on h.region_code=p.region_code and h.building_type=p.building_type   and (h.tr_price=0 or h.tr_price is null )
      and h.projid=v_projid and h.data_source=v_data_source
     ) tt
     on (h.region_code=tt.region_code and h.building_type=tt.building_type )
     when matched then
     update set h.tr_price_min=tt.avgprice_min,h.tr_price_max=tt.avgprice_max,h.tr_price=tt.avgprice,h.RISK_BROAD=2,h.lj_avgarea=tt.avgarea;
     commit;

     --dbms_output.put_line('6、SQLERRM='||SQLERRM);

     --6、是否能匹配region_name
     merge into assessprice.assess_house h
     using (
     select distinct p.avgprice_min,p.avgprice_max,p.avgprice,p.region_code,p.avgarea
     from assessprice.assess_house h inner join assessprice.lj_region_price p on h.region_code=p.region_code and (h.tr_price=0 or h.tr_price is null )  and h.projid=v_projid and h.data_source=v_data_source
     ) tt
     on (h.region_code=tt.region_code )
     when matched then
     update set h.tr_price_min=tt.avgprice_min,h.tr_price_max=tt.avgprice_max,h.tr_price=tt.avgprice,h.RISK_BROAD=2,h.lj_avgarea=tt.avgarea;
     commit;

     --dbms_output.put_line('7、SQLERRM='||SQLERRM);

     --7、处理楼层相对差异
     select max(regexp_substr(h.fno,'[0-9]+')+0)
   into v_floor_max
   from estate.housetable h
   where h.projid =v_projid and h.data_source =v_data_source;

   /*
     floor between 0 and 2 110
     floor between 3 and 5 105
     floor between 6 and 8 100
     floor between 9 and 11 95
     floor >= 12 90
     */

     SELECT nvl2(translate(v_floor_max,'/1234567890','/'),'CHAR','NUMBER')
     into v_number_flag
     FROM dual;

     if v_number_flag='NUMBER' and length(trim(v_floor_max)) >0 then
     merge into assessprice.assess_house h
     using (
     select h.tableid,h.data_source, abs(round(h.fno-v_floor_max/2,0)) as Floor_difference,
               case when abs(round(h.fno-v_floor_max/2,0)) between 0 and 2 then 110
                  when abs(round(h.fno-v_floor_max/2,0)) between 3 and 5 then 105
                  when abs(round(h.fno-v_floor_max/2,0)) between 6 and 8 then 100
                  when abs(round(h.fno-v_floor_max/2,0)) between 9 and 11 then 95
                  when abs(round(h.fno-v_floor_max/2,0)) >=12 then 90
                  else 100
             end as score_floor_difference
     from estate.housetable h
     where h.projid=v_projid and h.data_source=v_data_source and nvl2(translate(h.fno,'/1234567890','/'),'CHAR','NUMBER')='NUMBER'
     ) t
     on (h.tableid=t.tableid and h.data_source=t.data_source)
     when matched then
      update set h.Floor_difference=t.Floor_difference,h.score_floor_difference=decode(t.score_floor_difference,null,100,'',100,t.score_floor_difference);
       commit;
   else
       update assess_house h set h.score_floor_difference=100 where h.projid=v_projid and h.data_source=v_data_source and h.score_floor_difference is null;
         commit;
     end if;

     --dbms_output.put_line('8、SQLERRM='||SQLERRM);

     --8、更新assess_house表中房源面积得分及LJ平均面积得分
     /*
     <=50 85
     >50 and <=70 then 90
     >70 and <=90 then 95
     >90 and <=110 then 100
     >110 and <=130 then 105
     >130 and <=150 then 110
     >150 then 115
     */
     update assessprice.assess_house h
     set h.score_house_area= case when h.totalarea<=50 then 85
                                                  when h.totalarea>50 and h.totalarea<=70 then 90
                                                  when h.totalarea>70 and h.totalarea<=90 then 95
                                                  when h.totalarea>90 and h.totalarea<=110 then 100
                                                  when h.totalarea>110 and h.totalarea<=130 then 105
                                                  when h.totalarea>130 and h.totalarea<=150 then 110
                                                  when h.totalarea>150 then 115 end,
         h.score_lj_avgarea= case when h.lj_avgarea<=50 then 85
                                                  when h.lj_avgarea>50 and h.lj_avgarea<=70 then 90
                                                  when h.lj_avgarea>70 and h.lj_avgarea<=90 then 95
                                                  when h.lj_avgarea>90 and h.lj_avgarea<=110 then 100
                                                  when h.lj_avgarea>110 and h.lj_avgarea<=130 then 105
                                                  when h.lj_avgarea>130 and h.lj_avgarea<=150 then 110
                                                  when h.lj_avgarea>150 then 115 end
     where h.projid=v_projid and h.data_source=v_data_source;
     commit;

     --9、处理分数为空的情况
     update assessprice.assess_house h
     set  h.score_lj_avgarea= 100
     where h.projid=v_projid and h.data_source=v_data_source and h.score_lj_avgarea is null ;
     commit;

     --10、更新assess_house表中的NEW_FUN_PRICE_3=tr_price*(     (h.score_house_area+h.score_floor_difference)/(h.score_lj_avgarea+100) )
     update assessprice.assess_house h
     set h.NEW_FUN_PRICE_3 = tr_price*( decode(h.score_house_area,null,100,h.score_house_area)+decode(h.score_floor_difference,null,100,h.score_floor_difference) ) /( decode(h.score_lj_avgarea,null,100,h.score_lj_avgarea)+100 )
     where h.projid=v_projid and h.data_source=v_data_source;
     commit;

     --11、判断价格是否低估，高估。风险标识，估价结果。如果小于TR_PRICE_MIN，2--低估，或大于TR_PRICE_MAX，1--高估。在min和max之间，0--正常。
     update assessprice.assess_house h
     set RISK_ASSESS = case when NEW_FUN_PRICE_3<TR_PRICE_MIN then 2
                                         when NEW_FUN_PRICE_3>TR_PRICE_MAX then 1
                                         else 0 end
     where h.projid=v_projid and h.data_source=v_data_source;
     commit;

     update assessprice.TMP_PROJ_DATA_SOURCE set if_flag=1 where projid=v_projid and data_source=v_data_source;
     commit;

     v_floor_max:=0;

     fetch mycur_1 into v_projid,v_data_source;
     END LOOP;
     CLOSE mycur_1;

  --结束时间
  select sysdate into v_end_date from dual;

  delete from assessprice.operate_log where proc_name='PRO_lj_price_building_min_max' and parameter_name=s_date;
  insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
  values(sys_guid(),'PRO_lj_price_building_min_max',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'成功','');
  commit;


  exception
  when others then
  v_sqlcode:=('错误代码:'||SQLCODE);
  v_sqlerrm:=('错误信息:'||SQLERRM);
  insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
  values(sys_guid(),'PRO_lj_price_building_min_max',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'失败:'||v_sqlcode,v_sqlerrm);
  commit;
end PRO_lj_price_building_min_max;
/

