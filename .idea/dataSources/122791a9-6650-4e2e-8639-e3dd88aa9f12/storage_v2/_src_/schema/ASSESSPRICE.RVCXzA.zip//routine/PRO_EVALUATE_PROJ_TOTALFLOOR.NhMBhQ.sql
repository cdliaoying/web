CREATE procedure pro_evaluate_proj_totalfloor ( s_type varchar2,s_date varchar2 )
is
/************************************************************************************************************************************
开发时间：2017-07-11
变更时间：
变更内容：
输入参数：s_type='ini',初始化，'add'，增量；yyyy-mm-dd
返回参数：
过程功能：加工楼栋的总楼层
************************************************************************************************************************************/
v_start_date date;
v_end_date date;

v_sqlcode varchar2(200);
v_sqlerrm varchar2(2000);

begin

    --开始时间
    select sysdate into v_start_date from dual;

    if s_type='ini' then

      EXECUTE IMMEDIATE 'truncate table assessprice.evaluate_proj_data_source';

      merge into assessprice.evaluate_proj_data_source t
    using (
    select h.projid,h.data_source,max(h.fno+0) as total_floor
    from estate.housetable h
    where nvl2(translate(h.fno,'/1234567890','/'),'CHAR','NUMBER')='NUMBER' and h.projid is not null
    group by h.projid,h.data_source ) w
    on (t.projid=w.projid and t.data_source=w.data_source)
    when matched then
      update set t.total_floor=w.total_floor
    when not matched then
      insert (projid,data_source,total_floor)
      values (w.projid,w.data_source,w.total_floor);
    --elsif s_type='add' then
      
       merge into assessprice.assess_house h 
       using (select projid,data_source,total_floor from assessprice.evaluate_proj_data_source ) t 
       on (h.projid=t.projid and h.data_source=t.data_source)
       when matched then
         update set h.totfloor=t.total_floor;
    
    end if;

    --结束时间
    select sysdate into v_end_date from dual;

    delete from assessprice.operate_log where proc_name='pro_evaluate_proj_totalfloor' and parameter_name=s_date;
    insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
    values(sys_guid(),'pro_evaluate_proj_totalfloor',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'成功','');
    commit;

    exception
    when others then
    v_sqlcode:=('错误代码:'||SQLCODE);
    v_sqlerrm:=('错误信息:'||SQLERRM);
    insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
    values(sys_guid(),'pro_evaluate_proj_totalfloor',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'失败:'||v_sqlcode,v_sqlerrm);
    commit;
end pro_evaluate_proj_totalfloor;
/

