CREATE function FUN_GET_LJ_REGIONCODE(v_region IN VARCHAR2) return varchar2
is
  Result varchar2(10);


begin

  Result:=
  case when v_region like '%崇州%' then '510184'
    when v_region like '%成华%' then '510108'
    when v_region like '%大邑%' then '510129'
    when v_region like '%都江堰%' then '510181'
    when v_region like '%高新%' then '510109' 
    when v_region like '%金牛%' then '510106'
    when v_region like '%金堂%' then '510121'
    when v_region like '%锦江%' then '510104'
    when v_region like '%龙泉驿%' then '510112'  
    
    when v_region like '%彭州%' then '510182'
    when v_region like '%蒲江%' then '510131'
    when v_region like '%青白江%' then '510113'
    when v_region like '%青羊%' then '510105' 
    when v_region like '%双流%' then '510122'
    when v_region like '%天府%' then '510142'
    when v_region like '%温江%' then '510115'
    when v_region like '%武侯%' then '510107'
    
    when v_region like '%新都%' then '510114'
    when v_region like '%新津%' then '510132'
    when v_region like '%邛崃%' then '510183'
    when v_region like '%郫%' then '510124' 
    end;
  /*
  select case when v_data_source='510100' and v_districk in ('中和街道','中和镇','中和','华阳镇','华阳街道','东升街道','华阳街道办','西航港开发区','西航港街道','华阳','东升镇','兴隆镇','高新区','高新南区') then '510109'
              when v_data_source='510100' and v_districk ='锦江区' then '510104'
              when v_data_source='510100' and v_districk ='青羊区' then '510105'
              when v_data_source='510100' and v_districk ='金牛区' then '510106'
              when v_data_source='510100' and v_districk ='武侯区' then '510107'
              when v_data_source='510100' and v_districk ='成华区' then '510108'
              when v_data_source!='510100' then v_data_source
         end
  into Result
  from dual;
  */

  return(Result);
end FUN_GET_LJ_REGIONCODE;
/

