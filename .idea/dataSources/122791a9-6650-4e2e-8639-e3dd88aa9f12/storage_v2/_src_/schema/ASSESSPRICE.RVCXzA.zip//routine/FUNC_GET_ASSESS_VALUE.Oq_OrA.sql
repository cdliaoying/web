CREATE function             FUNC_GET_ASSESS_VALUE(vn_tableid  IN INTEGER,vn_data_source IN INTEGER) RETURN VARCHAR2  IS
  v_results VARCHAR2(2000);    ---返回值
  sv_err_sqlcode VARCHAR2(200); --错误代码
  sv_err_SQLERRM VARCHAR2(200); --错误信息
  vn_isnull number; --评估房源是否存在
  vn_cnt number; --记录可比房源套数
  vn_assessprice number;--评估总价
  vn_x number; --x坐标
  vn_y number; --y坐标
  vn_area number; --待估房源建筑面积


begin
--评估房源是否存在

select count(*) into vn_isnull from assessprice.assess_house ;
dbms_output.put_line('评估房源是否存在:'||vn_isnull);
if vn_isnull >=1 then

--找到该房源建筑区划信息
select count(*) into vn_cnt from assessprice.assess_house a
inner join assessprice.ASSESS_PRICE b on a.tableid = b.tableid and a.data_source = b.data_source
and sysdate - b.assess_date <= 90
and exists(select 1 from assessprice.assess_house c where a.district_id = c.district_id and a.data_source = c.data_source
and c.tableid = vn_tableid and c.data_source = vn_data_source);

dbms_output.put_line('找到该房源建筑区划信息:'||vn_cnt);

--判断是否有>=3套可比房源
if vn_cnt >=3 then

select
round(e.totalarea*(
select
sum((func_get_ind_factor(vn_tableid,vn_data_source)/func_get_ind_factor(a.tableid,a.data_source))*(b.assess_value/a.totalarea))
/count(*)
from assessprice.assess_house a
inner join assessprice.ASSESS_PRICE b on a.tableid = b.tableid and a.data_source = b.data_source
and sysdate - b.assess_date <= 90
and exists(select 1 from assessprice.assess_house c where a.tableid = c.tableid and a.data_source = c.data_source
and c.tableid = vn_tableid and c.data_source = vn_data_source)
),2) assessprice into vn_assessprice
from  assessprice.assess_house e;
v_results :=(vn_assessprice);
dbms_output.put_line('判断是否有>=3套可比房源:'||vn_assessprice);
else

select  a.XCENTERCOOD,a.YCENTERCOOD into vn_x,vn_y from assessprice.assess_house a
where a.tableid = vn_tableid and a.data_source = vn_data_source ;

select count(*) into vn_cnt
from assessprice.assess_house a
where assessprice.FUNC_GET_EARTH_DISTANCE(vn_x,vn_y,a.XCENTERCOOD,a.YCENTERCOOD) <=1000
;
----临近小区是否有>=3套可比房源
if vn_cnt >= 3 then

--func_get_ind_factor 获取个别因素总分
--func_get_reg_factor 获取区域因素总分
with tmp as (
select group_type,tableid,data_source,assess_value
 from(
select rownum row_id,1 group_type,tableid,data_source,assess_value from(
select a.tableid,a.data_source,round(b.assess_value/a.totalarea,2) as assess_value
from assessprice.assess_house a
inner join assessprice.ASSESS_PRICE b on a.tableid = b.tableid and a.data_source = b.data_source
where FUNC_GET_EARTH_DISTANCE(vn_x,vn_y,a.XCENTERCOOD,a.YCENTERCOOD) <=1000
order by FUNC_GET_EARTH_DISTANCE(vn_x,vn_y,a.XCENTERCOOD,a.YCENTERCOOD)
)
)where row_id <=3),
ckqz as(select tableid,data_source, round(func_get_reg_factor(vn_tableid,vn_data_source)/
sum(abs(func_get_reg_factor(tableid,data_source) - func_get_reg_factor(vn_tableid,vn_data_source)))over(partition by group_type order by null)*100
,2) ckqz
from tmp)
select
assess_value*(func_get_ind_factor(vn_tableid,vn_data_source)/func_get_ind_factor(a.tableid,a.data_source))*b.ckqz*vn_area
 into vn_assessprice
from tmp a
inner join ckqz b on a.tableid = b.tableid and a.data_source = b.data_source
;
v_results :=(vn_assessprice);

dbms_output.put_line('临近小区是否有>=3套可比房源:'||vn_cnt);
else
  v_results :='无法评估';
  dbms_output.put_line('无法评估');
end if;
end if;
else
  dbms_output.put_line('2:'||vn_isnull);
   v_results :='该房源未存在系统中';
end if;

  return v_results;

-----------------------------------------------------------------
------异常处理---------------------------------------------------
-----------------------------------------------------------------
EXCEPTION  WHEN OTHERS THEN
    ROLLBACK;
    sv_err_sqlcode:=('错误代码：'||SQLCODE);
    sv_err_SQLERRM:=('错误信息：'||SQLERRM);
    v_results:= '-2';
    DBMS_OUTPUT.PUT_LINE(SQLCODE||'---'||SQLERRM);

    -----向日志表插入数据
    -----向日志表插入数据
--insert into ASSESSPRICE.WORK_LOG values('日志ID','估价ID','房屋ID','是否有错','错误名称',sysdate,sv_err_sqlcode,sv_err_SQLERRM,'模块1');
commit;

  RETURN v_results;
end FUNC_GET_ASSESS_VALUE;
/

