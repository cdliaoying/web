CREATE procedure pro_evadetail_lj_firrgadd ( s_tableid in int,s_data_source in varchar2,
v_streetscene_firstreg in varchar2,v_doorplate_firstreg in varchar2,v_additory_firstreg in varchar2,
s_date in varchar2 )
is
/************************************************************************************************************************************
开发时间：2017-07-11
变更时间：
变更内容：
输入参数：
返回参数：
过程功能：按初始登记地址查询链家项目，抽取链家案例数据
************************************************************************************************************************************/
v_start_date date;
v_end_date date;

v_sqlcode varchar2(200);
v_sqlerrm varchar2(2000);

v_k int;

begin

    --开始时间
    select sysdate into v_start_date from dual;

    --根据传入的参数查询LJ_NAME

    delete from assessprice.evaluate_house_detail where evaluate_tableid=s_tableid and data_source=s_data_source and evaluate_date=to_date(s_date,'yyyy-mm-dd') and case_type in ( '初始登记lj_listed','初始登记lj_tr') ;

    --查询LJ_NAME
    select count(1)
    into v_k
    from assessprice.evaluate_registeraddress_lj t
    where ( decode(t.streetscene,null,'999999','','999999',t.streetscene) =v_streetscene_firstreg
                  and decode(t.doorplate,null,'999999','','999999',t.doorplate) =v_doorplate_firstreg
                  and decode(t.additory_doorplate,null,'999999','','999999',t.additory_doorplate) =v_additory_firstreg ) ;

    if v_k>0 then
      insert into assessprice.evaluate_house_detail (evaluate_id,evaluate_tableid,data_source,evaluate_date,case_type,lj_no,lj_name,verification_code,
      buydate,region_name,price,total_area,usage,decoration,building_year,total_floor,located_floor,
      house_type,elevator_num,elevator_house,elevator)

      select s_tableid||'-'||s_data_source||'-'||s_date,s_tableid,s_data_source,to_date(s_date,'yyyy-mm-dd'),'初始登记lj_listed',t.lj_no,t.lj_name,t.verification_code,
      t.listed_date,t.region,t.price,t.total_area,t.usage_1,t.decoration,t.building_year,t.total_floor,t.located_floor,
      t.bedroom||'室'||t.livingroom||'厅' house_type,t.elevator_num,t.elevator_house,t.elevator
      from assessprice.lj_listed_house t
      where t.lj_name in
        (
        select distinct t.lj_name
          from assessprice.evaluate_registeraddress_lj t
          where ( decode(t.streetscene,null,'999999','','999999',t.streetscene) =v_streetscene_firstreg
                      and decode(t.doorplate,null,'999999','','999999',t.doorplate) =v_doorplate_firstreg
                      and decode(t.additory_doorplate,null,'999999','','999999',t.additory_doorplate) =v_additory_firstreg )
        )

        union all

        select s_tableid||'-'||s_data_source||'-'||s_date,s_tableid,s_data_source,to_date(s_date,'yyyy-mm-dd'),'初始登记lj_tr',t.lj_no,t.lj_name,t.verification_code,
        t.tr_date,t.region,t.total_tr_price/t.total_area,t.total_area,t.usage_1,t.decoration,t.building_year,t.total_floor,t.located_floor,
        t.bedroom||'室'||t.livingroom||'厅'||t.kitchen||'厨'||t.bathroom||'卫' house_type,t.elevator_num,t.elevator_house,t.elevator
        from assessprice.lj_tr_house t
        where t.lj_name in
        (
        select distinct t.lj_name
          from evaluate_registeraddress_lj t
          where ( decode(t.streetscene,null,'999999','','999999',t.streetscene) =v_streetscene_firstreg
                      and decode(t.doorplate,null,'999999','','999999',t.doorplate) =v_doorplate_firstreg
                      and decode(t.additory_doorplate,null,'999999','','999999',t.additory_doorplate) =v_additory_firstreg )
        )
        ;
    end if;
    ---------------------------------------------------按初始登记取数据
    --结束时间
    select sysdate into v_end_date from dual;

    delete from assessprice.operate_log where proc_name='pro_evadetail_lj_firrgadd' and parameter_name=s_date;
    insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
    values(sys_guid(),'pro_evadetail_lj_firrgadd',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'成功','');
    commit;

    exception
    when others then
    v_sqlcode:=('错误代码:'||SQLCODE);
    v_sqlerrm:=('错误信息:'||SQLERRM);
    insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
    values(sys_guid(),'pro_evadetail_lj_firrgadd',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'失败:'||v_sqlcode,v_sqlerrm);
    commit;
end pro_evadetail_lj_firrgadd;
/

