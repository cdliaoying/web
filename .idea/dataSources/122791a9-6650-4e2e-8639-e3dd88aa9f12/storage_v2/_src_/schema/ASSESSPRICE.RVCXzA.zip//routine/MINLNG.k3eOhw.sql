CREATE FUNCTION minlng(double longitude,double latitude,double dis ) 
Return Number As
  --先计算查询点的经纬度范围
  r    Number := 6378.137;--地球半径千米 
  pi   Number := 3.14159265;
  s    Number := 0;
  dlng Number(15, 10);
begin 
  dlng: =  2*asin(sin(dis/(2*r))/cos(latitude*pi/180));  
  
                 
  s := s * earth_padius;
  s := Round(s * 10000)/10;--单位米 
  return s;

End minlng;
/

