CREATE package pkg_wrap_test is
--测试过程，将输入的数字以字符格式输出
function rad(ss in number);
END pkg_wrap_test;
/

