CREATE procedure             PRO_ASSESS_FUN_PRICE_1
is
/************************************************************************************************************************************
开发人员：唐遂宁
开发时间：2017-03-30
变更时间：按评估方法1进行计算，计算结果放在表：tmp_pro_avg_price中
变更内容：
输入参数：
返回参数：房屋评估单价
过程功能：计算房屋单价
************************************************************************************************************************************/
sv_err_sqlcode varchar2(200);
sv_err_SQLERRM varchar2(2000);

v_data_source varchar(20);
v_avg_price number(18,4);

cursor mycur is
select data_source,avg_price
from assessprice.tmp_year_price
where tj_year in (select max(tj_year) from assessprice.tmp_year_price );

begin

  /*****************************************************************
    方法一：评估价格
  ****************************************************************/
  EXECUTE IMMEDIATE 'truncate table assessprice.tmp_year_price';        --1、区域每年成交均价
  EXECUTE IMMEDIATE 'truncate table assessprice.tmp_pro_year_price'; --2、项目每年成交均价
  EXECUTE IMMEDIATE 'truncate table assessprice.tmp_pro_avg_price';  --3、项目成交均价

    --1、区域每年成交均价：tmp_year_price
    insert into assessprice.tmp_year_price (data_source,TJ_YEAR,avg_price)
    select c.data_source,
            to_char(c.indate,'yyyy') tj_year,
            round(sum(h.price)/sum(h.area+h.outarea),2) avg_price
  from estate.contract c
  inner join estate.housetable h on c.contractid=h.contractid and c.data_source = h.data_source
  inner join estate.presell p on h.licenceid=p.licenceid and c.data_source = p.data_source
  and h.usage in ('住宅','成套住宅','非成套住宅','公寓','别墅')
  where c.status=500 and  p.phase in ('有效', '查封', '暂停', '注销', '移交', '变更中')
  and p.licenceid not in ('1023', '1024', '1992', '99999','8535')
  GROUP BY c.data_source,to_char(c.indate,'yyyy');

  --计算区域每年成交均价表中涨幅
  begin
     open mycur;
     fetch mycur into v_data_source,v_avg_price;
     LOOP
       EXIT WHEN mycur%NOTFOUND;
       update assessprice.tmp_year_price a
       set a.zf = round(v_avg_price/a.avg_price,4)
       WHERE  a.avg_price >0 and data_source = v_data_source;
       dbms_output.put_line('v_data_source = '||v_data_source||' ,avg_price = '||v_avg_price);
       fetch mycur into v_data_source,v_avg_price;
     END LOOP;
     CLOSE mycur;
  end;

  --2、项目每年成交均价：tmp_pro_year_price
  insert into assessprice.tmp_pro_year_price (data_source,tj_year,district_name,district_id,district_code,district_address,avg_price,phase,fy_ts )
  SELECT cc.data_source,
              to_char(cc.indate,'yyyy') tj_year,
              c.district_name,
              b.district_id,
              c.district_code,
              c.district_address,
              round(sum(h.price)/sum(h.area+h.outarea),2) avg_price，
              case when count(distinct h.tableid) >=30 then 1 else 0 end phase,
              count(distinct h.tableid) fy_ts
  FROM estate.contract cc
  inner join estate.housetable h  on cc.contractid=h.contractid and cc.data_source = h.data_source
  and h.usage in ('住宅','成套住宅','非成套住宅','公寓','别墅')
  and cc.status=500
  inner join estate.presell p on h.licenceid=p.licenceid and p.data_source = cc.data_source
  and p.phase in ('有效', '查封', '暂停', '注销', '移交', '变更中')
  and p.licenceid not in ('1023', '1024', '1992', '99999','8535')
  inner join wxzj.fix_house a on h.tableid = a.manual_code and a.data_source = cc.data_source and a.data_source in('510100','510114') and a.manual_code <> '中厅'
  inner join wxzj.fix_building b on a.building_id = b.id and a.is_deleted = 0 and b.is_deleted = 0
  inner join wxzj.fix_district c on b.district_id = c.id and c.is_deleted = 0
  GROUP BY cc.data_source,to_char(cc.indate,'yyyy'),c.district_name,b.district_id,c.district_code,c.district_address;

    --3、项目成交均价：tmp_pro_avg_price
  insert into assessprice.tmp_pro_avg_price ( data_source,district_name,district_id,district_code,district_address,price )
  SELECT a.data_source,
              a.district_name,
              a.district_id,
              a.district_code,
              a.district_address,
        round(sum(a.avg_price*b.zf)/count(*),2) price
  FROM assessprice.tmp_pro_year_price a inner join assessprice.tmp_year_price b on a.tj_year = b.tj_year and a.phase =1 and a.data_source = b.data_source
  GROUP BY a.data_source,a.district_name,a.district_id,a.district_code,a.district_address;

    delete ASSESSPRICE.WORK_LOG where name='方法一' and trunc(in_date)=trunc(sysdate);
    insert into ASSESSPRICE.WORK_LOG
    values(assessprice.seq_work_log_id.nextval,'方法一','','','是','成功',trunc(sysdate),'','','估价计算模块');
    commit;

    exception when others then
    dbms_output.put_line('捕获错误 ');
    sv_err_sqlcode:=('错误代码：'||SQLCODE);
    sv_err_SQLERRM:=('错误信息：'||SQLERRM);
  insert into ASSESSPRICE.WORK_LOG
  values(assessprice.seq_work_log_id.nextval,'方法一','','','是','失败',trunc(sysdate),sv_err_sqlcode,sv_err_SQLERRM,'估价计算模块');
  commit;
end PRO_ASSESS_FUN_PRICE_1;
/

