CREATE procedure pro_evaluate_verification ( s_type varchar2,s_date varchar2 )
is
/************************************************************************************************************************************
开发时间：2017-07-11
变更时间：
变更内容：
输入参数：s_type='ini',初始化，'add'，增量；yyyy-mm-dd
返回参数：
过程功能：加工房源核实码
************************************************************************************************************************************/
v_start_date date;
v_end_date date;

v_sqlcode varchar2(200);
v_sqlerrm varchar2(2000);

begin

    --开始时间
    select sysdate into v_start_date from dual;

    if s_type='ini' then

      EXECUTE IMMEDIATE 'truncate table assessprice.evaluate_verification';

      merge into assessprice.evaluate_verification t
    using (
    select h.house_code,h.region_code,h.house_resource_code,h.in_time from trading.house_base_info h
    where nvl2(translate(h.house_code,'/1234567890','/'),'CHAR','NUMBER')='NUMBER' and h.house_code is not null and h.house_resource_code is not null) w
    on (t.tableid=w.house_code and t.data_source=w.region_code)
    when matched then
      update set t.verifi_code=w.house_resource_code,t.verifi_date=w.in_time
    when not matched then
      insert (tableid,data_source,verifi_code,verifi_date,tableid_int)
      values (w.house_code,w.region_code,w.house_resource_code,w.in_time,to_number(w.house_code));

    elsif s_type='add' then

    merge into assessprice.evaluate_verification t
    using (
    select h.house_code,h.region_code,h.house_resource_code,h.in_time from trading.house_base_info h
    where nvl2(translate(h.house_code,'/1234567890','/'),'CHAR','NUMBER')='NUMBER' and h.house_code is not null and h.house_resource_code is not null
         and h.in_time between to_date(s_date||' 00:00:00','yyyy-mm-dd hh24:mi:ss')
        and to_date(s_date||' 23:59:59','yyyy-mm-dd hh24:mi:ss')
  ) w
    on (t.tableid=w.house_code and t.data_source=w.region_code)
    when matched then
      update set t.verifi_code=w.house_resource_code,t.verifi_date=w.in_time
    when not matched then
      insert (tableid,data_source,verifi_code,verifi_date,tableid_int)
      values (w.house_code,w.region_code,w.house_resource_code,w.in_time,to_number(w.house_code));

    end if;

    --结束时间
    select sysdate into v_end_date from dual;

    delete from assessprice.operate_log where proc_name='pro_evaluate_verification' and parameter_name=s_date;
    insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
    values(sys_guid(),'pro_evaluate_verification',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'成功','');
    commit;

    exception
    when others then
    v_sqlcode:=('错误代码:'||SQLCODE);
    v_sqlerrm:=('错误信息:'||SQLERRM);
    insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
    values(sys_guid(),'pro_evaluate_verification',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'失败:'||v_sqlcode,v_sqlerrm);
    commit;
end pro_evaluate_verification;
/

