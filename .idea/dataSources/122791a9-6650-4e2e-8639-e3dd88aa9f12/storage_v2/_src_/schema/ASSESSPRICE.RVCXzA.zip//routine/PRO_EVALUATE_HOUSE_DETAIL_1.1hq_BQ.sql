CREATE procedure pro_evaluate_house_detail_1 ( s_tableid in int,s_data_source in varchar2,s_date varchar2 )
is
/************************************************************************************************************************************
开发时间：2017-07-11
变更时间：
变更内容：
输入参数：s_type='ini',初始化，'add'，增量；yyyy-mm-dd
返回参数：
过程功能：评估方法1：根据传入的tableid和data_source计算案例明细
************************************************************************************************************************************/
v_start_date date;
v_end_date date;

v_sqlcode varchar2(200);
v_sqlerrm varchar2(2000);

--楼盘表地址
v_district_id varchar2(50);

v_i int;
v_j int;
v_k int;

v_ii int;
v_kk int;
v_jj int; --统计案例数量
v_rate decimal(18,4);--平均涨幅

v_front_row int;--前20%的条数
v_end_row int;--后20%的条数

v_add_lng decimal(15,10);--评估房源坐标
v_add_lat decimal(15,10);--评估房源坐标
v_region varchar2(20); --评估房源区域

v_deal_avgprice decimal(13,2);--备案均价

begin

    --开始时间
    select sysdate into v_start_date from dual;
    v_i:=0;
    v_j:=0;
    v_k:=0;
    v_ii:=0;
    select count(1) into v_ii
    from estate.housetable h where h.tableid=s_tableid and h.data_source=s_data_source;

    --先清空临时表

    EXECUTE IMMEDIATE 'truncate table assessprice.evaluate_newhouse_tmp';
    --462642
    --510184
    --根据tableid,data_source，查询本栋前后365天内的新房备案

    --查询房源的建筑区划
    select h.district_id
      into v_district_id
      from assessprice.assess_house h
      where h.tableid=s_tableid and h.data_source=s_data_source and rownum=1;

    --统计同栋，同建筑形态的新房备案数量
    select count(1)
    into v_i
    from assessprice.evaluate_newhouse a inner join
    (
    select h.projid,h.data_source,h.building_type_code,h.buydate
    from assessprice.evaluate_newhouse h
    where h.tableid=s_tableid and h.data_source=s_data_source and h.usage in ('住宅','公寓','别墅')
    ) b on a.projid=b.projid and a.data_source=b.data_source and a.building_type_code=b.building_type_code
    where abs(ceil(a.buydate-b.buydate))<=365 and a.total_area>0;

    if v_i>=3 then
    --处理同栋前后365内达标的情况
    --assessprice.evaluate_newhouse_tmp
    insert into assessprice.evaluate_newhouse_tmp(tableid,data_source,price,total_area)
    select distinct a.tableid,a.data_source,a.price,a.total_area
      from assessprice.evaluate_newhouse a inner join
      (
      select h.projid,h.data_source,h.building_type_code,h.buydate
      from assessprice.evaluate_newhouse h
      where h.tableid=s_tableid and h.data_source=s_data_source and h.usage in ('住宅','公寓','别墅')
      ) b on a.projid=b.projid and a.data_source=b.data_source and a.building_type_code=b.building_type_code
      where abs(ceil(a.buydate-b.buydate))<=365 and a.total_area>0;
    else
         --如果同栋前后365内未达3套的情况时，按预售证进行处理
         select count(1)
         into v_j
         from assessprice.evaluate_newhouse a inner join
        (
        select distinct h.licenceid,h.data_source,h.building_type_code,h.buydate
        from assessprice.evaluate_newhouse h
        where h.tableid=s_tableid and h.data_source=s_data_source and h.usage in ('住宅','公寓','别墅')
        ) b on a.licenceid=b.licenceid and a.data_source=b.data_source and a.building_type_code=b.building_type_code
        where abs(ceil(a.buydate-b.buydate))<=365 and a.total_area>0;

        if v_j>=3 then
          --处理同栋前后365内未达3套，但预售证达标的情况
          insert into assessprice.evaluate_newhouse_tmp(tableid,data_source,price,total_area)
              select distinct a.tableid,a.data_source,a.price,a.total_area
            from assessprice.evaluate_newhouse a inner join
           (
           select distinct h.licenceid,h.data_source,h.building_type_code,h.buydate
           from assessprice.evaluate_newhouse h
           where h.tableid=s_tableid and h.data_source=s_data_source and h.usage in ('住宅','公寓','别墅')
           ) b on a.licenceid=b.licenceid and a.data_source=b.data_source and a.building_type_code=b.building_type_code
           where abs(ceil(a.buydate-b.buydate))<=365 and a.total_area>0;
      else
          --处理同栋前后365内未达3套，预售证也未达标的情况，查询出此房源建筑区域id并备案的情况
          --通过建筑区域id取已备案的房源情况

          if v_k>3 then
            insert into assessprice.evaluate_newhouse_tmp(tableid,data_source,price,total_area)
            select distinct aa.tableid,aa.data_source,aa.price,aa.total_area
            from assessprice.evaluate_newhouse aa
            where ( aa.tableid,aa.data_source ) in
            (
            select distinct h.tableid,h.data_source
      from assessprice.assess_house h
      where h.district_id = v_district_id
            );
          end if;
      end if;
    end if;

    select count(1) into v_kk from assessprice.evaluate_newhouse_tmp;

    if v_kk>=3 then
      --计算新房备案数量在3和4之间的备案均价
      if  v_kk<=4 then
        select sum(price)/sum(total_area) into v_deal_avgprice
        from assessprice.evaluate_newhouse_tmp;
      elsif v_kk>=5 then
        --计算新房备案大于等于5套时的备案均价
        select case when ceil(v_kk*0.2)=1 then 2 else ceil(v_kk*0.2) end ,floor(v_kk*0.8) into v_front_row,v_end_row from dual;

        select sum(tt.price)/sum(tt.total_area)
        into v_deal_avgprice
        from (
        select t.*,rownum as ts
        from
        (
        select tableid,data_source,price,total_area
        from assessprice.evaluate_newhouse_tmp order by price/total_area ) t ) tt
        where tt.ts between v_front_row and v_end_row;
      end if;

      --获得LJ成交房源情况,将明细案例数据插入到表：evaluate_house_detail
      --先删除本期评估数据
      delete from assessprice.evaluate_house_detail where evaluate_tableid=s_tableid and evaluate_data_source=s_data_source and evaluate_id=s_tableid||'-'||s_data_source||'-'||s_date and proc_name='pro_evaluate_house_detail_1';

      insert into assessprice.evaluate_house_detail (evaluate_data_source,evaluate_tableid,evaluate_id,evaluate_date,case_id,proc_name,
      case_type,case_tableid,case_data_source,his_price,buydate,
      price,total_area,verification_code,rate,
      lj_no,lj_name,usage,decoration,building_year,total_floor,lj_date,
      located_floor,house_type,elevator_num,
      elevator_house,elevator,avgprice)

      --LJ成交房源
      select s_data_source,s_tableid,s_tableid||'-'||s_data_source||'-'||s_date,to_date(s_date,'yyyy-mm-dd'),lth.lj_no,'pro_evaluate_house_detail_1',
        'LJ_TR',en.tableid,en.data_source,en.price,en.buydate,
        lth.total_tr_price,lth.total_area,lth.verification_code,lth.total_tr_price/en.price,
        lth.lj_no,lth.lj_name,lth.usage_1,lth.decoration,lth.building_year,lth.total_floor,lth.tr_date,
      lth.located_floor,lth.BEDROOM||'室'||lth.livingroom||'厅',lth.elevator_num,
      lth.elevator_house,lth.elevator,v_deal_avgprice
    from assessprice.lj_tr_house lth inner join assessprice.tmp_lj_district_rel tldr on lth.lj_name=tldr.lj_name
    inner join assessprice.evaluate_verification ev on lth.verification_code=ev.verifi_code
    inner join assessprice.evaluate_newhouse en on ev.tableid_int=en.tableid and ev.data_source=en.data_source
    where tldr.district_id=v_district_id
    and lth.verification_code is not null
    and lth.total_tr_price>0
    and en.price>0
    and lth.usage_1 like '%住宅%'
    and lth.tr_date<=sysdate - 365 --当期业务时间在-365天以内
    and abs(ceil(en.buydate -
    ( select h.buydate
      from assessprice.evaluate_newhouse h
      where h.tableid= s_tableid and h.data_source=s_data_source and rownum=1
    )))<=365 --新房备案时间在+-365天以内
    and abs(ceil(lth.building_year -
    ( select t.house_age
      from assessprice.assess_house t
      where t.tableid= s_tableid and t.data_source=s_data_source and rownum=1
    )))=1 --建成年代+-年

    union all

    --LJ挂牌房源
    select s_data_source,s_tableid,s_tableid||'-'||s_data_source||'-'||s_date,to_date(s_date,'yyyy-mm-dd'),lth.lj_no,'pro_evaluate_house_detail_1',
        'LJ_LIST',en.tableid,en.data_source,en.price,en.buydate,
        lth.Estimate_Price,lth.total_area,lth.verification_code,lth.Estimate_Price/en.price,
        lth.lj_no,lth.lj_name,lth.usage_1,lth.decoration,lth.building_year,lth.total_floor,lth.listed_date,
      lth.located_floor,lth.BEDROOM||'室'||lth.livingroom||'厅',lth.elevator_num,
      lth.elevator_house,lth.elevator,v_deal_avgprice
    from assessprice.lj_listed_house lth inner join assessprice.tmp_lj_district_rel tldr on lth.lj_name=tldr.lj_name
    inner join assessprice.evaluate_verification ev on lth.verification_code=ev.verifi_code
    inner join assessprice.evaluate_newhouse en on ev.tableid_int=en.tableid and ev.data_source=en.data_source
    where tldr.district_id=v_district_id
    and lth.verification_code is not null
    and lth.Estimate_Price>0
    and lth.usage_1 like '%住宅%'
    and en.price>0
    and lth.Listed_Date<=sysdate - 365 --当期业务时间在-365天以内
    and abs(ceil(en.buydate -
    ( select h.buydate
      from assessprice.evaluate_newhouse h
      where h.tableid= s_tableid and h.data_source=s_data_source and rownum=1
    )))<=365 --新房备案时间在+-365天以内
    and abs(ceil(lth.building_year -
    ( select t.house_age
      from assessprice.assess_house t
      where t.tableid= s_tableid and t.data_source=s_data_source and rownum=1
    )))=1 --建成年代+-年
    ;

    --按LJ_NO去掉重复数据，规则：如果LJ_NO重复，则保留LJ_TR
    delete from assessprice.evaluate_house_detail tt
  where tt.case_type='LJ_LIST'
  and tt.lj_no in (
  select t.lj_no from assessprice.evaluate_house_detail t
  where evaluate_id=s_tableid||'-'||s_data_source||'-'||s_date and proc_name='pro_evaluate_house_detail_1'
  group by t.lj_no
  having count(1)>1
  )
  and evaluate_id=s_tableid||'-'||s_data_source||'-'||s_date and proc_name='pro_evaluate_house_detail_1';

    --统计案例数量
    select count(1)
    into v_jj
    from assessprice.evaluate_house_detail t
    where t.evaluate_id=s_tableid||'-'||s_data_source||'-'||s_date and proc_name='pro_evaluate_house_detail_1';

    --计算明细数据在3和4之间的平均涨幅：v_rate
    if v_jj>=3 and v_jj<=4 then
      select sum(rate)/count(1)
      into v_rate
      from assessprice.evaluate_house_detail
      where evaluate_id=s_tableid||'-'||s_data_source||'-'||s_date and proc_name='pro_evaluate_house_detail_1';
    end if;

    if v_jj>=5 then
      --计算明细数据大于等于5时的平均涨幅
      v_front_row:=0;
      v_end_row:=0;

      select case when ceil(v_jj*0.2)=1 then 2 else ceil(v_jj*0.2) end ,floor(v_jj*0.8) into v_front_row,v_end_row from dual;

      select sum(tt.rate)/(v_end_row-v_front_row+1)
      into v_rate
      from (
      select t.*,rownum as ts
      from
      (
    select t.evaluate_tableid,t.evaluate_data_source,t.rate
      from assessprice.evaluate_house_detail t
        where  evaluate_id=s_tableid||'-'||s_data_source||'-'||s_date and proc_name='pro_evaluate_house_detail_1'
        order by rate ) t
        ) tt
      where tt.ts between v_front_row and v_end_row;
    end if;


    if v_jj>=3 then
      --如果去重后的案例数量大于3，写入评估结果表：assessprice.evaluate_house_result

      merge into assessprice.evaluate_house_result t
        using (select s_tableid||'-'||s_data_source||'-'||s_date as assess_id,
                            s_tableid as evaluate_tableid,
                            s_data_source as data_source,
                            to_date(s_date,'yyyy-mm-dd') as assess_date,
                            v_rate*v_deal_avgprice as fun_price_1,
                            v_deal_avgprice as INITIA_AVG,
                            v_end_row-v_front_row+1 as CASE_NUM_1
                  from dual ) h
        on ( t.assess_id=h.assess_id)
        when matched then
        update set t.fun_price_1=h.fun_price_1,t.INITIA_AVG=h.INITIA_AVG,t.CASE_NUM_1=h.CASE_NUM_1
        when not matched then
        insert( assess_id,evaluate_tableid,data_source,assess_date,fun_price_1,INITIA_AVG,CASE_NUM_1)
        values(s_tableid||'-'||s_data_source||'-'||s_date,s_tableid,s_data_source,to_date(s_date,'yyyy-mm-dd'),v_rate*v_deal_avgprice,v_deal_avgprice,v_end_row-v_front_row+1 );

      /*
      insert into assessprice.evaluate_house_result ( assess_id,evaluate_tableid,data_source,assess_date,fun_price_1,INITIA_AVG,CASE_NUM_1)
      values(s_tableid||'-'||s_data_source||'-'||s_date,s_tableid,s_data_source,to_date(s_date,'yyyy-mm-dd'),v_rate*v_deal_avgprice,v_deal_avgprice,v_end_row-v_front_row+1 );
      */

    else
      --如果去重后的案例数量小于3，根据距离计算案例房源。
      v_jj:=0;
      select count(1)
      into v_jj
      from tmp_lj_district_rel b
    where b.district_id=v_district_id;

      if v_jj>0 then
        select b.region,b.add_lng,b.add_lat
        into v_region,v_add_lng,v_add_lat
      from tmp_lj_district_rel b
      where b.district_id=v_district_id;

      delete from assessprice.evaluate_house_detail where evaluate_tableid=s_tableid and evaluate_data_source=s_data_source and evaluate_id=s_tableid||'-'||s_data_source||'-'||s_date and proc_name='pro_evaluate_house_detail_1';

        insert into assessprice.evaluate_house_detail (evaluate_data_source,evaluate_tableid,evaluate_id,evaluate_date,case_id,proc_name,
        case_type,case_tableid,case_data_source,his_price,buydate,
        price,total_area,verification_code,rate,
        lj_no,lj_name,usage,decoration,building_year,total_floor,lj_date,
        located_floor,house_type,elevator_num,
        elevator_house,elevator,avgprice)

        --LJ成交房源
        select s_data_source,s_tableid,s_tableid||'-'||s_data_source||'-'||s_date,to_date(s_date,'yyyy-mm-dd'),lth.lj_no,'pro_evaluate_house_detail_1',
          'LJ_TR',en.tableid,en.data_source,en.price,en.buydate,
          lth.total_tr_price,lth.total_area,lth.verification_code,lth.total_tr_price/en.price,
          lth.lj_no,lth.lj_name,lth.usage_1,lth.decoration,lth.building_year,lth.total_floor,lth.tr_date,
        lth.located_floor,lth.BEDROOM||'室'||lth.livingroom||'厅',lth.elevator_num,
        lth.elevator_house,lth.elevator,v_deal_avgprice
      from assessprice.lj_tr_house lth /*inner join assessprice.tmp_lj_district_rel tldr on lth.lj_name=tldr.lj_name*/
      inner join assessprice.lj_project tldr on lth.lj_name=tldr.lj_name
      inner join assessprice.evaluate_verification ev on lth.verification_code=ev.verifi_code
      inner join assessprice.evaluate_newhouse en on ev.tableid_int=en.tableid and ev.data_source=en.data_source
      where /*FUNC_GET_EARTH_DISTANCE(tldr.add_lng,tldr.add_lat,v_add_lng,v_add_lat)<=3000*/
      FUNC_GET_EARTH_DISTANCE(tldr.longtitude_add,tldr.latitude_add,v_add_lng,v_add_lat)<=3000
      and tldr.region=v_region
      and lth.verification_code is not null
      and lth.total_tr_price>0
      and lth.usage_1 like '%住宅%'
      and en.price>0
      and lth.tr_date<=sysdate - 365 --当期业务时间在-365天以内
      and abs(ceil(en.buydate -
      ( select h.buydate
        from assessprice.evaluate_newhouse h
        where h.tableid= s_tableid and h.data_source=s_data_source and rownum=1
      )))<=365 --新房备案时间在+-365天以内
      and abs(ceil(lth.building_year -
      ( select t.house_age
        from assessprice.assess_house t
        where t.tableid= s_tableid and t.data_source=s_data_source and rownum=1
      )))=1 --建成年代+-年

      union all

      --LJ挂牌房源
      select s_data_source,s_tableid,s_tableid||'-'||s_data_source||'-'||s_date,to_date(s_date,'yyyy-mm-dd'),lth.lj_no,'pro_evaluate_house_detail_1',
          'LJ_LIST',en.tableid,en.data_source,en.price,en.buydate,
          lth.Estimate_Price,lth.total_area,lth.verification_code,lth.Estimate_Price/en.price,
          lth.lj_no,lth.lj_name,lth.usage_1,lth.decoration,lth.building_year,lth.total_floor,lth.listed_date,
        lth.located_floor,lth.BEDROOM||'室'||lth.livingroom||'厅',lth.elevator_num,
        lth.elevator_house,lth.elevator,v_deal_avgprice
      from assessprice.lj_listed_house lth /*inner join assessprice.tmp_lj_district_rel tldr on lth.lj_name=tldr.lj_name*/
      inner join assessprice.lj_project tldr on lth.lj_name=tldr.lj_name
      inner join assessprice.evaluate_verification ev on lth.verification_code=ev.verifi_code
      inner join assessprice.evaluate_newhouse en on ev.tableid_int=en.tableid and ev.data_source=en.data_source
      where /*FUNC_GET_EARTH_DISTANCE(tldr.add_lng,tldr.add_lat,v_add_lng,v_add_lat)<=3000*/
      FUNC_GET_EARTH_DISTANCE(tldr.longtitude_add,tldr.latitude_add,v_add_lng,v_add_lat)<=3000
      and tldr.region=v_region
      and lth.verification_code is not null
      and lth.Estimate_Price>0
      and lth.usage_1 like '%住宅%'
      and en.price>0
      and lth.Listed_Date<=sysdate - 365 --当期业务时间在-365天以内
      and abs(ceil(en.buydate -
      ( select h.buydate
        from assessprice.evaluate_newhouse h
        where h.tableid= s_tableid and h.data_source=s_data_source and rownum=1
      )))<=365 --新房备案时间在+-365天以内
      and abs(ceil(lth.building_year -
      ( select t.house_age
        from assessprice.assess_house t
        where t.tableid= s_tableid and t.data_source=s_data_source and rownum=1
      )))=1 --建成年代+-年
      ;

      --统计案例数量
      v_jj:=0;

      select count(1)
      into v_jj
      from assessprice.evaluate_house_detail t
      where t.evaluate_id=s_tableid||'-'||s_data_source||'-'||s_date and proc_name='pro_evaluate_house_detail_1';

      --计算明细数据在3和4之间的平均涨幅：v_rate
      if v_jj>=3 and v_jj<=4 then
        select sum(rate)/count(1)
        into v_rate
        from assessprice.evaluate_house_detail
        where evaluate_id=s_tableid||'-'||s_data_source||'-'||s_date and proc_name='pro_evaluate_house_detail_1';
      end if;

      if v_jj>=5 then
        --计算明细数据大于等于5时的平均涨幅
        v_front_row:=0;
        v_end_row:=0;

        select case when ceil(v_jj*0.2)=1 then 2 else ceil(v_jj*0.2) end ,floor(v_jj*0.8) into v_front_row,v_end_row from dual;

        select sum(tt.rate)/(v_end_row-v_front_row+1)
        into v_rate
        from (
        select t.*,rownum as ts
        from
        (
      select t.evaluate_tableid,t.evaluate_data_source,t.rate
        from assessprice.evaluate_house_detail t
          where  evaluate_id=s_tableid||'-'||s_data_source||'-'||s_date and proc_name='pro_evaluate_house_detail_1'
          order by rate ) t
          ) tt
        where tt.ts between v_front_row and v_end_row;
      end if;

      if v_jj>=3 then
        --如果去重后的案例数量大于3，写入评估结果表：assessprice.evaluate_house_result
        merge into assessprice.evaluate_house_result t
        using (select s_tableid||'-'||s_data_source||'-'||s_date as assess_id,
                            s_tableid as evaluate_tableid,
                            s_data_source as data_source,
                            to_date(s_date,'yyyy-mm-dd') as assess_date,
                            v_rate*v_deal_avgprice as fun_price_1,
                            v_deal_avgprice as INITIA_AVG,
                            v_end_row-v_front_row+1 as CASE_NUM_1
                  from dual ) h
        on ( t.assess_id=h.assess_id)
        when matched then
        update set t.fun_price_1=h.fun_price_1,t.INITIA_AVG=h.INITIA_AVG,t.CASE_NUM_1=h.CASE_NUM_1
        when not matched then
        insert( assess_id,evaluate_tableid,data_source,assess_date,fun_price_1,INITIA_AVG,CASE_NUM_1)
        values(s_tableid||'-'||s_data_source||'-'||s_date,s_tableid,s_data_source,to_date(s_date,'yyyy-mm-dd'),v_rate*v_deal_avgprice,v_deal_avgprice,v_end_row-v_front_row+1 );
      end if;
    end if;
    end if;
    end if;

    --结束时间
    select sysdate into v_end_date from dual;

    delete from assessprice.operate_log where proc_name='pro_evaluate_house_detail_1' and parameter_name=s_date;
    insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
    values(sys_guid(),'pro_evaluate_house_detail_1',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'成功','');
    commit;

    exception
    when others then
    v_sqlcode:=('错误代码:'||SQLCODE);
    v_sqlerrm:=('错误信息:'||SQLERRM);
    insert into assessprice.operate_log(uuid,proc_name,parameter_name,start_time,end_time,oper_time,result,err_text)
    values(sys_guid(),'pro_evaluate_house_detail_1',s_date,v_start_date,v_end_date,to_char(round((v_end_date-v_start_date)*24*60*60,0)),'失败:'||v_sqlcode,v_sqlerrm);
    commit;
end pro_evaluate_house_detail_1;
/

