CREATE procedure PRO_tmp_lj_district_rel
is
/************************************************************************************************************************************
开发人员：tsn
开发时间：2017-04-14
变更时间：计算tmp_lj_district_rel
变更内容：
输入参数：
返回参数：
过程功能：
************************************************************************************************************************************/
sv_err_sqlcode varchar2(200);
sv_err_SQLERRM varchar2(2000);

begin

    --建筑区划信息
  merge into assessprice.tmp_lj_district_rel b
    using  (SELECT distinct a.id district_id,
               a.district_name as project_name,
               flcr.project_name as new_project_name,
               flcr.circle_name as circle,
               flcr.direction_name as position,
               flcr.plate_name as new_block_name,
               a.district_address as district_add,
               flcr.presell_region_name as region,
               flcr.ods_data_source as data_source
        FROM wxzj.fix_district a
        inner join wxzj.fix_building b on a.id = b.district_id and a.is_deleted = 0 and b.is_deleted = 0
        inner join wxzj.fix_house c on b.id = c.building_id and b.is_deleted = 0 and c.is_deleted = 0
        inner join estate.housetable h on c.manual_code = h.tableid and c.data_source = h.data_source
        and regexp_replace(c.manual_code,'[0-9]') is null
        and h.usage in('住宅','公寓','别墅','成套住宅') and c.is_deleted = 0
        inner join fina.fina_licenceid_community_rel flcr on h.licenceid=flcr.licenceid and h.data_source=flcr.ods_data_source ) a
  on ( b.district_id = a.district_id )
  when matched then 
    update set b.if_house_flag=1
  when not matched then
    insert (id,district_id,project_name,new_project_name,circle,position,new_block_name,district_add,region,data_source,if_house_flag)
    values(sys_guid(),a.district_id,a.project_name,a.new_project_name,a.circle,a.position,a.new_block_name,a.district_add,a.region,a.data_source,1);

   delete ASSESSPRICE.WORK_LOG where name='PRO_tmp_lj_district_rel' and trunc(in_date)=trunc(sysdate);
   insert into ASSESSPRICE.WORK_LOG
   values(assessprice.seq_work_log_id.nextval,'PRO_tmp_lj_district_rel','','','是','成功',trunc(sysdate),'','','PRO_tmp_lj_district_rel');
   commit;

   exception when others then
   dbms_output.put_line('捕获错误 ');
   sv_err_sqlcode:=('错误代码：'||SQLCODE);
   sv_err_SQLERRM:=('错误信息：'||SQLERRM);
   insert into ASSESSPRICE.WORK_LOG
   values(assessprice.seq_work_log_id.nextval,'PRO_tmp_lj_district_rel','','','是','失败',trunc(sysdate),sv_err_sqlcode,sv_err_SQLERRM,'PRO_tmp_lj_district_rel');
   commit;
end PRO_tmp_lj_district_rel;
/

