CREATE procedure             PRO_TRA_SCORE
is
/************************************************************************************************************************************
开发人员：谢勇
开发时间：2016-11-16
变更时间：
变更内容：
输入参数：
返回参数：
过程功能：增量新增或者更新房屋评估系统房源指标对应得分
************************************************************************************************************************************/

sv_err_sqlcode varchar2(200);
sv_err_SQLERRM varchar2(2000);

begin

----------------------------------------------------------------------------------
----计算各指标对应分值
-----------------------------------------------------------------------------------

--增量更新楼层差数据

--楼层差


--楼层差

/*fno = abs(目标房源楼层-round(最大楼层数/2,0))*/
update assessprice.assess_keypoint a
set a.score =
case when keypoint_value in('0','1','2') then 110
  when keypoint_value in('3','4','5') then 105
    when keypoint_value in('6','7','8') then 100
      when keypoint_value in('9','10','11') then 95
        when keypoint_value in('12','13','14') then 90
          else  110 end,
a.phase = 3
WHERE a.phase = '0'
and a.keypoint_code = 'KEY_1_1_1'
;
commit;
--朝向
update assessprice.assess_keypoint a
set a.score =
case when keypoint_value = '西北' then 90
  when keypoint_value = '西' then 92
    when keypoint_value = '北' then 96
      when keypoint_value = '东北' then 98
        when keypoint_value = '西南' then 102
          when keypoint_value = '南' then 108
            when keypoint_value = '西南' then 110
              else 110 end,
a.phase = 3
WHERE a.phase = '0'
and a.keypoint_code = 'KEY_1_1_2'
;
commit;
--装修
update assessprice.assess_keypoint a
set a.score =
case when keypoint_value = '毛坯' then 100
  when keypoint_value = '简装' then 105
    when keypoint_value = '精装' then 110
      when keypoint_value = '豪华装修' then 115
        else 115 end,
a.phase = 3
WHERE a.phase = '0'
and a.keypoint_code = 'KEY_1_1_3'
;
commit;
--面积段
update assessprice.assess_keypoint a
set a.score =
case when keypoint_value < 50 then 85
  when keypoint_value >= 50 and keypoint_value < 70 then 90
    when keypoint_value >= 70 and keypoint_value < 90 then 95
      when keypoint_value >= 90 and keypoint_value < 110 then 100
        when keypoint_value >= 110 and keypoint_value < 130 then 105
          when keypoint_value >= 130 and keypoint_value < 150 then 110
            when keypoint_value >= 150 then 115
              else 115 end,
a.phase = 3
WHERE a.phase = '0'
and a.keypoint_code = 'KEY_1_1_4'
;
commit;

--用地面积
update assessprice.assess_keypoint a
set a.score =
case when keypoint_value >= 0 and keypoint_value < 20 then 90
  when keypoint_value >= 20 and keypoint_value < 50 then 95
    when keypoint_value >= 50 and keypoint_value < 100 then 100
      when keypoint_value >= 100 and keypoint_value < 200 then 105
        when keypoint_value >= 200 then 110
          else 110 end ,
a.phase = 3
WHERE a.phase = '0'
and a.keypoint_code = 'KEY_1_1_5'
;
commit;

--物业费
update assessprice.assess_keypoint a
set a.score =
case when keypoint_value >= 0 and keypoint_value < 1 then 85
  when keypoint_value >= 1 and keypoint_value < 2 then 90
    when keypoint_value >= 2 and keypoint_value < 3 then 95
      when keypoint_value >= 3 and keypoint_value < 5 then 100
        when keypoint_value >= 5 and keypoint_value < 7 then 110
          when keypoint_value >= 10 then 115
            else 110 end ,
a.phase = 3
WHERE a.phase = '0'
and a.keypoint_code = 'KEY_1_1_6'
;
commit;

--立面年限
update assessprice.assess_keypoint a
set a.score =
case when keypoint_value >= 0 and keypoint_value < 1 then 85
  when keypoint_value >= 1 and keypoint_value < 2 then 90
    when keypoint_value >= 2 and keypoint_value < 3 then 95
      when keypoint_value >= 3 and keypoint_value < 5 then 100
        when keypoint_value >= 5 and keypoint_value < 7 then 110
          when keypoint_value >= 10 then 115
            else 110 end ,
a.phase = 3
WHERE a.phase = '0'
and a.keypoint_code = 'KEY_1_1_6'
;
commit;
---建筑立面
update assessprice.assess_keypoint a
set a.score = 100,
a.phase = 3
WHERE a.phase = '0'
and a.keypoint_code = 'KEY_1_1_7'
;
commit;
/*case when keypoint_value = '瓷砖' and  2016 - keypoint_value <=5 then 100
  when keypoint_value = '瓷砖' and  2016 - keypoint_value >5 and 2016 - keypoint_value <=10 then 95
    when keypoint_value = '瓷砖' and  2016 - keypoint_value >10 then 85
      when keypoint_value = '涂料' and  2016 - keypoint_value <=5  then 95
        when keypoint_value = '涂料' and  2016 - keypoint_value >5 and 2016 - keypoint_value <=10 then 90
          when keypoint_value = '涂料' and  2016 - keypoint_value >10 then 80
            else 100 end KEY_1_1_7,*/
--结构
update assessprice.assess_keypoint a
set a.score =
case when keypoint_value = '框架' then 100
  when keypoint_value = '砖混' then 90
    when keypoint_value = '砖木' then 85
      when keypoint_value = '简易' then 80
        else 100 end ,
a.phase = 3
WHERE a.phase = '0'
and a.keypoint_code = 'KEY_1_1_8'
;
commit;

--建成年代
update assessprice.assess_keypoint a
set a.score =
case when 2016 - keypoint_value < 3 then 120
   when 2016 - keypoint_value >= 3 and 2016 - keypoint_value < 5  then 110
      when 2016 - keypoint_value >= 5 and 2016 - keypoint_value < 10  then 105
        when 2016 - keypoint_value >= 10 and 2016 - keypoint_value < 15  then 100
          when 2016 - keypoint_value >= 15 and 2016 - keypoint_value < 20  then 95
            when 2016 - keypoint_value >= 20 and 2016 - keypoint_value < 30  then 90
              when 2016 - keypoint_value >= 30  then 80
                else 110 end  ,
a.phase = '3'
WHERE a.phase = '0'
and regexp_like(a.keypoint_value,'^[0-9]')
and a.keypoint_code = 'KEY_1_1_9'
;
commit;
update assessprice.assess_keypoint a
set a.score = 100,
a.phase = '3'
where a.phase = '0'
and a.keypoint_code = 'KEY_1_1_9'
;
commit;


--------------------
--计算各指标分数

update assessprice.assess_keypoint a
set
a.keypoint_algorithm = nvl(a.score,100)*a.weight,
a.phase = '1'
where a.phase = '3'
;



insert into ASSESSPRICE.WORK_LOG values(assessprice.seq_work_log_id.nextval,'抽取数据成功','','','否','',sysdate,sv_err_sqlcode,sv_err_SQLERRM,'基础数据抽取模块');
commit;
    exception when others then
    dbms_output.put_line('捕获错误 ');
    sv_err_sqlcode:=('错误代码：'||SQLCODE);
    sv_err_SQLERRM:=('错误信息：'||SQLERRM);
insert into ASSESSPRICE.WORK_LOG values(assessprice.seq_work_log_id.nextval,'捕获错误','','','是否有错','错误名称',sysdate,sv_err_sqlcode,sv_err_SQLERRM,'评估基础数据抽取模块');

    commit;

end PRO_TRA_SCORE;



--spool off
/

